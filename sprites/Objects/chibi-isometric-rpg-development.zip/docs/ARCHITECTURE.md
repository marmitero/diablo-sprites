# Arquitetura

```
src/
  app/                    Next.js (App Router)
    page.tsx              monta <GameCanvas/>
    api/saves/route.ts    GET (lista) / PUT (upsert slot 1..3) / DELETE ?slot=
    api/deeds/route.ts    GET últimos 20 / POST registro de chefe morto
  components/GameCanvas.tsx  canvas único, import dinâmico do jogo (client only)
  db/schema.ts            tabelas `saves` e `hero_deeds` (Drizzle)
  game/
    Game.ts               loop, input escalado (1280x720 letterbox), cenas, fades, persistência
    core/
      rng.ts              mulberry32 + hashString + Noise2D (value noise/fbm)
      assets.ts           loader, chroma-key, trim/slice, composição LPC, tiles de terreno, alpha masks
      audio.ts            sintetizador de música/SFX
      ui.ts               primitivas de UI em canvas (fancyText, panel, button, orb, cursor, partículas)
    data/
      classes.ts          ClassDef/SkillDef (4 classes × 5 skills)
      acts.ts             ActDef (bioma, inimigos, chefe, capítulos, textos) + NPCS
      items.ts            geração de equipamentos/afixos/poções/materiais + ícones
    world/
      mapgen.ts           generateRegion(seed, act) → Region
      entities.ts         tipos (Player/Enemy/Ally/Npc/Projectile/Drop/Effect), SaveData, derived()
    scenes/
      menu.ts             título, slots, seed, opções, créditos, LetterPicker (PS1)
      cutscene.ts         narração + nome + ClassSelectScene
      play.ts             simulação + render do mundo
      playUI.ts           HUD, painéis, lojas, diálogos, minimapa
public/
  sprites/lpc/*.png       camadas LPC (832x1344)
  img/*.png|jpg           pinturas (menu, logo, retratos, props, cabanas)
```

## Loop e cenas
`Game` roda `requestAnimationFrame`, `dt` limitado a 50ms. Interface `Scene { update, render, onMouse*, onKey*, cursorMode }`. Troca de cena por `game.goto(scene, speed)` com fade.

Resolução virtual 1280×720; o canvas é escalado por CSS para a janela e o mouse é convertido para o espaço virtual.

## Pipeline de assets (runtime)
1. **LPC**: cada camada é um spritesheet 832×1344 (13 col × 21 lin, frames 64px). `composeSheet(layers)` desenha as camadas em ordem num canvas e cacheia por chave. Pseudo-camada `tint:#rrggbb@alpha` aplica uma tinta `source-atop` (variações de inimigos por ato). Armas *oversize* (192px) ficam num canvas separado e são desenhadas só na animação correspondente.
2. **Pinturas**: fundo verde puro → `chromaKey` (threshold + despill + alpha suave). Sheets de props/cabanas são fatiadas em grade e aparadas (`sliceGrid`).
3. **Tiles**: `makeGroundTiles(bioma)` gera 4 variantes de chão (ruído), 16 tiles de caminho e 16 de líquido via *marching squares* no losango, com bordas curvas, "rim" só na borda orgânica e máscara de pixel exata (sem emendas).
4. Props por bioma: `hueShift` (hue/sat/brightness) dos props da floresta e das cabanas.

## Geração de mapa (mapgen.ts)
Determinística em `(seed, act)`:
1. Quadrante da aldeia sorteado; covil do chefe no canto oposto.
2. POIs (waystone, altar, 3–4 acampamentos) com distâncias mínimas/máximas da aldeia e entre si.
3. Líquidos: fbm > 0.62 nos vértices, removidos perto de aldeia/POIs/covil.
4. Caminhos: *random walk* enviesado por ruído da aldeia (ou de um POI anterior, 40%) até cada POI, carimbado em raio ~1.1–1.4 nos vértices (+ praça circular). Caminhos limpam líquidos ao redor. A máscara de 4 cantos de cada tile seleciona o tile autotile.
5. Bloqueio: tile com ≥3 cantos líquidos.
6. Aldeia: 6 construções num anel (raio 7.6) começando no ângulo do spawn (cabana do Ancião é a 1ª), NPC 3.6 tiles à frente de cada cabana, poço, cercas, portal oposto ao spawn.
7. Anel do covil (árvores mortas/pedras, abertura de ±0.55 rad para a aldeia).
8. Props: para cada tile fora de aldeia/caminho/líquido/clareiras: árvores se `rand < (fbm−0.35)²·1.6`, pedras se ruído de rocha > 0.72, arbustos esparsos. Grade de ocupação garante espaçamento mínimo (árvore 1.6, pedra 1.2). Props bloqueiam tiles num raio.
9. Spawns: acampamentos nos POIs (5–8), chefe + escolta no covil, packs espalhados (`W·H/420`), tier do tipo cresce com a distância. Elite do capítulo `elite` nasce no acampamento de índice 3.

## Render isométrico
`screen = ((x−y)·32, (x+y)·16) − câmera`. Tiles visíveis por bounding box do viewport. Depois, uma lista única (props, drops, atores, projéteis) ordenada por `x+y`. Oclusão: prop à frente do jogador com ≥2 amostras de alpha > 40 sobre o corpo do jogador → alpha 0.4 (`alphaAt` usa máscara 1/4 cacheada).

## Combate / skills
`castSkill` valida nível/mana/cooldown, toca animação e enfileira `castQueue`; o efeito executa no frame de impacto (`executeSkill`), por `kind`: melee_aoe, dash, buff, quake, phantom, projectile, heal, nova, shield, judgement, summon, army, corpse, curse, chain, teleport, meteor. VFX em `effects[]` (ring, beam, pillar, crack, meteor, aura, slashArc, summonCircle, portalBurst) + partículas no espaço do mundo.

## Formato de save (`SaveData`, jsonb em `saves.data`)
```
{ version, name, classId, evolved, seed, level, xp, statPoints, stats{str,dex,vit,ene},
  gold, inventory[Item], equipment{slot:Item}, act, maxAct, chapterIndex{act:idx}, chapterProgress,
  waypoints["1:village","1:waystone",...], poisFound["1:altar",...], playtime, hp, mp,
  bossesKilled[], deaths, kills, shopSeed }
```
Regiões não são salvas: são regeneradas da seed; inimigos renascem ao entrar (grind-friendly); chefes mortos não renascem (`bossesKilled`).

## Como estender
- **Novo ato**: adicionar `ActDef` em `acts.ts` (bioma, inimigos, chefe, capítulos). Tudo o mais é automático.
- **Nova skill**: `SkillDef` na classe + `case` em `executeSkill` se for um `kind` novo + runa em `drawSkillRune`.
- **Novo inimigo**: `EnemyTypeDef` com camadas LPC (ver ASSETS.md); tint para variações.
- **Novo prop**: adicionar à sheet (ou nova sheet) e ao `propVariant`/regras de `mapgen`.
- **Novo tipo de capítulo**: `ChapterKind` + progressão em `play.ts` (`killEnemy`, `checkCollect`, `updateExploration`, `deliverTo`).
