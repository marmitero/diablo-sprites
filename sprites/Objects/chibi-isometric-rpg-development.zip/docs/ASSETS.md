# Assets

## Personagens, NPCs e inimigos — Universal LPC Spritesheet (importado)
Fonte: `github.com/makrohn/Universal-LPC-spritesheet` (Liberated Pixel Cup). Licença **CC-BY-SA 3.0 / GPL 3.0** — manter crédito aos autores (Stephen Challener/Redshrike, Johannes Sjölund/wulax, Matthew Krohn/makrohn, Luke Mehl, Manuel Riecke, Thane Brimhall, Marcel van de Steeg, Lanea Zimmerman/Sharm, entre outros). Créditos exibidos no jogo (tela de Créditos e loading).

Arquivos em `public/sprites/lpc/` (nome local → caminho original):
- Corpos: `body_light|tanned|dark|skeleton|orc|red_orc|darkelf` ← `body/male/*.png`
- Cabelos: `hair_plain_brown, hair_long_white, hair_messy_black, hair_ponytail_blonde, hair_bedhead_raven, hair_mohawk_red, hair_shorthawk_gray, hair_long_raven` ← `hair/male/<estilo>/<cor>.png`
- Barbas: `beard_white|gray|brown` ← `facial/male/beard/*.png`
- Torso: `torso_plate, torso_plate_arms, torso_chain, torso_leather, torso_leather_shoulders, torso_shirt_white|brown|maroon|teal, torso_gold, torso_gold_arms`
- Pernas: `legs_magenta|red|teal|white|metal|gold|robe`
- Cabeça: `head_cloth_hood, head_chain_hood, head_metal_helm, head_gold_helm, head_leather_cap, head_bandana, head_chainhat`
- Pés/mãos: `feet_brown|black|metal|gold`, `hands_metal|leather|gold`
- Armas (64px): `wpn_dagger, wpn_wand, wpn_spear, wpn_shield` · Oversize (192px): `wpn_longsword, wpn_mace, wpn_saber` (slash) e `wpn_trident` (thrust)

### Layout do sheet (832×1344, frames 64×64)
| Linhas | Animação | Frames |
|---|---|---|
| 0–3 | spellcast | 7 |
| 4–7 | thrust | 8 |
| 8–11 | walk (frame 0 = parado) | 9 |
| 12–15 | slash | 6 |
| 16–19 | shoot | 13 |
| 20 | hurt/die | 6 |
Direções dentro de cada bloco: up, left, down, right. Oversize: 4 linhas × (6 ou 8) colunas de 192px, desenhado com offset −64.

### Como adicionar um personagem
1. Baixe as camadas desejadas para `public/sprites/lpc/<nome>.png` e adicione o nome em `LPC_LAYERS` (`assets.ts`).
2. Use a lista de camadas (ordem = ordem de desenho: corpo → pés → pernas → torso → mãos → cabelo → cabeça → arma) em `classes.ts`/`acts.ts`.
3. Variações baratas: pseudo-camada `tint:#cor@alpha`.

## Pinturas (geradas para o projeto e pós-processadas por chroma-key)
| Arquivo | Uso | Observação |
|---|---|---|
| `img/menu_sky.jpg` | camada de fundo do menu (parallax lento) | |
| `img/menu_fg.png` | camada frontal (ruínas/árvores) | verde → alpha |
| `img/logo.png` | logotipo animado | verde → alpha, trim |
| `img/portrait_{warrior,priest,necromancer,sorcerer}.png` | seleção de classe, slots de save | |
| `img/portrait_elder.png` | cutscene e diálogo do Ancião | |
| `img/props_forest.png` | sheet 5×2: carvalho, pinheiro, árvore morta, arbusto, cogumelos, pedregulho, rocha, pedras, cerca, poço | fatiada em runtime; re-skin por bioma (hue/sat/brilho) |
| `img/props_huts.png` | sheet 3×2: cabana do ancião, forja, barraca do mercador, casa destruída, tenda do viajante, capela em ruínas | |

Chroma-key: pixels com `G − max(R,B) > 80` viram transparentes; faixa 25–80 recebe alpha gradual + despill.

## Terreno (gerado em runtime)
Paletas por bioma em `acts.ts → biome` (chão ×3, detalhe, caminho ×2, líquido ×2 + brilho). Tiles 64×32, autotile de 16 casos.

## Áudio
100% sintetizado (`audio.ts`). Sem arquivos. Para usar faixas reais: substituir `playMusic` por `AudioBufferSourceNode` mantendo a API.
