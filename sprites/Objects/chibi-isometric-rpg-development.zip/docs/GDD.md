# Game Design Document — Pilares do Inferno

## 1. Visão
Action RPG isométrico "Diablo 2 chibi" para navegador. Fantasia sombria, humor leve pela arte chibi, loop de **explorar → matar → saquear → voltar à aldeia → fortalecer → avançar**. Cada run é gerada a partir de uma **seed** (mesma seed = mesmo mundo, caminhos, aldeias, hordas e capítulos).

## 2. Pilares de design
1. **Tudo em canvas** – menus, HUD, diálogos, lojas, mapa: nenhum DOM/CSS de UI.
2. **Procedural com identidade** – mapa, props, hordas e seleção de capítulos vêm da seed; a *história* (atos, chefes, NPCs) é autoral.
3. **Dificuldade em degraus** – cada ato é ~3x mais perigoso que o anterior; o jogador precisa *grindar* (nível, equipamentos +N, poções maiores) antes de avançar. A aldeia é safezone absoluta.
4. **Expansível por dados** – classes, skills, atos, inimigos e capítulos são tabelas em `src/game/data/*`.

## 3. Fluxo de telas
Boot (loading) → **Menu** (parallax, partículas, trilha própria, SFX hover/seleção) → Slot (3 saves) → Seed (aleatória/digitada) → **Cutscene** do Ancião (typewriter) → **Nome** (seletor de letras estilo PS1) → continuação da narração → **Seleção de classe** (4 classes, destaque, descrição) → **Jogo** (nasce na aldeia, cabana do Ancião é a mais próxima).

## 4. Mundo
- 5 Atos / 5 regiões, cada uma com **aldeia própria** (mesmos 4 NPCs, estética do bioma via re-skin das cabanas/props).
- Região = grade isométrica 112–130² tiles. Terreno base + caminhos autotile (16 casos, bordas orgânicas) + líquidos (água/ácido/gelo/lava) autotile.
- Props seguem regras: densidade por ruído, espaçamento mínimo por tipo, clareiras em POIs, anel de árvores mortas/pedras no covil do chefe com abertura voltada para a aldeia, nada sobre caminhos, oclusão (prop à frente do jogador fica translúcido via teste de alpha).
- POIs: Pedra do Portal (waypoint), Local misterioso (altar/templo/trono...), 3–4 acampamentos, Covil do chefe (canto oposto à aldeia).
- Portal da aldeia: viaja entre todas as aldeias liberadas e Pedras do Portal descobertas (todas as regiões anteriores continuam acessíveis).

## 5. Aldeia (safezone)
- Monstros não entram, não atacam e só reconhecem o jogador quando ele está fora do círculo.
- NPCs em frente às cabanas (cabanas são só visuais):
  - **Ancião Oromir** – capítulos/missões, ascensão de classe, lore.
  - **Gorm (Ferreiro)** – melhora equipamentos (+1 a +10, +8% stat principal por nível, custo exponencial).
  - **Sela (Mercadora)** – poções (tamanhos desbloqueados por ato).
  - **Vashti (Viajante)** – 6 equipamentos gerados pelo nível; "novo estoque" pago.
- Regeneração acelerada dentro da aldeia.

## 6. Estrutura narrativa
Guerra dos Cem Anos iniciada por Belial. Profecia do herói (nome do jogador). Em cada ato, 8–12 capítulos (escolhidos por seed entre os templates; chefe sempre último).
- Ato I: Floresta de Vorhal → **Belial** (revela que é 1 dos 4 pilares).
- Ato II: Deserto de Qaresh → **Mammon**.
- Ato III: Pântano Putrefato → **Asmodeus**.
- Ato IV: Montanhas de Khar-Thul → **Azazel**; aparição de **Lúcifer** que desafia o jogador.
- Ato V: Domínios de Lúcifer → **Lúcifer**. Final (jogo continua aberto para grind).

Tipos de capítulo: `kill` (N de um tipo / qualquer), `collect` (materiais droppados), `deliver` (falar com NPC), `explore` (descobrir POI), `elite` (campeão de um tipo), `boss`. Todos exceto `boss` são entregues ao Ancião.

## 7. Classes e evolução
| Classe | Evolução (nv 18, via Ancião) | Papel |
|---|---|---|
| Guerreiro | Cavaleiro da Ruína | melee tanque, AoE físico |
| Sacerdote | Inquisidor | híbrido, cura/escudo/holy |
| Necromante | Senhor das Almas | invocador/controle |
| Feiticeiro | Arquimago | caster de dano à distância |

Cada classe: ataque básico + 4 skills (desbloqueio por nível) + 1 skill de evolução. Evolução: +25% vida/mana/dano, novas camadas visuais (LPC) e 5ª skill. Ver `CONTENT.md`.

## 8. Atributos e fórmulas
- Força (dano melee), Destreza (armadura, crítico, vel. ataque), Vitalidade (vida), Energia (mana, dano mágico). 5 pontos por nível.
- Vida = (40 + VIT·g_hp + nível·6 + itens)·evo. Mana = (20 + ENE·g_mp + nível·3 + itens)·evo.
- Dano = (4 + nível·1.4 + 0.6·(FOR ou ENE) + 1.2·dano_arma)·evo; skill = dano·mult·(1 + nível·0.025)·(Grito 1.3).
- Redução = armadura / (armadura + 30 + nível·7), máx. 72%.
- XP p/ próximo nível = 80·nível^1.9.

## 9. Inimigos e dificuldade
- Nível do inimigo = faixa do ato interpolada por distância da aldeia (70%) e tier do tipo (30%). HP/dano ×(1 + 0.13·(nível − mín. do ato)).
- Elites (8% dos packs + acampamento marcado): ×3.5 HP, ×1.6 dano, tint dourado, loot melhor.
- Chefes: escala 2.1–2.8, aura, barra própria, música de boss, loot garantido (3 mágicos/raros + chance de único).
- IA: idle/wander → chase (aggro 7–12 tiles, só fora da aldeia) → attack (frame de impacto) → return (leash). Separação entre inimigos, deslize em obstáculos, ranged mantém 6 tiles.
- Morte: renasce na aldeia do ato, perde 10% do ouro; inimigos voltam ao ponto de origem.

## 10. Itens e economia
- 5 slots (arma, armadura, elmo, botas, anel). Raridades: normal/mágico (1 afixo)/raro (3 afixos)/único (tabela fixa). Preço de venda 25%.
- Poções: 60/220/700 pontos. Materiais de coleta por ato.
- Drops: ouro 65%, poção 14%, equipamento 16%×mult, material 45% quando o capítulo atual é de coleta.

## 11. Áudio
Totalmente sintetizado (Web Audio): trilhas por humor (menu, aldeia, 5 atos, boss) com drone + pad + arpejos + percussão; ~30 SFX (UI, golpes, magias, loot, portal, level-up, boss).

## 12. Persistência e meta
- 3 slots (PostgreSQL via `/api/saves`, fallback localStorage). Autosave 90s, ao concluir capítulo, viajar, ascender, pausar.
- Hall dos Heróis: cada chefe morto é registrado (`/api/deeds`) e exibido nos Créditos.
