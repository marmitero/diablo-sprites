# Conteúdo

## Atos
| Ato | Região | Aldeia | Níveis | Líquido | Coletável | Chefe (HP base / dano) |
|---|---|---|---|---|---|---|
| I | Floresta de Vorhal | Aldeia de Vorhal | 1–12 | água | Raiz de Cinza | Belial, Senhor das Mentiras (900 / 22) |
| II | Deserto de Qaresh | Oásis de Qaresh | 12–24 | água (oásis) | Fragmento de Ouro Amaldiçoado | Mammon, o Devorador de Ouro (3200 / 48) |
| III | Pântano Putrefato | Palafitas de Morr | 24–36 | ácido | Pétala de Sangue | Asmodeus, Príncipe da Luxúria (9000 / 95) |
| IV | Montanhas de Khar-Thul | Refúgio de Khar-Thul | 36–50 | gelo | Cristal de Ira | Azazel, o Flagelo da Ira (26000 / 190) |
| V | Domínios de Lúcifer | Bastião dos Condenados | 50–66 | lava | Essência Infernal | Lúcifer, Imperador do Submundo (80000 / 380) |

HP/dano de chefes escalam pelo nível máximo do ato (×(1+0.13·(nível−mín))).

## Capítulos (templates por ato; 8–12 escolhidos por seed, ordenados por tier, chefe por último)
Ato I: Os Mortos Caminham (kill zumbi 8) · Ervas para o Ferreiro (collect 6) · Entrega ao Ferreiro (deliver) · Ossos Inquietos (kill esqueleto 12) · O Altar Profano (explore altar) · Cultistas de Belial (kill 10) · O Capitão Desertor (elite bandit) · Suprimentos para o Mercador (collect 10) · A Pedra do Portal (explore waystone) · A Horda (kill any 30) · Entrega ao Viajante (deliver) · **A Fortaleza de Belial** (boss).

Ato II: Fome das Areias · Fragmentos de Ouro Amaldiçoado · A Forja do Oásis · Lacaios Dourados · O Templo Enterrado · Videntes Cegos · O Cobrador (elite) · Pedra do Portal · Tributo ao Mercador · Tempestade de Lâminas · **O Templo de Mammon**.

Ato III: Lodo Vivo · Pétalas Venenosas · Ao Ferreiro · Sussurros · O Jardim Negro · Cavaleiros Caídos · A Bruxa-Mãe (elite) · Pedra do Portal · Poções do Mercador · Carta ao Viajante · A Marcha do Lodo · **O Palácio de Asmodeus**.

Ato IV: Sangue na Neve · Cristais de Ira · A Forja Gelada · Espectros · O Trono de Gelo · Fúria Cega · O Campeão de Azazel (elite) · Pedra do Portal · Avalanche · **A Cidadela de Azazel** (→ aparição de Lúcifer).

Ato V: Portões de Ferro · Essência Infernal · A Última Forja · Magos do Abismo · O Coliseu · Anjos Caídos · O Senhor do Abismo (elite) · Pedra do Portal · Legião · **O Trono de Lúcifer**.

## Bestiário (HP base / dano / vel / XP; R = ranged)
- **I**: Zumbi Camponês 28/5/1.6/8 · Esqueleto 22/6/2.4/10 · Cultista de Belial (R) 20/7/2.0/12 · Desertor 34/8/2.6/14
- **II**: Ghoul das Areias 70/14 · Lacaio de Mammon 95/17 · Vidente da Areia (R) 60/20 · Esqueleto Dourado 85/16 · Saqueador das Dunas 80/15
- **III**: Miserável do Lodo 180/30 · Súcubo (R) 150/36 · Cavaleiro da Peste 260/40 · Esqueleto Pantanoso 170/32 · Bruxa do Brejo (R) 160/44
- **IV**: Orc do Gelo 480/70 · Espectro Gélido (R) 380/85 · Berserker de Azazel 620/95 · Cavaleiro Congelado 700/80 · Xamã da Nevasca (R) 420/110
- **V**: Cavaleiro Infernal 1400/160 · Mago Demoníaco (R) 1000/200 · Senhor dos Ossos 1600/170 · Anjo Caído 1300/190 · Senhor do Abismo 2400/220 (escala 1.4)

## Classes e skills
### Guerreiro → Cavaleiro da Ruína (slash, melee)
| # | Skill | Tipo | Mana | CD | Dano | Nv |
|---|---|---|---|---|---|---|
| 1 | Golpe Giratório | AoE raio 2.2 | 8 | 1.2 | 1.4× | 1 |
| 2 | Investida | dash 6 tiles, atordoa | 10 | 4 | 1.6× | 3 |
| 3 | Grito de Guerra | buff 10s (+30% dano, +15% red.) | 15 | 18 | – | 6 |
| 4 | Terremoto | AoE raio 3.5, atordoa, shake | 25 | 9 | 3.0× | 10 |
| 5 | Lâminas Fantasmas | aura 8s, tick 0.45s raio 2.6 | 35 | 20 | 0.9×/tick | 18 (evo) |

### Sacerdote → Inquisidor (slash, melee curto)
| 1 | Martelo Sagrado | projétil perfurante (3) | 6 | 0.6 | 1.3× | 1 |
| 2 | Cura | +35% vida | 20 | 8 | – | 2 |
| 3 | Luz Purificadora | nova raio 3.2 | 18 | 5 | 1.8× | 5 |
| 4 | Escudo Divino | absorve 50% vida máx. por 8s (70% do dano) | 22 | 16 | – | 9 |
| 5 | Juízo Final | pilares em até 8 inimigos (raio 6) | 40 | 18 | 3.5× | 18 (evo) |

### Necromante → Senhor das Almas (thrust, ranged)
| 1 | Lança de Osso | projétil perfurante (1) | 7 | 0.5 | 1.4× | 1 |
| 2 | Erguer Esqueleto | invoca (máx 3, 40s) | 15 | 3 | 0.7× | 2 |
| 3 | Explosão de Cadáver | até 3 corpos, raio 2.5 | 14 | 2 | 2.2× | 5 |
| 4 | Maldição | +50% dano sofrido 8s, raio 4 | 16 | 10 | – | 9 |
| 5 | Exército dos Mortos | 5 esqueletos de elite (45s) | 45 | 25 | 1.2× | 18 (evo) |

### Feiticeiro → Arquimago (spellcast, ranged)
| 1 | Bola de Fogo | projétil + splash 1.5 | 8 | 0.55 | 1.6× | 1 |
| 2 | Nova de Gelo | nova raio 3.5 + lentidão 3.5s | 16 | 5 | 1.2× | 3 |
| 3 | Raio em Cadeia | 5 saltos (−15% por salto) | 14 | 2.2 | 1.5× | 6 |
| 4 | Teleporte | 8 tiles | 12 | 3 | – | 9 |
| 5 | Meteoro | atraso 0.75s, raio 3, atordoa | 45 | 12 | 5× | 18 (evo) |

## Itens
- Bases por slot (nomes), afixos: 10 prefixos / 11 sufixos. Únicos: Lamento de Vorhal (arma), Coração de Mammon (anel), Véu de Asmodeus (elmo), Ira de Azazel (armadura), Passos do Imperador (botas).
- Raridade: 2% único, 10% raro, 30% mágico. Preço ×1/2.5/6/15.
- Melhoria do ferreiro: custo = (40 + nível·15)·1.6^upgrade, máx +10.

## NPCs
| NPC | Papel | Camadas LPC |
|---|---|---|
| Ancião Oromir | missões, ascensão, lore | body_light, legs_robe, torso_shirt_brown, hair_long_white, beard_white, wpn_wand |
| Gorm | ferreiro | body_tanned, feet_metal, legs_red, torso_leather, hands_leather, hair_shorthawk_gray, beard_gray, wpn_mace |
| Sela | mercadora de poções | body_light, legs_teal, torso_shirt_teal, hair_ponytail_blonde |
| Vashti | viajante (equipamentos) | body_dark, legs_magenta, torso_leather(+shoulders), hair_bedhead_raven, head_leather_cap, wpn_dagger |
