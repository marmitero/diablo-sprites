# Roadmap / Backlog

## Curto prazo (polimento do MVP)
- [ ] Pathfinding A* para clique-para-mover e IA (hoje: steering + deslize).
- [ ] Monstros não-humanoides (LPC Monsters: morcego, slime, aranha, lobo) e animações de voo.
- [ ] Mais sheets de props por bioma (cactos, estalagmites, ossos, cristais) em vez de re-skin por matiz.
- [ ] Cinto de poções (4 slots) e atalhos configuráveis; remapeamento de teclas nas Opções.
- [ ] Tooltip de comparação de itens (equipado vs. novo) e botão "vender tudo normal".
- [ ] Balanceamento por classe (DPS alvo por ato), curva de XP e preços.

## Médio prazo
- [ ] Árvore de talentos (pontos de skill, ranks por skill, sinergias).
- [ ] Afixos de elite (Extra Rápido, Vampírico, Aura de Fogo, Imune a X) e packs de campeões.
- [ ] Eventos de mundo por seed (invasão da aldeia, baú amaldiçoado, mercador errante).
- [ ] Masmorras opcionais (cavernas/criptas) geradas por BSP com portais próprios.
- [ ] Ciclo dia/noite e clima por bioma (neve, cinzas, névoa do pântano).
- [ ] Dificuldades Pesadelo/Inferno (NG+) com loot exclusivo.

## Longo prazo
- [ ] Co-op online (estado autoritativo no servidor, seeds compartilhadas).
- [ ] Ranking/leaderboard por seed (tempo até Belial, mortes).
- [ ] Editor de seeds/mapas e compartilhamento de runs.
- [ ] Localização (en-US/es-ES).

## Dívidas técnicas conhecidas
- `chromaKey` em runtime custa ~200ms no boot; pode ser pré-processado em build.
- `play.ts` concentra simulação + render; separar `systems/` (combat, ai, loot) quando crescer.
- Save não guarda inimigos mortos nem drops no chão (por design, mas documentar para o jogador).
