# Pilares do Inferno — Documentação

RPG isométrico de ação em navegador (100% `<canvas>`), inspirado em Diablo 2, com arte chibi/pixel, mundo procedural por seed e persistência em PostgreSQL.

| Documento | Conteúdo |
|---|---|
| [GDD.md](GDD.md) | Game Design Document: pilares, loop, progressão, classes, dificuldade, economia |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Arquitetura de código, pipeline de assets, geração de mapa, formato de save, API |
| [CONTENT.md](CONTENT.md) | Tabelas de conteúdo: atos, capítulos, bestiário, chefes, skills, itens, NPCs |
| [ASSETS.md](ASSETS.md) | Origem/licença de cada arte, layout dos spritesheets LPC, como adicionar sprites |
| [ROADMAP.md](ROADMAP.md) | Backlog priorizado para expansão |

## Rodando
- `npm run dev` / `npm run build && npm start`
- Banco: `DATABASE_URL` no `.env`; schema em `src/db/schema.ts` (`npx drizzle-kit push`).
- Debug: no console do navegador, `window.__game.scene` expõe a cena atual (player, enemies, region...).

## Controles
| Ação | Tecla |
|---|---|
| Mover | WASD / setas / clique esquerdo (segurar para seguir o cursor) |
| Atacar | Clique esquerdo no inimigo (Shift = atacar parado) |
| Habilidades | 1–5 (no cursor) • botão direito = habilidade ativa • roda do mouse troca |
| Poções | Q (vida) / E (mana) |
| Painéis | I inventário • C personagem • K habilidades • J missões • M/Tab mapa • ESC pausa |
| NPCs / Portal | Clique quando próximo |
