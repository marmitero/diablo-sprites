"use client";
import { useEffect, useRef } from "react";

/**
 * Mounts the full-canvas game. Everything (menus, HUD, world) is rendered
 * inside this single <canvas>; no DOM/CSS UI is used for game screens.
 */
export default function GameCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let dispose: (() => void) | undefined;
    let cancelled = false;
    import("@/game/Game").then(({ Game }) => {
      if (cancelled || !ref.current) return;
      const game = new Game(ref.current);
      game.start();
      (window as unknown as { __game?: unknown }).__game = game; // debug handle
      dispose = () => game.destroy();
    });
    return () => {
      cancelled = true;
      dispose?.();
    };
  }, []);
  return (
    <canvas
      ref={ref}
      style={{ display: "block", width: "100vw", height: "100vh", cursor: "none", imageRendering: "auto" }}
    />
  );
}
