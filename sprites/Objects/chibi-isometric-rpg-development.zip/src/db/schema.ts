import { integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Save slots (1..3). `data` holds the full serialized player/progress state
 * (see docs/ARCHITECTURE.md -> "Save format").
 */
export const saves = pgTable("saves", {
  id: serial("id").primaryKey(),
  slot: integer("slot").notNull().unique(),
  playerName: text("player_name").notNull(),
  className: text("class_name").notNull(),
  level: integer("level").notNull().default(1),
  act: integer("act").notNull().default(1),
  seed: text("seed").notNull(),
  playtime: integer("playtime").notNull().default(0),
  data: jsonb("data").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Hall of Heroes: every boss kill is recorded here for a global leaderboard. */
export const heroDeeds = pgTable("hero_deeds", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  className: text("class_name").notNull(),
  level: integer("level").notNull(),
  bossName: text("boss_name").notNull(),
  act: integer("act").notNull(),
  seed: text("seed").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
