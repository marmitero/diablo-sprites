import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { heroDeeds } from "@/db/schema";

export const dynamic = "force-dynamic";

/** GET /api/deeds -> last 20 boss kills (Hall of Heroes shown in Credits). */
export async function GET() {
  try {
    const rows = await db.select().from(heroDeeds).orderBy(desc(heroDeeds.createdAt)).limit(20);
    return NextResponse.json({ ok: true, deeds: rows });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

/** POST /api/deeds  body: { playerName, className, level, bossName, act, seed } */
export async function POST(req: Request) {
  try {
    const b = await req.json();
    await db.insert(heroDeeds).values({
      playerName: String(b.playerName ?? "?"),
      className: String(b.className ?? "?"),
      level: Number(b.level ?? 1),
      bossName: String(b.bossName ?? "?"),
      act: Number(b.act ?? 1),
      seed: String(b.seed ?? "0"),
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
