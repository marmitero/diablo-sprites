import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { saves } from "@/db/schema";

export const dynamic = "force-dynamic";

/** GET /api/saves -> summary of the 3 slots (full data included for loading). */
export async function GET() {
  try {
    const rows = await db.select().from(saves).orderBy(asc(saves.slot));
    return NextResponse.json({ ok: true, saves: rows });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

/** PUT /api/saves  body: { slot, playerName, className, level, act, seed, playtime, data } */
export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const slot = Number(body.slot);
    if (!(slot >= 1 && slot <= 3)) {
      return NextResponse.json({ ok: false, error: "slot must be 1..3" }, { status: 400 });
    }
    const values = {
      slot,
      playerName: String(body.playerName ?? "Herói"),
      className: String(body.className ?? "warrior"),
      level: Number(body.level ?? 1),
      act: Number(body.act ?? 1),
      seed: String(body.seed ?? "0"),
      playtime: Number(body.playtime ?? 0),
      data: body.data ?? {},
      updatedAt: new Date(),
    };
    await db
      .insert(saves)
      .values(values)
      .onConflictDoUpdate({ target: saves.slot, set: values });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

/** DELETE /api/saves?slot=N */
export async function DELETE(req: Request) {
  try {
    const slot = Number(new URL(req.url).searchParams.get("slot"));
    if (!(slot >= 1 && slot <= 3)) {
      return NextResponse.json({ ok: false, error: "slot must be 1..3" }, { status: 400 });
    }
    await db.delete(saves).where(eq(saves.slot, slot));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
