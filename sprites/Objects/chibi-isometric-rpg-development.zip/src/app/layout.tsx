import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pilares do Inferno — RPG Isométrico",
  description: "Um action RPG isométrico chibi inspirado em Diablo 2, 100% canvas, mundo procedural com seed.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{ margin: 0, background: "#000", overflow: "hidden" }}>{children}</body>
    </html>
  );
}
