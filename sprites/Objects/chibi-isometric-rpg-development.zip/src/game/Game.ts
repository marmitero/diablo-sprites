/**
 * Game shell: canvas loop, scaled input (1280x720 virtual resolution, letterboxed), scene stack,
 * fade transitions and persistence (REST -> PostgreSQL, with localStorage fallback).
 */
import { loadAll } from "./core/assets";
import { audio } from "./core/audio";
import { fancyText, fade, text, VH, VW, cursor, bar } from "./core/ui";
import type { SaveData } from "./world/entities";
import { setUidFloor } from "./data/items";

export interface Scene {
  enter?(): void;
  exit?(): void;
  update(dt: number): void;
  render(ctx: CanvasRenderingContext2D): void;
  onMouseMove?(x: number, y: number): void;
  onMouseDown?(x: number, y: number, button: number): void;
  onMouseUp?(x: number, y: number, button: number): void;
  onKeyDown?(key: string, e: KeyboardEvent): void;
  onKeyUp?(key: string): void;
  onWheel?(dy: number): void;
  cursorMode?: () => "normal" | "attack" | "talk" | "hand";
}

export interface SaveSummary { slot: number; playerName: string; className: string; level: number; act: number; seed: string; playtime: number; data: SaveData }

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  scene: Scene | null = null;
  mouse = { x: 0, y: 0, down: [false, false, false], inside: true };
  keys = new Set<string>();
  time = 0;
  private raf = 0;
  private last = 0;
  private scaleF = 1;
  private offX = 0;
  private offY = 0;
  private fadeA = 0;
  private fadeDir = 0;
  private fadeNext: Scene | null = null;
  private fadeSpeed = 2;
  loadProgress = 0;
  loadLabel = "";
  loaded = false;
  currentSlot = 1;
  running = false;
  private handlers: Array<[string, EventListener, EventTarget]> = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    canvas.width = VW;
    canvas.height = VH;
  }

  start() {
    this.running = true;
    this.resize();
    const on = <K extends keyof WindowEventMap>(target: EventTarget, ev: K | string, fn: (e: Event) => void) => {
      target.addEventListener(ev, fn as EventListener);
      this.handlers.push([ev, fn as EventListener, target]);
    };
    on(window, "resize", () => this.resize());
    on(this.canvas, "mousemove", (e) => { this.updMouse(e as MouseEvent); this.scene?.onMouseMove?.(this.mouse.x, this.mouse.y); });
    on(this.canvas, "mousedown", (e) => { const me = e as MouseEvent; e.preventDefault(); audio.init(); audio.resume(); this.updMouse(me); this.mouse.down[me.button] = true; this.scene?.onMouseDown?.(this.mouse.x, this.mouse.y, me.button); });
    on(window, "mouseup", (e) => { const me = e as MouseEvent; this.mouse.down[me.button] = false; this.scene?.onMouseUp?.(this.mouse.x, this.mouse.y, me.button); });
    on(this.canvas, "contextmenu", (e) => e.preventDefault());
    on(this.canvas, "wheel", (e) => { e.preventDefault(); this.scene?.onWheel?.((e as WheelEvent).deltaY); });
    on(window, "keydown", (e) => {
      const ke = e as KeyboardEvent;
      if (["Tab", "F1", "F5"].includes(ke.key) === false && (ke.key.startsWith("Arrow") || ke.key === " ")) ke.preventDefault();
      audio.init();
      audio.resume();
      this.keys.add(ke.key.length === 1 ? ke.key.toLowerCase() : ke.key);
      this.scene?.onKeyDown?.(ke.key.length === 1 ? ke.key.toLowerCase() : ke.key, ke);
    });
    on(window, "keyup", (e) => { const ke = e as KeyboardEvent; const k = ke.key.length === 1 ? ke.key.toLowerCase() : ke.key; this.keys.delete(k); this.scene?.onKeyUp?.(k); });
    on(window, "blur", () => this.keys.clear());
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
    // boot: load assets then go to menu
    loadAll((p, l) => { this.loadProgress = p; this.loadLabel = l; })
      .then(async () => {
        const { MenuScene } = await import("./scenes/menu");
        this.loaded = true;
        this.goto(new MenuScene(this), 1.5);
      })
      .catch((err) => { this.loadLabel = "Erro ao carregar: " + err; });
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const [ev, fn, t] of this.handlers) t.removeEventListener(ev, fn);
    audio.stopMusic();
  }

  private resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.scaleF = Math.min(w / VW, h / VH);
    this.offX = (w - VW * this.scaleF) / 2;
    this.offY = (h - VH * this.scaleF) / 2;
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.canvas.style.background = "#000";
  }
  private updMouse(e: MouseEvent) {
    const r = this.canvas.getBoundingClientRect();
    this.mouse.x = (e.clientX - r.left - this.offX) / this.scaleF;
    this.mouse.y = (e.clientY - r.top - this.offY) / this.scaleF;
  }

  /** Fade out, swap scene, fade in. */
  goto(scene: Scene, speed = 2.5) {
    this.fadeNext = scene;
    this.fadeDir = 1;
    this.fadeSpeed = speed;
    if (!this.scene) { this.fadeA = 1; }
  }
  private swapScene() {
    this.scene?.exit?.();
    this.scene = this.fadeNext;
    this.fadeNext = null;
    this.scene?.enter?.();
  }

  private loop = (now: number) => {
    if (!this.running) return;
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.time += dt;
    // transitions
    if (this.fadeDir === 1) {
      this.fadeA += dt * this.fadeSpeed;
      if (this.fadeA >= 1) { this.fadeA = 1; this.swapScene(); this.fadeDir = -1; }
    } else if (this.fadeDir === -1) {
      this.fadeA -= dt * this.fadeSpeed;
      if (this.fadeA <= 0) { this.fadeA = 0; this.fadeDir = 0; }
    }
    if (this.scene && this.fadeDir !== 1) this.scene.update(dt);
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = true;
    if (this.scene) this.scene.render(ctx);
    else this.renderLoading(ctx);
    fade(ctx, this.fadeA);
    if (this.mouse.x >= 0 && this.mouse.x <= VW && this.mouse.y >= 0 && this.mouse.y <= VH) cursor(ctx, this.mouse.x, this.mouse.y, this.scene?.cursorMode?.() ?? "normal");
    this.raf = requestAnimationFrame(this.loop);
  };

  private renderLoading(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = "#06040a";
    ctx.fillRect(0, 0, VW, VH);
    // embers
    for (let i = 0; i < 40; i++) {
      const t = (this.time * 0.3 + i * 0.37) % 1;
      const x = ((i * 193) % VW) + Math.sin(this.time + i) * 20;
      const y = VH - t * VH;
      ctx.globalAlpha = (1 - t) * 0.7;
      ctx.fillStyle = i % 3 === 0 ? "#ffb347" : "#ff5a1a";
      ctx.beginPath(); ctx.arc(x, y, 2 + (i % 3), 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    fancyText(ctx, "PILARES DO INFERNO", VW / 2, VH / 2 - 40, { size: 54, align: "center", glow: "#ff6a1a", wave: 4, time: this.time });
    text(ctx, "Invocando o mundo...", VW / 2, VH / 2 + 10, 18, "#b8a080", "center");
    bar(ctx, { x: VW / 2 - 200, y: VH / 2 + 30, w: 400, h: 16 }, this.loadProgress, "#c9402a");
    text(ctx, this.loadLabel.slice(0, 40), VW / 2, VH / 2 + 70, 13, "#776655", "center");
    text(ctx, "Sprites de personagens: Liberated Pixel Cup (CC-BY-SA 3.0 / GPL 3.0)", VW / 2, VH - 24, 12, "#554433", "center");
  }

  /* ---------------- persistence ---------------- */
  async listSaves(): Promise<SaveSummary[]> {
    try {
      const r = await fetch("/api/saves", { cache: "no-store" });
      const j = await r.json();
      if (j.ok) return j.saves as SaveSummary[];
    } catch { /* fallthrough */ }
    const out: SaveSummary[] = [];
    for (let s = 1; s <= 3; s++) {
      const raw = localStorage.getItem("pdi_save_" + s);
      if (raw) { const d = JSON.parse(raw) as SaveData; out.push({ slot: s, playerName: d.name, className: d.classId, level: d.level, act: d.act, seed: d.seed, playtime: d.playtime, data: d }); }
    }
    return out;
  }
  async saveToSlot(slot: number, data: SaveData): Promise<boolean> {
    localStorage.setItem("pdi_save_" + slot, JSON.stringify(data));
    try {
      const r = await fetch("/api/saves", {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slot, playerName: data.name, className: data.classId, level: data.level, act: data.act, seed: data.seed, playtime: Math.floor(data.playtime), data }),
      });
      return (await r.json()).ok === true;
    } catch { return false; }
  }
  async deleteSlot(slot: number) {
    localStorage.removeItem("pdi_save_" + slot);
    try { await fetch(`/api/saves?slot=${slot}`, { method: "DELETE" }); } catch { /* */ }
  }
  async recordDeed(d: SaveData, bossName: string) {
    try { await fetch("/api/deeds", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerName: d.name, className: d.classId, level: d.level, bossName, act: d.act, seed: d.seed }) }); } catch { /* */ }
  }
  async listDeeds(): Promise<Array<{ playerName: string; className: string; level: number; bossName: string; act: number }>> {
    try { const r = await fetch("/api/deeds", { cache: "no-store" }); const j = await r.json(); return j.ok ? j.deeds : []; } catch { return []; }
  }

  /** Restores UID floor for items after loading a save. */
  prepareLoaded(d: SaveData) {
    let max = 0;
    for (const it of d.inventory) max = Math.max(max, it.uid);
    for (const k of Object.keys(d.equipment)) { const it = d.equipment[k as keyof typeof d.equipment]; if (it) max = Math.max(max, it.uid); }
    setUidFloor(max);
  }
}
