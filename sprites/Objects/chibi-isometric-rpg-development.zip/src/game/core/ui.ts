/**
 * Canvas-only UI toolkit. No DOM/CSS. All panels, buttons, text effects, orbs and the cursor are drawn here.
 */
export const VW = 1280;
export const VH = 720;

export const FONT_TITLE = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
export const FONT_BODY = 'Georgia, "Times New Roman", serif';

export interface Rect { x: number; y: number; w: number; h: number }
export const inRect = (px: number, py: number, r: Rect) => px >= r.x && py >= r.y && px <= r.x + r.w && py <= r.y + r.h;

export interface FancyOpts {
  size?: number;
  align?: CanvasTextAlign;
  baseline?: CanvasTextBaseline;
  colors?: [string, string]; // gradient top -> bottom
  stroke?: string;
  strokeW?: number;
  glow?: string;
  glowSize?: number;
  wave?: number; // amplitude px (animated letters)
  time?: number;
  font?: string;
  alpha?: number;
  bold?: boolean;
}

/** Ornate gradient text with stroke/glow and optional per-letter wave animation. */
export function fancyText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, o: FancyOpts = {}) {
  const size = o.size ?? 24;
  const font = `${o.bold === false ? "" : "bold "}${size}px ${o.font ?? FONT_TITLE}`;
  ctx.save();
  ctx.font = font;
  ctx.textAlign = o.align ?? "left";
  ctx.textBaseline = o.baseline ?? "alphabetic";
  ctx.globalAlpha = o.alpha ?? 1;
  const draw = (t: string, px: number, py: number) => {
    const grad = ctx.createLinearGradient(0, py - size, 0, py + size * 0.25);
    const [c0, c1] = o.colors ?? ["#ffe9a8", "#b8862b"];
    grad.addColorStop(0, c0);
    grad.addColorStop(1, c1);
    if (o.glow) {
      ctx.shadowColor = o.glow;
      ctx.shadowBlur = o.glowSize ?? 12;
    }
    ctx.lineJoin = "round";
    ctx.strokeStyle = o.stroke ?? "#1a0b05";
    ctx.lineWidth = o.strokeW ?? Math.max(2, size / 8);
    ctx.strokeText(t, px, py);
    ctx.shadowBlur = 0;
    ctx.fillStyle = grad;
    ctx.fillText(t, px, py);
  };
  if (o.wave && o.wave > 0) {
    const total = ctx.measureText(text).width;
    let cx = x;
    if (ctx.textAlign === "center") cx = x - total / 2;
    else if (ctx.textAlign === "right") cx = x - total;
    ctx.textAlign = "left";
    const time = o.time ?? 0;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      const w = ctx.measureText(ch).width;
      const dy = Math.sin(time * 3 + i * 0.5) * o.wave;
      draw(ch, cx, y + dy);
      cx += w;
    }
  } else draw(text, x, y);
  ctx.restore();
}

export function text(ctx: CanvasRenderingContext2D, t: string, x: number, y: number, size = 16, color = "#e8dcc0", align: CanvasTextAlign = "left", font = FONT_BODY, shadow = true) {
  ctx.save();
  ctx.font = `${size}px ${font}`;
  ctx.textAlign = align;
  ctx.textBaseline = "alphabetic";
  if (shadow) {
    ctx.fillStyle = "rgba(0,0,0,0.8)";
    ctx.fillText(t, x + 1, y + 1);
  }
  ctx.fillStyle = color;
  ctx.fillText(t, x, y);
  ctx.restore();
}

export function wrapText(ctx: CanvasRenderingContext2D, t: string, maxW: number, size = 16, font = FONT_BODY): string[] {
  ctx.save();
  ctx.font = `${size}px ${font}`;
  const words = t.split(" ");
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const test = cur ? cur + " " + w : w;
    if (ctx.measureText(test).width > maxW && cur) {
      lines.push(cur);
      cur = w;
    } else cur = test;
  }
  if (cur) lines.push(cur);
  ctx.restore();
  return lines;
}

/** Stone/iron ornate panel with gold trim and corner rivets. */
export function panel(ctx: CanvasRenderingContext2D, r: Rect, opts: { alpha?: number; title?: string; dark?: boolean } = {}) {
  ctx.save();
  ctx.globalAlpha = opts.alpha ?? 0.96;
  const g = ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
  g.addColorStop(0, opts.dark ? "#13100d" : "#2a221b");
  g.addColorStop(1, opts.dark ? "#090705" : "#171210");
  ctx.fillStyle = g;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  // inner texture lines
  ctx.strokeStyle = "rgba(255,255,255,0.03)";
  for (let y = r.y + 6; y < r.y + r.h; y += 7) {
    ctx.beginPath();
    ctx.moveTo(r.x + 4, y);
    ctx.lineTo(r.x + r.w - 4, y);
    ctx.stroke();
  }
  // borders
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#5a4322";
  ctx.strokeRect(r.x + 1.5, r.y + 1.5, r.w - 3, r.h - 3);
  ctx.lineWidth = 1;
  ctx.strokeStyle = "#c9a24a";
  ctx.strokeRect(r.x + 5.5, r.y + 5.5, r.w - 11, r.h - 11);
  ctx.strokeStyle = "#000";
  ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
  // rivets
  for (const [cx, cy] of [[r.x + 9, r.y + 9], [r.x + r.w - 9, r.y + 9], [r.x + 9, r.y + r.h - 9], [r.x + r.w - 9, r.y + r.h - 9]]) {
    const rg = ctx.createRadialGradient(cx - 1, cy - 1, 0, cx, cy, 4);
    rg.addColorStop(0, "#ffe9a8");
    rg.addColorStop(1, "#7a5a1e");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  if (opts.title) {
    const tw = Math.min(r.w - 40, opts.title.length * 14 + 40);
    const tx = r.x + r.w / 2;
    ctx.save();
    const tg = ctx.createLinearGradient(tx - tw / 2, 0, tx + tw / 2, 0);
    tg.addColorStop(0, "rgba(90,67,34,0)");
    tg.addColorStop(0.5, "#5a4322");
    tg.addColorStop(1, "rgba(90,67,34,0)");
    ctx.fillStyle = tg;
    ctx.fillRect(tx - tw / 2, r.y - 2, tw, 30);
    ctx.restore();
    fancyText(ctx, opts.title, tx, r.y + 20, { size: 20, align: "center" });
  }
}

/** Ornate button (stone plate with metal frame). */
export function button(ctx: CanvasRenderingContext2D, r: Rect, label: string, hovered: boolean, opts: { disabled?: boolean; size?: number; time?: number; active?: boolean } = {}) {
  ctx.save();
  const dis = !!opts.disabled;
  const g = ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
  if (hovered && !dis) {
    g.addColorStop(0, "#6a3a14");
    g.addColorStop(0.5, "#3b1d0c");
    g.addColorStop(1, "#5a2d10");
  } else if (opts.active) {
    g.addColorStop(0, "#4a3a1a");
    g.addColorStop(1, "#2a1f0e");
  } else {
    g.addColorStop(0, "#3a2e22");
    g.addColorStop(0.5, "#1f1812");
    g.addColorStop(1, "#2c231a");
  }
  ctx.fillStyle = g;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  // bevel
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.beginPath(); ctx.moveTo(r.x + 2, r.y + r.h - 2); ctx.lineTo(r.x + 2, r.y + 2); ctx.lineTo(r.x + r.w - 2, r.y + 2); ctx.stroke();
  ctx.strokeStyle = "rgba(0,0,0,0.5)";
  ctx.beginPath(); ctx.moveTo(r.x + r.w - 2, r.y + 2); ctx.lineTo(r.x + r.w - 2, r.y + r.h - 2); ctx.lineTo(r.x + 2, r.y + r.h - 2); ctx.stroke();
  ctx.lineWidth = 2;
  ctx.strokeStyle = hovered && !dis ? "#ffcf5a" : "#8a6a2a";
  ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
  if (hovered && !dis) {
    ctx.shadowColor = "#ff9a2a";
    ctx.shadowBlur = 18;
    ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
    ctx.shadowBlur = 0;
    // side flames markers
    const t = opts.time ?? 0;
    for (const sx of [r.x - 14, r.x + r.w + 14]) {
      ctx.fillStyle = "#ffb347";
      ctx.beginPath();
      const s = 5 + Math.sin(t * 8) * 1.5;
      ctx.moveTo(sx, r.y + r.h / 2 - s);
      ctx.lineTo(sx + (sx < r.x ? s : -s), r.y + r.h / 2);
      ctx.lineTo(sx, r.y + r.h / 2 + s);
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.restore();
  fancyText(ctx, label, r.x + r.w / 2, r.y + r.h / 2 + (opts.size ?? 22) * 0.36, {
    size: opts.size ?? 22,
    align: "center",
    colors: dis ? ["#777", "#444"] : hovered ? ["#fff6d8", "#ffcf5a"] : ["#f0dca0", "#b8862b"],
    alpha: dis ? 0.7 : 1,
  });
}

/** Diablo-style liquid orb. */
export function orb(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, ratio: number, color: [string, string], time: number, label: string) {
  ctx.save();
  // socket
  const sg = ctx.createRadialGradient(cx, cy, r * 0.6, cx, cy, r + 10);
  sg.addColorStop(0, "#2b241c");
  sg.addColorStop(1, "#0a0806");
  ctx.fillStyle = sg;
  ctx.beginPath(); ctx.arc(cx, cy, r + 10, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#8a6a2a"; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(cx, cy, r + 8, 0, Math.PI * 2); ctx.stroke();
  // glass bg
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = "#0b0608"; ctx.fill();
  ctx.save();
  ctx.clip();
  const level = cy + r - ratio * 2 * r;
  const lg = ctx.createLinearGradient(0, level, 0, cy + r);
  lg.addColorStop(0, color[0]);
  lg.addColorStop(1, color[1]);
  ctx.fillStyle = lg;
  ctx.beginPath();
  ctx.moveTo(cx - r, cy + r);
  ctx.lineTo(cx - r, level);
  for (let x = -r; x <= r; x += 4) ctx.lineTo(cx + x, level + Math.sin(time * 2.5 + x * 0.08) * 3);
  ctx.lineTo(cx + r, cy + r);
  ctx.closePath();
  ctx.fill();
  // bubbles
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  for (let i = 0; i < 5; i++) {
    const by = cy + r - ((time * 20 + i * 37) % (2 * r));
    if (by > level) { ctx.beginPath(); ctx.arc(cx - r / 2 + i * r / 2.5, by, 2 + (i % 2), 0, Math.PI * 2); ctx.fill(); }
  }
  // shine
  const hg = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, 0, cx - r * 0.35, cy - r * 0.4, r * 0.8);
  hg.addColorStop(0, "rgba(255,255,255,0.35)");
  hg.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = hg;
  ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
  ctx.restore();
  ctx.strokeStyle = "rgba(255,255,255,0.15)"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(cx, cy, r - 1, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
  text(ctx, label, cx, cy + 5, 14, "#fff", "center");
}

export function bar(ctx: CanvasRenderingContext2D, r: Rect, ratio: number, color: string, bg = "#1a1210", border = "#6a4a1a") {
  ctx.save();
  ctx.fillStyle = bg;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  ctx.fillStyle = color;
  ctx.fillRect(r.x + 1, r.y + 1, Math.max(0, (r.w - 2) * Math.min(1, Math.max(0, ratio))), r.h - 2);
  ctx.strokeStyle = border;
  ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
  ctx.restore();
}

export function cursor(ctx: CanvasRenderingContext2D, x: number, y: number, mode: "normal" | "attack" | "talk" | "hand" = "normal") {
  ctx.save();
  ctx.translate(x, y);
  ctx.shadowColor = "rgba(0,0,0,0.8)";
  ctx.shadowBlur = 4;
  if (mode === "attack") {
    ctx.strokeStyle = "#ff5a3a"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 9, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-13, 0); ctx.lineTo(-5, 0); ctx.moveTo(5, 0); ctx.lineTo(13, 0); ctx.moveTo(0, -13); ctx.lineTo(0, -5); ctx.moveTo(0, 5); ctx.lineTo(0, 13); ctx.stroke();
  } else if (mode === "talk" || mode === "hand") {
    ctx.fillStyle = mode === "talk" ? "#ffe08a" : "#e8dcc0";
    ctx.strokeStyle = "#2a1a08"; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, 18); ctx.lineTo(5, 14); ctx.lineTo(9, 22); ctx.lineTo(13, 20); ctx.lineTo(9, 12); ctx.lineTo(15, 11); ctx.closePath();
    ctx.fill(); ctx.stroke();
    if (mode === "talk") { ctx.fillStyle = "#ffe08a"; ctx.font = "bold 14px serif"; ctx.fillText("?", 14, 4); }
  } else {
    // gauntlet-like arrow
    const g = ctx.createLinearGradient(0, 0, 14, 20);
    g.addColorStop(0, "#ffe9a8"); g.addColorStop(1, "#9a6e22");
    ctx.fillStyle = g;
    ctx.strokeStyle = "#1a0b05"; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, 20); ctx.lineTo(5, 15); ctx.lineTo(9, 23); ctx.lineTo(13, 21); ctx.lineTo(9, 13); ctx.lineTo(16, 12); ctx.closePath();
    ctx.fill(); ctx.stroke();
  }
  ctx.restore();
}

/** Simple particle used by menus and VFX. */
export interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; size: number; color: string; glow?: boolean; grav?: number }

export function updateParticles(ps: Particle[], dt: number) {
  for (let i = ps.length - 1; i >= 0; i--) {
    const p = ps[i];
    p.life -= dt;
    if (p.life <= 0) { ps.splice(i, 1); continue; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    if (p.grav) p.vy += p.grav * dt;
  }
}
export function drawParticles(ctx: CanvasRenderingContext2D, ps: Particle[], ox = 0, oy = 0) {
  ctx.save();
  for (const p of ps) {
    const a = Math.max(0, Math.min(1, p.life / p.maxLife));
    ctx.globalAlpha = a;
    ctx.fillStyle = p.color;
    if (p.glow) { ctx.shadowColor = p.color; ctx.shadowBlur = 8; }
    ctx.beginPath();
    ctx.arc(p.x + ox, p.y + oy, p.size * (0.5 + a * 0.5), 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }
  ctx.restore();
}

export function fade(ctx: CanvasRenderingContext2D, alpha: number, color = "#000") {
  if (alpha <= 0) return;
  ctx.save();
  ctx.globalAlpha = Math.min(1, alpha);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, VW, VH);
  ctx.restore();
}

export function vignette(ctx: CanvasRenderingContext2D, strength = 0.6) {
  const g = ctx.createRadialGradient(VW / 2, VH / 2, VH * 0.35, VW / 2, VH / 2, VH * 0.85);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, `rgba(0,0,0,${strength})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, VW, VH);
}
