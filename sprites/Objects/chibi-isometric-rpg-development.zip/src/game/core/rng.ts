/** Deterministic PRNG utilities. Every procedural system receives an RNG derived from the run seed. */

export function hashString(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

export class RNG {
  private s: number;
  constructor(seed: number | string) {
    this.s = (typeof seed === "string" ? hashString(seed) : seed >>> 0) || 1;
  }
  /** mulberry32 */
  next(): number {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number): number {
    return a + (b - a) * this.next();
  }
  int(a: number, b: number): number {
    return Math.floor(this.range(a, b + 1));
  }
  chance(p: number): boolean {
    return this.next() < p;
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  shuffle<T>(arr: T[]): T[] {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  fork(label: string): RNG {
    return new RNG(hashString(label + ":" + Math.floor(this.next() * 1e9)));
  }
}

/** Smooth value noise, seeded. Returns [0,1]. */
export class Noise2D {
  private seed: number;
  constructor(seed: number) {
    this.seed = seed >>> 0;
  }
  private hash(x: number, y: number): number {
    let h = Math.imul(x, 374761393) + Math.imul(y, 668265263) + this.seed;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  at(x: number, y: number): number {
    const x0 = Math.floor(x), y0 = Math.floor(y);
    const fx = x - x0, fy = y - y0;
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const a = this.hash(x0, y0), b = this.hash(x0 + 1, y0);
    const c = this.hash(x0, y0 + 1), d = this.hash(x0 + 1, y0 + 1);
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  }
  fbm(x: number, y: number, octaves = 4): number {
    let v = 0, amp = 0.5, f = 1, sum = 0;
    for (let i = 0; i < octaves; i++) {
      v += this.at(x * f, y * f) * amp;
      sum += amp;
      amp *= 0.5;
      f *= 2;
    }
    return v / sum;
  }
}

export function makeSeedString(): string {
  const words = ["ASH", "BONE", "RUIN", "HEX", "VEIL", "EMBER", "GRIM", "DUSK", "WRATH", "VOID"];
  const w = words[Math.floor(Math.random() * words.length)];
  return `${w}-${Math.floor(Math.random() * 9000 + 1000)}`;
}
