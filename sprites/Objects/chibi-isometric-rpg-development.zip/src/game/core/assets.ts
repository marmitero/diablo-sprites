/**
 * Asset pipeline (runtime):
 *  - Loads hand-made art (AI-painted PNG/JPG + imported LPC spritesheets).
 *  - Chroma-keys pure green (#00FF00) backgrounds into real alpha.
 *  - Slices prop sheets (grid -> trimmed canvases).
 *  - Composes layered LPC character sheets (body + hair + armor + weapon) once and caches them.
 *  - Generates the ground tileset (textured diamonds + 16-case autotile masks for paths / liquids).
 *
 * LPC sheet layout (832x1344, 64px frames, 13 cols x 21 rows):
 *  rows 0-3 spellcast(7) | 4-7 thrust(8) | 8-11 walk(9) | 12-15 slash(6) | 16-19 shoot(13) | 20 hurt(6)
 *  direction order inside a block: up, left, down, right.
 */
import { Noise2D, RNG } from "./rng";

export type Canvas = HTMLCanvasElement;

export const TILE_W = 64;
export const TILE_H = 32;

export interface Sheet {
  img: Canvas;
  oversize?: Canvas; // 192px frames (slash: 6 cols / thrust: 8 cols)
  oversizeAnim?: "slash" | "thrust";
}

export const ANIM = {
  spellcast: { row: 0, frames: 7 },
  thrust: { row: 4, frames: 8 },
  walk: { row: 8, frames: 9 },
  slash: { row: 12, frames: 6 },
  shoot: { row: 16, frames: 13 },
  hurt: { row: 20, frames: 6 },
} as const;
export type AnimName = keyof typeof ANIM;
/** LPC direction rows: 0 up, 1 left, 2 down, 3 right */
export type Dir4 = 0 | 1 | 2 | 3;

export function makeCanvas(w: number, h: number): Canvas {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.floor(w));
  c.height = Math.max(1, Math.floor(h));
  return c;
}

export function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = () => rej(new Error("fail " + url));
    i.src = url;
  });
}

/** Removes a flat green background and despills edges. */
export function chromaKey(img: CanvasImageSource & { width: number; height: number }): Canvas {
  const c = makeCanvas(img.width, img.height);
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0);
  const id = ctx.getImageData(0, 0, c.width, c.height);
  const d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const greenness = g - Math.max(r, b);
    if (greenness > 80 && g > 120) {
      d[i + 3] = 0;
    } else if (greenness > 25) {
      const t = (greenness - 25) / 55; // 0..1
      d[i + 3] = Math.round(d[i + 3] * (1 - t));
      d[i + 1] = Math.max(r, b); // despill
    }
  }
  ctx.putImageData(id, 0, 0);
  return c;
}

/** Trims transparent borders. */
export function trim(src: Canvas): Canvas {
  const ctx = src.getContext("2d", { willReadFrequently: true })!;
  const { width: w, height: h } = src;
  const d = ctx.getImageData(0, 0, w, h).data;
  let minX = w, minY = h, maxX = -1, maxY = -1;
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      if (d[(y * w + x) * 4 + 3] > 12) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  if (maxX < 0) return makeCanvas(1, 1);
  const out = makeCanvas(maxX - minX + 1, maxY - minY + 1);
  out.getContext("2d")!.drawImage(src, minX, minY, out.width, out.height, 0, 0, out.width, out.height);
  return out;
}

export function sliceGrid(sheet: Canvas, cols: number, rows: number): Canvas[] {
  const cw = sheet.width / cols, ch = sheet.height / rows;
  const out: Canvas[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const cell = makeCanvas(cw, ch);
      cell.getContext("2d")!.drawImage(sheet, c * cw, r * ch, cw, ch, 0, 0, cw, ch);
      out.push(trim(cell));
    }
  return out;
}

export function scaleCanvas(src: Canvas, scale: number): Canvas {
  const out = makeCanvas(src.width * scale, src.height * scale);
  const ctx = out.getContext("2d")!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(src, 0, 0, out.width, out.height);
  return out;
}

export function tintCanvas(src: Canvas, color: string, alpha: number): Canvas {
  const out = makeCanvas(src.width, src.height);
  const ctx = out.getContext("2d")!;
  ctx.drawImage(src, 0, 0);
  ctx.globalCompositeOperation = "source-atop";
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, out.width, out.height);
  return out;
}

export function hueShift(src: Canvas, degrees: number, sat = 1, bright = 1): Canvas {
  const out = makeCanvas(src.width, src.height);
  const ctx = out.getContext("2d")!;
  ctx.filter = `hue-rotate(${degrees}deg) saturate(${sat}) brightness(${bright})`;
  ctx.drawImage(src, 0, 0);
  ctx.filter = "none";
  return out;
}

/* ------------------------------------------------------------------ */
/* LPC layered characters                                              */
/* ------------------------------------------------------------------ */

export const LPC_LAYERS = [
  "body_light", "body_tanned", "body_dark", "body_skeleton", "body_orc", "body_red_orc", "body_darkelf",
  "hair_plain_brown", "hair_long_white", "hair_messy_black", "hair_ponytail_blonde", "hair_bedhead_raven",
  "hair_mohawk_red", "hair_shorthawk_gray", "hair_long_raven",
  "beard_white", "beard_gray", "beard_brown",
  "torso_plate", "torso_plate_arms", "torso_chain", "torso_leather", "torso_leather_shoulders",
  "torso_shirt_white", "torso_shirt_brown", "torso_shirt_maroon", "torso_shirt_teal", "torso_gold", "torso_gold_arms",
  "legs_magenta", "legs_red", "legs_teal", "legs_white", "legs_metal", "legs_gold", "legs_robe",
  "head_cloth_hood", "head_chain_hood", "head_metal_helm", "head_gold_helm", "head_leather_cap", "head_bandana", "head_chainhat",
  "feet_brown", "feet_black", "feet_metal", "feet_gold",
  "hands_metal", "hands_leather", "hands_gold",
  "wpn_dagger", "wpn_wand", "wpn_spear", "wpn_shield",
] as const;
export const LPC_OVERSIZE: Record<string, "slash" | "thrust"> = {
  wpn_longsword: "slash",
  wpn_mace: "slash",
  wpn_saber: "slash",
  wpn_trident: "thrust",
};

const lpcImages: Record<string, HTMLImageElement> = {};
const sheetCache = new Map<string, Sheet>();

/** Compose a character from layer ids. Layer order = draw order. Supports a `tint:#rrggbb@0.4` pseudo layer. */
export function composeSheet(layers: string[]): Sheet {
  const key = layers.join("|");
  const cached = sheetCache.get(key);
  if (cached) return cached;
  let img = makeCanvas(832, 1344);
  const ctx = img.getContext("2d")!;
  let oversize: Canvas | undefined;
  let oversizeAnim: "slash" | "thrust" | undefined;
  let tint: { color: string; a: number } | undefined;
  for (const l of layers) {
    if (l.startsWith("tint:")) {
      const [c, a] = l.slice(5).split("@");
      tint = { color: c, a: parseFloat(a || "0.4") };
      continue;
    }
    const im = lpcImages[l];
    if (!im) continue;
    if (LPC_OVERSIZE[l]) {
      oversize = makeCanvas(im.width, im.height);
      oversize.getContext("2d")!.drawImage(im, 0, 0);
      oversizeAnim = LPC_OVERSIZE[l];
    } else {
      ctx.drawImage(im, 0, 0);
    }
  }
  if (tint) img = tintCanvas(img, tint.color, tint.a);
  const sheet: Sheet = { img, oversize, oversizeAnim };
  sheetCache.set(key, sheet);
  return sheet;
}

/** Draw one frame of a composed sheet, centered horizontally at (x), feet at (y). */
export function drawSheetFrame(
  ctx: CanvasRenderingContext2D,
  sheet: Sheet,
  anim: AnimName,
  dir: Dir4,
  frame: number,
  x: number,
  y: number,
  scale = 1,
  alpha = 1,
) {
  const a = ANIM[anim];
  const f = Math.min(frame, a.frames - 1);
  const row = anim === "hurt" ? 20 : a.row + dir;
  const size = 64 * scale;
  ctx.globalAlpha = alpha;
  ctx.drawImage(sheet.img, f * 64, row * 64, 64, 64, x - size / 2, y - size + 6 * scale, size, size);
  if (sheet.oversize && sheet.oversizeAnim === anim) {
    const cols = anim === "slash" ? 6 : 8;
    const os = 192 * scale;
    ctx.drawImage(sheet.oversize, (f % cols) * 192, dir * 192, 192, 192, x - os / 2, y - size + 6 * scale - 64 * scale, os, os);
  }
  ctx.globalAlpha = 1;
}

/* ------------------------------------------------------------------ */
/* Ground tiles                                                        */
/* ------------------------------------------------------------------ */

export interface BiomeStyle {
  ground: [string, string, string]; // dark, mid, light
  detail: string; // speckle color
  path: [string, string]; // dark, light
  liquid?: [string, string]; // water/lava
  liquidGlow?: string;
}

export interface GroundTiles {
  base: Canvas[]; // 4 variants
  path: Canvas[]; // 16 marching-square cases
  liquid: Canvas[]; // 16 cases
}

function diamondPath(ctx: CanvasRenderingContext2D, pad = 0) {
  ctx.beginPath();
  ctx.moveTo(TILE_W / 2, -pad);
  ctx.lineTo(TILE_W + pad, TILE_H / 2);
  ctx.lineTo(TILE_W / 2, TILE_H + pad);
  ctx.lineTo(-pad, TILE_H / 2);
  ctx.closePath();
}

function textureFill(ctx: CanvasRenderingContext2D, w: number, h: number, cols: [string, string, string], detail: string, noise: Noise2D, ox: number, oy: number, grainy: number, contrast = 1) {
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const parse = (c: string) => [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)];
  const c0 = parse(cols[0]), c1 = parse(cols[1]), c2 = parse(cols[2]), cd = parse(detail);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const n = noise.fbm((x + ox) / 9, (y + oy) / 5, 3);
      const g = noise.at((x + ox) * 1.7, (y + oy) * 1.7) * grainy;
      let t = Math.min(1, Math.max(0, n + g - grainy / 2));
      t = 0.5 + (t - 0.5) * contrast;
      let r: number, gg: number, b: number;
      if (t < 0.5) {
        const k = t * 2;
        r = c0[0] + (c1[0] - c0[0]) * k; gg = c0[1] + (c1[1] - c0[1]) * k; b = c0[2] + (c1[2] - c0[2]) * k;
      } else {
        const k = (t - 0.5) * 2;
        r = c1[0] + (c2[0] - c1[0]) * k; gg = c1[1] + (c2[1] - c1[1]) * k; b = c1[2] + (c2[2] - c1[2]) * k;
      }
      if (noise.at((x + ox) * 3.1, (y + oy) * 3.1) > 0.93) { r = cd[0]; gg = cd[1]; b = cd[2]; }
      const i = (y * w + x) * 4;
      d[i] = r; d[i + 1] = gg; d[i + 2] = b; d[i + 3] = 255;
    }
  ctx.putImageData(img, 0, 0);
}

/**
 * Marching squares on the diamond. Corner bits: 1=N(top), 2=E(right), 4=S(bottom), 8=W(left).
 * Shape vertices use edge midpoints, drawn with curves so edges are organic (no square paths).
 */
function maskShape(ctx: CanvasRenderingContext2D, mask: number) {
  const N = [TILE_W / 2, 0], E = [TILE_W, TILE_H / 2], S = [TILE_W / 2, TILE_H], W = [0, TILE_H / 2];
  const NE = [TILE_W * 0.75, TILE_H * 0.25], SE = [TILE_W * 0.75, TILE_H * 0.75], SW = [TILE_W * 0.25, TILE_H * 0.75], NW = [TILE_W * 0.25, TILE_H * 0.25];
  const C = [TILE_W / 2, TILE_H / 2];
  const poly = (pts: number[][]) => {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    ctx.fill();
  };
  const bulge = (a: number[], b: number[], corner: number[]) => {
    // rounded wedge around a corner
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.quadraticCurveTo(C[0] * 0.5 + corner[0] * 0.5, C[1] * 0.5 + corner[1] * 0.5, b[0], b[1]);
    ctx.lineTo(corner[0], corner[1]);
    ctx.closePath();
    ctx.fill();
  };
  const n = !!(mask & 1), e = !!(mask & 2), s = !!(mask & 4), w = !!(mask & 8);
  if (mask === 15) { diamondPath(ctx, 1); ctx.fill(); return; }
  if (n) bulge(NW, NE, N);
  if (e) bulge(NE, SE, E);
  if (s) bulge(SE, SW, S);
  if (w) bulge(SW, NW, W);
  // fill between adjacent corners (straight bands)
  if (n && e) poly([N, E, SE, C, NW]);
  if (e && s) poly([E, S, SW, C, NE]);
  if (s && w) poly([S, W, NW, C, SE]);
  if (w && n) poly([W, N, NE, C, SW]);
  if (n && s && !e && !w) poly([NW, NE, SE, SW]);
  if (e && w && !n && !s) poly([NW, NE, SE, SW]);
  if ((n && e && s) || (e && s && w) || (s && w && n) || (w && n && e)) { ctx.beginPath(); ctx.arc(C[0], C[1], TILE_H * 0.45, 0, Math.PI * 2); ctx.fill(); }
}

/** Pixel-exact diamond mask (no anti-aliased seams between neighbouring tiles). */
function crispDiamond(c: Canvas, threshold = 100) {
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  const id = ctx.getImageData(0, 0, c.width, c.height);
  const d = id.data;
  for (let y = 0; y < c.height; y++)
    for (let x = 0; x < c.width; x++) {
      const inside = Math.abs(x + 0.5 - TILE_W / 2) / (TILE_W / 2) + Math.abs(y + 0.5 - TILE_H / 2) / (TILE_H / 2) <= 1.0;
      const i = (y * c.width + x) * 4 + 3;
      d[i] = inside && d[i] > threshold ? 255 : 0;
    }
  ctx.putImageData(id, 0, 0);
}

export function makeGroundTiles(style: BiomeStyle, seed: number): GroundTiles {
  const noise = new Noise2D(seed);
  const base: Canvas[] = [];
  for (let v = 0; v < 4; v++) {
    const tex = makeCanvas(TILE_W, TILE_H);
    textureFill(tex.getContext("2d")!, TILE_W, TILE_H, style.ground, style.detail, noise, v * 13, v * 7, 0.45, 0.7);
    const c = makeCanvas(TILE_W, TILE_H);
    const ctx = c.getContext("2d")!;
    ctx.drawImage(tex, 0, 0);
    crispDiamond(c);
    base.push(c);
  }
  const makeMasked = (cols: [string, string], glow: string | undefined, liquid: boolean) => {
    const tex = makeCanvas(TILE_W, TILE_H);
    textureFill(tex.getContext("2d")!, TILE_W, TILE_H, [cols[0], cols[0], cols[1]], cols[1], noise, 300, 300, liquid ? 0.1 : 0.5);
    const pat = tex;
    const out: Canvas[] = [];
    for (let m = 0; m < 16; m++) {
      const c = makeCanvas(TILE_W, TILE_H);
      const ctx = c.getContext("2d")!;
      if (m === 0) { out.push(c); continue; }
      // shape mask
      const mask = makeCanvas(TILE_W, TILE_H);
      const mctx = mask.getContext("2d")!;
      mctx.fillStyle = "#fff";
      maskShape(mctx, m);
      ctx.save();
      // rim: dilated shape in rim color (only visible along the organic boundary, never along the diamond clip)
      if (m !== 15) {
        const rimCol = glow ?? "rgba(0,0,0,0.35)";
        ctx.fillStyle = rimCol;
        ctx.globalAlpha = glow ? 0.7 : 0.6;
        for (const [dx, dy] of [[1.5, 0], [-1.5, 0], [0, 1.5], [0, -1.5], [1, 1], [-1, 1], [1, -1], [-1, -1]]) {
          ctx.save(); ctx.translate(dx, dy); maskShape(ctx, m); ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
      // masked texture
      const tex2 = makeCanvas(TILE_W, TILE_H);
      const t2 = tex2.getContext("2d")!;
      t2.drawImage(mask, 0, 0);
      t2.globalCompositeOperation = "source-in";
      t2.drawImage(pat, 0, 0);
      ctx.drawImage(tex2, 0, 0);
      ctx.restore();
      crispDiamond(c, 60);
      out.push(c);
    }
    return out;
  };
  const path = makeMasked(style.path, undefined, false);
  const liquid = style.liquid ? makeMasked(style.liquid, style.liquidGlow, true) : [];
  return { base, path, liquid };
}

/* ------------------------------------------------------------------ */
/* Registry                                                            */
/* ------------------------------------------------------------------ */

export interface Assets {
  menuSky: HTMLImageElement;
  menuFg: Canvas;
  logo: Canvas;
  portraits: Record<string, Canvas>; // warrior, priest, necromancer, sorcerer, elder
  props: Canvas[]; // forest set, 10 items
  huts: Canvas[]; // 6 buildings
}

export const A: { ready: boolean; data: Assets | null } = { ready: false, data: null };

export async function loadAll(onProgress: (p: number, label: string) => void): Promise<Assets> {
  const total = LPC_LAYERS.length + Object.keys(LPC_OVERSIZE).length + 10;
  let done = 0;
  const tick = (l: string) => onProgress(++done / total, l);
  const lpcNames = [...LPC_LAYERS, ...Object.keys(LPC_OVERSIZE)];
  await Promise.all(
    lpcNames.map(async (n) => {
      try {
        lpcImages[n] = await loadImage(`/sprites/lpc/${n}.png`);
      } catch {
        /* missing layer tolerated */
      }
      tick(n);
    }),
  );
  const [sky, fg, logo, pw, pp, pn, ps, pe, propsImg, hutsImg] = await Promise.all([
    loadImage("/img/menu_sky.jpg"), loadImage("/img/menu_fg.png"), loadImage("/img/logo.png"),
    loadImage("/img/portrait_warrior.png"), loadImage("/img/portrait_priest.png"), loadImage("/img/portrait_necromancer.png"),
    loadImage("/img/portrait_sorcerer.png"), loadImage("/img/portrait_elder.png"), loadImage("/img/props_forest.png"), loadImage("/img/props_huts.png"),
  ]);
  tick("pinturas");
  const assets: Assets = {
    menuSky: sky,
    menuFg: chromaKey(fg),
    logo: trim(chromaKey(logo)),
    portraits: {
      warrior: trim(chromaKey(pw)),
      priest: trim(chromaKey(pp)),
      necromancer: trim(chromaKey(pn)),
      sorcerer: trim(chromaKey(ps)),
      elder: trim(chromaKey(pe)),
    },
    props: sliceGrid(chromaKey(propsImg), 5, 2),
    huts: sliceGrid(chromaKey(hutsImg), 3, 2),
  };
  for (let i = 0; i < 9; i++) tick("recortes");
  A.data = assets;
  A.ready = true;
  return assets;
}

/** Cached low-res alpha masks for occlusion tests (1/4 resolution). */
const alphaMasks = new WeakMap<Canvas, { w: number; h: number; d: Uint8Array }>();
export function alphaAt(img: Canvas, u: number, v: number): number {
  let m = alphaMasks.get(img);
  if (!m) {
    const w = Math.max(1, Math.floor(img.width / 4)), h = Math.max(1, Math.floor(img.height / 4));
    const c = makeCanvas(w, h);
    const cx = c.getContext("2d", { willReadFrequently: true })!;
    cx.drawImage(img, 0, 0, w, h);
    const id = cx.getImageData(0, 0, w, h).data;
    const d = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) d[i] = id[i * 4 + 3];
    m = { w, h, d };
    alphaMasks.set(img, m);
  }
  if (u < 0 || v < 0 || u >= 1 || v >= 1) return 0;
  return m.d[Math.floor(v * m.h) * m.w + Math.floor(u * m.w)];
}

/** Deterministic helper used by map gen to pick prop variants. */
export function propVariant(rng: RNG, kind: "tree" | "rock" | "bush" | "misc"): number {
  // props sheet indexes: 0 oak,1 pine,2 dead tree,3 bush,4 mushrooms,5 boulder,6 rock,7 pebbles,8 fence,9 well
  switch (kind) {
    case "tree": return rng.pick([0, 0, 1, 1, 2]);
    case "rock": return rng.pick([5, 6, 6, 7, 7]);
    case "bush": return rng.pick([3, 3, 4]);
    default: return rng.pick([8, 9]);
  }
}
