/**
 * Procedural audio engine (Web Audio API). No external files needed.
 *  - Music: a lookahead scheduler plays pad chords + arpeggios + bass from a per-track "mood".
 *  - SFX: short synthesized sounds (UI, combat, skills, loot, portal...).
 * Volumes are persisted in localStorage (options screen).
 */

export type MusicTrack = "menu" | "village" | "act1" | "act2" | "act3" | "act4" | "act5" | "boss" | "none";
export type SfxName =
  | "hover" | "select" | "back" | "sword" | "hit" | "hurt" | "die" | "fire" | "ice" | "bolt" | "holy" | "heal"
  | "bone" | "curse" | "dash" | "shout" | "quake" | "levelup" | "coin" | "potion" | "pickup" | "portal" | "quest"
  | "boss" | "equip" | "error" | "summon" | "meteor" | "page";

interface Mood {
  bpm: number;
  root: number; // midi
  scale: number[];
  chords: number[][]; // degrees
  padType: OscillatorType;
  arpType: OscillatorType;
  arpDensity: number; // 0..1
  bass: boolean;
  drone: boolean;
  percussion: boolean;
  cutoff: number;
}

const MOODS: Record<Exclude<MusicTrack, "none">, Mood> = {
  menu: { bpm: 60, root: 45, scale: [0, 2, 3, 5, 7, 8, 10], chords: [[0, 2, 4], [5, 0, 2], [3, 5, 0], [4, 6, 1]], padType: "sawtooth", arpType: "triangle", arpDensity: 0.45, bass: true, drone: true, percussion: false, cutoff: 900 },
  village: { bpm: 72, root: 50, scale: [0, 2, 3, 5, 7, 9, 10], chords: [[0, 2, 4], [3, 5, 0], [4, 6, 1], [5, 0, 2]], padType: "triangle", arpType: "sine", arpDensity: 0.5, bass: false, drone: false, percussion: false, cutoff: 1800 },
  act1: { bpm: 84, root: 43, scale: [0, 2, 3, 5, 7, 8, 10], chords: [[0, 2, 4], [5, 0, 2], [0, 2, 4], [6, 1, 3]], padType: "sawtooth", arpType: "square", arpDensity: 0.35, bass: true, drone: true, percussion: true, cutoff: 1200 },
  act2: { bpm: 92, root: 41, scale: [0, 1, 4, 5, 7, 8, 10], chords: [[0, 2, 4], [1, 3, 5], [0, 2, 4], [4, 6, 1]], padType: "sawtooth", arpType: "triangle", arpDensity: 0.5, bass: true, drone: true, percussion: true, cutoff: 1400 },
  act3: { bpm: 70, root: 40, scale: [0, 2, 3, 6, 7, 8, 11], chords: [[0, 2, 4], [3, 5, 0], [6, 1, 3], [0, 2, 4]], padType: "triangle", arpType: "sine", arpDensity: 0.3, bass: true, drone: true, percussion: false, cutoff: 800 },
  act4: { bpm: 100, root: 38, scale: [0, 1, 3, 5, 6, 8, 10], chords: [[0, 2, 4], [1, 3, 5], [5, 0, 2], [0, 2, 4]], padType: "sawtooth", arpType: "sawtooth", arpDensity: 0.55, bass: true, drone: true, percussion: true, cutoff: 1600 },
  act5: { bpm: 110, root: 36, scale: [0, 1, 4, 5, 7, 8, 11], chords: [[0, 2, 4], [1, 3, 5], [0, 2, 4], [1, 3, 5]], padType: "sawtooth", arpType: "square", arpDensity: 0.6, bass: true, drone: true, percussion: true, cutoff: 2000 },
  boss: { bpm: 128, root: 36, scale: [0, 1, 3, 5, 6, 8, 10], chords: [[0, 2, 4], [1, 3, 5], [0, 2, 4], [6, 1, 3]], padType: "sawtooth", arpType: "sawtooth", arpDensity: 0.8, bass: true, drone: true, percussion: true, cutoff: 2400 },
};

const midi = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

class AudioEngine {
  ctx: AudioContext | null = null;
  master!: GainNode;
  musicBus!: GainNode;
  sfxBus!: GainNode;
  musicVol = 0.6;
  sfxVol = 0.8;
  current: MusicTrack = "none";
  private timer: number | null = null;
  private nextBeat = 0;
  private beat = 0;
  private musicNodes: AudioNode[] = [];
  private droneOsc: OscillatorNode[] = [];
  private lastSfx: Record<string, number> = {};

  constructor() {
    if (typeof window !== "undefined") {
      const mv = localStorage.getItem("pdi_musicVol"), sv = localStorage.getItem("pdi_sfxVol");
      if (mv) this.musicVol = parseFloat(mv);
      if (sv) this.sfxVol = parseFloat(sv);
    }
  }

  /** Must be called from a user gesture. */
  init() {
    if (this.ctx) return;
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new Ctor();
    this.master = this.ctx.createGain();
    this.master.gain.value = 1;
    this.master.connect(this.ctx.destination);
    this.musicBus = this.ctx.createGain();
    this.musicBus.gain.value = this.musicVol;
    this.musicBus.connect(this.master);
    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = this.sfxVol;
    this.sfxBus.connect(this.master);
    if (this.current !== "none") {
      const t = this.current;
      this.current = "none";
      this.playMusic(t);
    }
  }
  resume() {
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }
  setMusicVol(v: number) {
    this.musicVol = v;
    localStorage.setItem("pdi_musicVol", String(v));
    if (this.musicBus) this.musicBus.gain.value = v;
  }
  setSfxVol(v: number) {
    this.sfxVol = v;
    localStorage.setItem("pdi_sfxVol", String(v));
    if (this.sfxBus) this.sfxBus.gain.value = v;
  }

  /* ---------------- music ---------------- */
  playMusic(track: MusicTrack) {
    if (track === this.current) return;
    this.stopMusic();
    this.current = track;
    if (!this.ctx || track === "none") return;
    const mood = MOODS[track];
    const ctx = this.ctx;
    // drone
    if (mood.drone) {
      for (const detune of [-6, 6]) {
        const o = ctx.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = midi(mood.root - 12);
        o.detune.value = detune;
        const f = ctx.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = 220;
        const g = ctx.createGain();
        g.gain.value = 0.0;
        g.gain.linearRampToValueAtTime(0.07, ctx.currentTime + 3);
        o.connect(f).connect(g).connect(this.musicBus);
        o.start();
        this.droneOsc.push(o);
        this.musicNodes.push(g);
      }
    }
    this.beat = 0;
    this.nextBeat = ctx.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(mood), 90);
  }
  stopMusic() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    for (const o of this.droneOsc) { try { o.stop(); } catch { /* */ } }
    this.droneOsc = [];
    this.musicNodes = [];
    this.current = "none";
  }
  private schedule(mood: Mood) {
    const ctx = this.ctx!;
    const spb = 60 / mood.bpm;
    while (this.nextBeat < ctx.currentTime + 0.4) {
      const t = this.nextBeat;
      const bar = Math.floor(this.beat / 8);
      const chord = mood.chords[bar % mood.chords.length];
      const step = this.beat % 8;
      if (step === 0) {
        // pad chord
        for (const deg of chord) {
          const n = mood.root + 12 + this.degToSemi(mood.scale, deg);
          this.tone(t, midi(n), spb * 8.2, mood.padType, 0.045, this.musicBus, mood.cutoff, 1.2, 2.5);
        }
        if (mood.bass) this.tone(t, midi(mood.root - 12 + this.degToSemi(mood.scale, chord[0])), spb * 3.5, "triangle", 0.12, this.musicBus, 400, 0.02, 1.0);
      }
      if (step === 4 && mood.bass) this.tone(t, midi(mood.root - 12 + this.degToSemi(mood.scale, chord[0])), spb * 2, "triangle", 0.09, this.musicBus, 400, 0.02, 0.8);
      // arpeggio / melody
      const r = this.hashRand(this.beat * 7 + bar * 13);
      if (r < mood.arpDensity) {
        const deg = chord[(this.beat + bar) % 3] + (r < mood.arpDensity * 0.3 ? 7 : 0);
        const n = mood.root + 24 + this.degToSemi(mood.scale, deg);
        this.tone(t, midi(n), spb * 0.9, mood.arpType, 0.05, this.musicBus, mood.cutoff * 1.5, 0.01, 0.4);
      }
      if (mood.percussion) {
        if (step === 0 || step === 4 || (step === 6 && bar % 2 === 1)) this.drum(t, "kick");
        if (step === 2 || step === 6) this.drum(t, "tom");
      }
      this.nextBeat += spb / 2;
      this.beat++;
    }
  }
  private degToSemi(scale: number[], deg: number): number {
    const oct = Math.floor(deg / scale.length);
    const i = ((deg % scale.length) + scale.length) % scale.length;
    return scale[i] + oct * 12;
  }
  private hashRand(i: number): number {
    const x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
  }

  /* ---------------- synth primitives ---------------- */
  private tone(t: number, freq: number, dur: number, type: OscillatorType, vol: number, bus: AudioNode, cutoff = 4000, attack = 0.01, release = 0.2, slideTo?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = cutoff;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.setValueAtTime(vol, t + Math.max(attack, dur - release));
    g.gain.linearRampToValueAtTime(0, t + dur);
    o.connect(f).connect(g).connect(bus);
    o.start(t);
    o.stop(t + dur + 0.05);
  }
  private noise(t: number, dur: number, vol: number, bus: AudioNode, filterType: BiquadFilterType = "lowpass", cutoff = 2000, q = 1, sweepTo?: number) {
    const ctx = this.ctx!;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const s = ctx.createBufferSource();
    s.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = filterType;
    f.frequency.setValueAtTime(cutoff, t);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(bus);
    s.start(t);
  }
  private drum(t: number, kind: "kick" | "tom") {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.frequency.setValueAtTime(kind === "kick" ? 110 : 180, t);
    o.frequency.exponentialRampToValueAtTime(kind === "kick" ? 40 : 70, t + 0.25);
    const g = ctx.createGain();
    g.gain.setValueAtTime(kind === "kick" ? 0.3 : 0.15, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g).connect(this.musicBus);
    o.start(t);
    o.stop(t + 0.35);
  }

  /* ---------------- sfx ---------------- */
  sfx(name: SfxName) {
    if (!this.ctx) return;
    this.resume();
    const now = performance.now();
    if (this.lastSfx[name] && now - this.lastSfx[name] < 40) return;
    this.lastSfx[name] = now;
    const t = this.ctx.currentTime;
    const b = this.sfxBus;
    switch (name) {
      case "hover": this.tone(t, 620, 0.07, "sine", 0.12, b, 4000, 0.005, 0.05); break;
      case "select": this.tone(t, 440, 0.12, "triangle", 0.2, b, 4000, 0.005, 0.06); this.tone(t + 0.08, 660, 0.25, "triangle", 0.2, b, 4000, 0.005, 0.15); break;
      case "back": this.tone(t, 500, 0.1, "triangle", 0.15, b, 3000, 0.005, 0.05); this.tone(t + 0.07, 330, 0.2, "triangle", 0.15, b, 3000, 0.005, 0.12); break;
      case "page": this.noise(t, 0.18, 0.18, b, "bandpass", 1500, 0.8, 600); break;
      case "sword": this.noise(t, 0.18, 0.35, b, "bandpass", 2500, 1.5, 600); break;
      case "hit": this.noise(t, 0.12, 0.4, b, "lowpass", 900, 1); this.tone(t, 160, 0.1, "square", 0.15, b, 800, 0.001, 0.08, 60); break;
      case "hurt": this.tone(t, 300, 0.2, "sawtooth", 0.18, b, 1200, 0.005, 0.1, 120); break;
      case "die": this.tone(t, 220, 0.6, "sawtooth", 0.2, b, 900, 0.01, 0.4, 40); this.noise(t, 0.4, 0.2, b, "lowpass", 600); break;
      case "fire": this.noise(t, 0.5, 0.35, b, "lowpass", 3000, 1, 300); this.tone(t, 200, 0.35, "sawtooth", 0.12, b, 1500, 0.01, 0.25, 90); break;
      case "ice": this.noise(t, 0.4, 0.25, b, "highpass", 3000, 2, 8000); this.tone(t, 1400, 0.3, "sine", 0.15, b, 8000, 0.005, 0.25, 2200); break;
      case "bolt": this.noise(t, 0.25, 0.45, b, "highpass", 1500, 3); this.tone(t, 900, 0.12, "square", 0.1, b, 6000, 0.001, 0.1, 200); break;
      case "holy": for (let i = 0; i < 4; i++) this.tone(t + i * 0.05, 523 * Math.pow(2, i / 12 * 4), 0.5, "sine", 0.12, b, 6000, 0.02, 0.35); break;
      case "heal": this.tone(t, 660, 0.4, "sine", 0.15, b, 6000, 0.05, 0.3, 1320); this.tone(t + 0.1, 880, 0.4, "triangle", 0.1, b, 6000, 0.05, 0.3); break;
      case "bone": this.noise(t, 0.2, 0.3, b, "bandpass", 1200, 4, 300); this.tone(t, 180, 0.2, "square", 0.08, b, 1000, 0.001, 0.1, 60); break;
      case "curse": this.tone(t, 220, 0.6, "sawtooth", 0.12, b, 700, 0.1, 0.4, 110); this.tone(t, 233, 0.6, "sawtooth", 0.12, b, 700, 0.1, 0.4, 117); break;
      case "dash": this.noise(t, 0.3, 0.3, b, "bandpass", 800, 1, 3000); break;
      case "shout": this.tone(t, 150, 0.5, "sawtooth", 0.25, b, 1200, 0.02, 0.3, 220); this.noise(t, 0.4, 0.15, b, "lowpass", 1500); break;
      case "quake": this.noise(t, 0.9, 0.5, b, "lowpass", 300, 1, 60); this.tone(t, 60, 0.8, "sine", 0.4, b, 300, 0.01, 0.6, 30); break;
      case "meteor": this.noise(t, 0.6, 0.3, b, "lowpass", 4000, 1, 200); this.noise(t + 0.6, 0.8, 0.6, b, "lowpass", 500, 1, 60); this.tone(t + 0.6, 80, 0.7, "sine", 0.4, b, 400, 0.01, 0.5, 30); break;
      case "levelup": [0, 4, 7, 12, 16].forEach((s, i) => this.tone(t + i * 0.09, midi(72 + s), 0.5, "triangle", 0.18, b, 6000, 0.01, 0.35)); break;
      case "coin": this.tone(t, 1760, 0.12, "square", 0.08, b, 8000, 0.001, 0.08); this.tone(t + 0.06, 2217, 0.2, "square", 0.08, b, 8000, 0.001, 0.15); break;
      case "potion": this.tone(t, 500, 0.15, "sine", 0.15, b, 5000, 0.01, 0.1, 900); this.tone(t + 0.12, 700, 0.2, "sine", 0.12, b, 5000, 0.01, 0.15, 1100); break;
      case "pickup": this.tone(t, 700, 0.08, "triangle", 0.12, b, 5000, 0.005, 0.05); this.tone(t + 0.05, 1050, 0.12, "triangle", 0.1, b, 5000, 0.005, 0.08); break;
      case "equip": this.noise(t, 0.12, 0.25, b, "bandpass", 3000, 2, 1500); this.tone(t, 300, 0.1, "square", 0.08, b, 2000, 0.001, 0.08); break;
      case "portal": this.tone(t, 200, 1.2, "sine", 0.2, b, 4000, 0.1, 0.8, 800); this.tone(t, 300, 1.2, "triangle", 0.1, b, 4000, 0.1, 0.8, 1200); this.noise(t, 1.0, 0.1, b, "bandpass", 2000, 2, 6000); break;
      case "quest": [0, 7, 12].forEach((s, i) => this.tone(t + i * 0.12, midi(67 + s), 0.45, "triangle", 0.16, b, 5000, 0.01, 0.3)); break;
      case "boss": this.tone(t, 55, 1.5, "sawtooth", 0.35, b, 500, 0.05, 1.0, 40); this.noise(t, 1.2, 0.25, b, "lowpass", 400, 1, 100); this.tone(t + 0.2, 110, 1.0, "square", 0.1, b, 600, 0.05, 0.8, 70); break;
      case "summon": this.tone(t, 150, 0.5, "sawtooth", 0.12, b, 900, 0.05, 0.3, 300); this.noise(t, 0.4, 0.2, b, "bandpass", 700, 3, 2500); break;
      case "error": this.tone(t, 200, 0.15, "square", 0.12, b, 1500, 0.005, 0.1); this.tone(t + 0.12, 150, 0.2, "square", 0.12, b, 1500, 0.005, 0.1); break;
    }
  }
}

export const audio = new AudioEngine();
