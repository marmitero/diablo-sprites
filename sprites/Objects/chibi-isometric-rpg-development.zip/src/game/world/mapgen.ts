/**
 * Procedural region generator. Fully deterministic from (seed, act).
 * See docs/ARCHITECTURE.md -> "Map generation" for the rule set:
 *  - Village (safezone) with plaza, huts on a ring, NPC spots in front of huts, portal and spawn.
 *  - Winding paths (noise-biased random walk, stamped on the vertex grid -> 16-case autotile).
 *  - Liquids from fbm noise, carved away from village/paths/POIs.
 *  - Props: density from noise, minimum spacing per kind, clearings around POIs, ring around the boss lair.
 *  - Enemy camps at POIs and scattered packs whose tier grows with distance from the village.
 */
import { A, Canvas, GroundTiles, hueShift, makeGroundTiles, propVariant, scaleCanvas } from "../core/assets";
import { hashString, Noise2D, RNG } from "../core/rng";
import { ACTS, ActDef } from "../data/acts";

export interface Prop {
  x: number; y: number; // tile coords of the base (anchor bottom-center)
  img: Canvas;
  w: number; h: number; // pixels
  kind: "tree" | "rock" | "bush" | "misc" | "hut" | "altar" | "waystone" | "portal" | "lair";
  blocks: boolean;
  radius: number; // blocking radius (tiles)
  occludes: boolean;
  id?: string;
}

export interface POI { id: "altar" | "waystone" | "lair" | "camp"; x: number; y: number; discovered: boolean; index: number }
export interface SpawnGroup { x: number; y: number; typeIndex: number; count: number; elite?: boolean; boss?: boolean; radius: number }
export interface NpcSpot { id: "elder" | "smith" | "merchant" | "traveler"; x: number; y: number }

export interface Region {
  act: ActDef;
  seed: string;
  W: number; H: number;
  ground: Uint8Array;
  pathV: Uint8Array;
  liquidV: Uint8Array;
  blocked: Uint8Array;
  explored: Uint8Array;
  props: Prop[];
  village: { cx: number; cy: number; radius: number; npcs: NpcSpot[]; portal: { x: number; y: number }; spawn: { x: number; y: number } };
  pois: POI[];
  spawns: SpawnGroup[];
  lair: { x: number; y: number };
  tiles: GroundTiles;
}

export const VIDX = (r: Region, x: number, y: number) => y * (r.W + 1) + x;

export function pathMask(r: Region, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= r.W || ty >= r.H) return 0;
  const v = r.pathV;
  // corner bits: 1=N (vertex tx,ty), 2=E (tx+1,ty), 4=S (tx+1,ty+1), 8=W (tx,ty+1)
  return (v[VIDX(r, tx, ty)] ? 1 : 0) | (v[VIDX(r, tx + 1, ty)] ? 2 : 0) | (v[VIDX(r, tx + 1, ty + 1)] ? 4 : 0) | (v[VIDX(r, tx, ty + 1)] ? 8 : 0);
}
export function liquidMask(r: Region, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= r.W || ty >= r.H) return 0;
  const v = r.liquidV;
  return (v[VIDX(r, tx, ty)] ? 1 : 0) | (v[VIDX(r, tx + 1, ty)] ? 2 : 0) | (v[VIDX(r, tx + 1, ty + 1)] ? 4 : 0) | (v[VIDX(r, tx, ty + 1)] ? 8 : 0);
}

export function isWalkable(r: Region, x: number, y: number): boolean {
  if (x < 1 || y < 1 || x >= r.W - 1 || y >= r.H - 1) return false;
  return r.blocked[Math.floor(y) * r.W + Math.floor(x)] === 0;
}
export function inVillage(r: Region, x: number, y: number): boolean {
  const dx = x - r.village.cx, dy = y - r.village.cy;
  return dx * dx + dy * dy < r.village.radius * r.village.radius;
}

const propCache = new Map<string, Canvas[]>();
function biomeProps(act: ActDef): { props: Canvas[]; huts: Canvas[] } {
  const key = "p" + act.id;
  if (!propCache.has(key)) {
    const base = A.data!.props.map((c) => (act.propHue || act.propSat !== 1 || act.propBright !== 1 ? hueShift(c, act.propHue, act.propSat, act.propBright) : c));
    propCache.set(key, base);
    const huts = A.data!.huts.map((c) => (act.hutHue ? hueShift(c, act.hutHue, 0.9, 0.95) : c));
    propCache.set("h" + act.id, huts);
  }
  return { props: propCache.get(key)!, huts: propCache.get("h" + act.id)! };
}

const tilesCache = new Map<number, GroundTiles>();

export function generateRegion(seed: string, actId: number): Region {
  const act = ACTS[actId - 1];
  const W = act.size, H = act.size;
  const rng = new RNG(hashString(seed + "|act" + actId));
  const noise = new Noise2D(hashString(seed + "n" + actId));
  const forest = new Noise2D(hashString(seed + "f" + actId));
  const rocks = new Noise2D(hashString(seed + "r" + actId));
  if (!tilesCache.has(actId)) tilesCache.set(actId, makeGroundTiles(act.biome, hashString("tiles" + actId)));
  const { props: propImgs, huts: hutImgs } = biomeProps(act);

  const r: Region = {
    act, seed, W, H,
    ground: new Uint8Array(W * H),
    pathV: new Uint8Array((W + 1) * (H + 1)),
    liquidV: new Uint8Array((W + 1) * (H + 1)),
    blocked: new Uint8Array(W * H),
    explored: new Uint8Array(W * H),
    props: [],
    village: { cx: 0, cy: 0, radius: 11, npcs: [], portal: { x: 0, y: 0 }, spawn: { x: 0, y: 0 } },
    pois: [],
    spawns: [],
    lair: { x: 0, y: 0 },
    tiles: tilesCache.get(actId)!,
  };

  // ground variants
  for (let i = 0; i < W * H; i++) r.ground[i] = Math.floor(noise.at((i % W) * 0.7, Math.floor(i / W) * 0.7) * 4) % 4;

  // --- village placement (one of 4 quadrants), boss lair in the opposite corner
  const quadrant = rng.int(0, 3);
  const vx = quadrant % 2 === 0 ? W * 0.24 : W * 0.76;
  const vy = quadrant < 2 ? H * 0.24 : H * 0.76;
  r.village.cx = Math.round(vx + rng.range(-4, 4));
  r.village.cy = Math.round(vy + rng.range(-4, 4));
  r.lair = { x: Math.round(W - vx + rng.range(-6, 6)), y: Math.round(H - vy + rng.range(-6, 6)) };
  const dist = (ax: number, ay: number, bx: number, by: number) => Math.hypot(ax - bx, ay - by);

  // --- POIs: altar, waystone, 3 camps, scattered at increasing distances
  const poiCandidates: POI[] = [];
  const tryPlace = (id: POI["id"], minD: number, maxD: number, idx: number) => {
    for (let t = 0; t < 200; t++) {
      const x = rng.int(8, W - 9), y = rng.int(8, H - 9);
      const d = dist(x, y, r.village.cx, r.village.cy);
      if (d < minD || d > maxD) continue;
      if (dist(x, y, r.lair.x, r.lair.y) < 14) continue;
      if (poiCandidates.some((p) => dist(p.x, p.y, x, y) < 16)) continue;
      poiCandidates.push({ id, x, y, discovered: false, index: idx });
      return;
    }
  };
  tryPlace("waystone", 28, 50, 0);
  tryPlace("altar", 40, 80, 1);
  tryPlace("camp", 22, 40, 2);
  tryPlace("camp", 35, 60, 3);
  tryPlace("camp", 50, 85, 4);
  if (act.size > 118) tryPlace("camp", 45, 90, 5);
  r.pois = poiCandidates;
  r.pois.push({ id: "lair", x: r.lair.x, y: r.lair.y, discovered: false, index: 9 });

  // --- liquids (vertex grid) from noise, carved away from village, POIs, lair
  if (act.liquidKind !== "none") {
    for (let y = 0; y <= H; y++)
      for (let x = 0; x <= W; x++) {
        const n = noise.fbm(x / 14, y / 14, 3);
        let ok = n > 0.62;
        if (x < 3 || y < 3 || x > W - 3 || y > H - 3) ok = false;
        if (dist(x, y, r.village.cx, r.village.cy) < r.village.radius + 5) ok = false;
        if (dist(x, y, r.lair.x, r.lair.y) < 9) ok = false;
        for (const p of r.pois) if (dist(x, y, p.x, p.y) < 6) ok = false;
        if (ok) r.liquidV[y * (W + 1) + x] = 1;
      }
  }

  // --- paths: village -> each POI (biased random walk with noise), stamped on vertices
  const stampPath = (px: number, py: number, rad: number) => {
    for (let yy = Math.floor(py - rad); yy <= Math.ceil(py + rad); yy++)
      for (let xx = Math.floor(px - rad); xx <= Math.ceil(px + rad); xx++) {
        if (xx < 1 || yy < 1 || xx >= W || yy >= H) continue;
        if (dist(xx, yy, px, py) <= rad) {
          r.pathV[yy * (W + 1) + xx] = 1;
          // clear liquid around path
          for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
            const lx = xx + dx, ly = yy + dy;
            if (lx >= 0 && ly >= 0 && lx <= W && ly <= H) r.liquidV[ly * (W + 1) + lx] = 0;
          }
        }
      }
  };
  const carve = (ax: number, ay: number, bx: number, by: number, width: number) => {
    let x = ax, y = ay;
    let guard = 0;
    const wob = rng.range(0, 100);
    while (dist(x, y, bx, by) > 1.5 && guard++ < 2000) {
      const ang = Math.atan2(by - y, bx - x) + (noise.at(x / 6 + wob, y / 6) - 0.5) * 2.2;
      x += Math.cos(ang) * 0.8;
      y += Math.sin(ang) * 0.8;
      stampPath(x, y, width + (noise.at(x / 3, y / 3) - 0.5) * 0.6);
    }
  };
  // plaza ring
  for (let a = 0; a < Math.PI * 2; a += 0.08) stampPath(r.village.cx + Math.cos(a) * 4.5, r.village.cy + Math.sin(a) * 4.5, 1.6);
  stampPath(r.village.cx, r.village.cy, 2.2);
  for (const p of r.pois) {
    // path from village edge toward poi, sometimes via a previous poi (network feel)
    const from = rng.chance(0.4) && r.pois.indexOf(p) > 0 ? r.pois[rng.int(0, r.pois.indexOf(p) - 1)] : { x: r.village.cx, y: r.village.cy };
    carve(from.x, from.y, p.x, p.y, p.id === "lair" ? 1.4 : 1.1);
    stampPath(p.x, p.y, 2.4);
  }

  // --- blocked by liquid (3+ corners)
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const m = liquidMask(r, x, y);
      const bits = ((m & 1) ? 1 : 0) + ((m & 2) ? 1 : 0) + ((m & 4) ? 1 : 0) + ((m & 8) ? 1 : 0);
      if (bits >= 3) r.blocked[y * W + x] = 1;
    }

  const addProp = (p: Prop) => {
    r.props.push(p);
    if (p.blocks) {
      const rad = p.radius;
      for (let yy = Math.floor(p.y - rad); yy <= Math.ceil(p.y + rad); yy++)
        for (let xx = Math.floor(p.x - rad); xx <= Math.ceil(p.x + rad); xx++) {
          if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
          if (dist(xx + 0.5, yy + 0.5, p.x, p.y) <= rad + 0.2) r.blocked[yy * W + xx] = 1;
        }
    }
  };

  // --- village huts on a ring; elder hut nearest to spawn
  const spawnAng = rng.range(0, Math.PI * 2);
  r.village.spawn = { x: r.village.cx + Math.cos(spawnAng) * 2, y: r.village.cy + Math.sin(spawnAng) * 2 };
  r.village.portal = { x: r.village.cx + Math.cos(spawnAng + Math.PI) * 3.2, y: r.village.cy + Math.sin(spawnAng + Math.PI) * 3.2 };
  const hutOrder = [0, 1, 2, 4, 3, 5]; // elder, smith, merchant, traveler(tent), ruin, chapel
  const npcForHut: Record<number, NpcSpot["id"]> = { 0: "elder", 1: "smith", 2: "merchant", 4: "traveler" };
  const ringR = 7.6;
  for (let i = 0; i < hutOrder.length; i++) {
    const hi = hutOrder[i];
    const ang = spawnAng + (i / hutOrder.length) * Math.PI * 2 + 0.35;
    const hx = r.village.cx + Math.cos(ang) * ringR;
    const hy = r.village.cy + Math.sin(ang) * ringR;
    const img = hutImgs[hi];
    const w = 300, h = (img.height / img.width) * 300;
    addProp({ x: hx, y: hy, img, w, h, kind: "hut", blocks: true, radius: 2.4, occludes: true, id: "hut" + hi });
    const npc = npcForHut[hi];
    if (npc) {
      // NPC stands in front (towards plaza center)
      const tx = r.village.cx + Math.cos(ang) * (ringR - 3.6);
      const ty = r.village.cy + Math.sin(ang) * (ringR - 3.6);
      r.village.npcs.push({ id: npc, x: tx, y: ty });
    }
  }
  // village decor: well + fences
  addProp({ x: r.village.cx + 2.5, y: r.village.cy - 2.5, img: propImgs[9], w: 70, h: 70 * (propImgs[9].height / propImgs[9].width), kind: "misc", blocks: true, radius: 0.6, occludes: false });
  for (let i = 0; i < 6; i++) {
    const a = rng.range(0, Math.PI * 2);
    addProp({ x: r.village.cx + Math.cos(a) * (r.village.radius - 1.2), y: r.village.cy + Math.sin(a) * (r.village.radius - 1.2), img: propImgs[8], w: 64, h: 64 * (propImgs[8].height / propImgs[8].width), kind: "misc", blocks: false, radius: 0, occludes: false });
  }
  // portal prop (drawn procedurally by renderer; registered as non-blocking marker)
  addProp({ x: r.village.portal.x, y: r.village.portal.y, img: propImgs[7], w: 1, h: 1, kind: "portal", blocks: false, radius: 0, occludes: false, id: "portal" });
  for (const p of r.pois) {
    if (p.id === "altar") addProp({ x: p.x, y: p.y, img: propImgs[9], w: 90, h: 90 * (propImgs[9].height / propImgs[9].width), kind: "altar", blocks: true, radius: 0.8, occludes: false, id: "altar" });
    if (p.id === "waystone") addProp({ x: p.x, y: p.y, img: propImgs[5], w: 80, h: 80 * (propImgs[5].height / propImgs[5].width), kind: "waystone", blocks: true, radius: 0.8, occludes: false, id: "waystone" });
  }

  // --- boss lair ring (dead trees / boulders) with an opening toward the village
  const toVillage = Math.atan2(r.village.cy - r.lair.y, r.village.cx - r.lair.x);
  for (let a = 0; a < Math.PI * 2; a += 0.28) {
    let d = Math.abs(((a - toVillage + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    d = Math.min(d, Math.PI * 2 - d);
    if (d < 0.55) continue;
    const img = propImgs[rng.chance(0.6) ? 2 : 5];
    const s = rng.range(1.0, 1.3);
    const w = 110 * s, h = (img.height / img.width) * 110 * s;
    addProp({ x: r.lair.x + Math.cos(a) * 6.5, y: r.lair.y + Math.sin(a) * 6.5, img, w, h, kind: "tree", blocks: true, radius: 0.7, occludes: true });
  }
  addProp({ x: r.lair.x, y: r.lair.y - 3, img: propImgs[5], w: 1, h: 1, kind: "lair", blocks: false, radius: 0, occludes: false, id: "lair" });

  // --- scattered props with spacing rules
  const occupancy = new Uint8Array(W * H); // 1 = near a prop
  const mark = (x: number, y: number, rad: number) => {
    for (let yy = Math.floor(y - rad); yy <= Math.ceil(y + rad); yy++)
      for (let xx = Math.floor(x - rad); xx <= Math.ceil(x + rad); xx++) if (xx >= 0 && yy >= 0 && xx < W && yy < H) occupancy[yy * W + xx] = 1;
  };
  for (const p of r.props) mark(p.x, p.y, Math.max(1, p.radius + 1));
  const nearPath = (x: number, y: number) => pathMask(r, x, y) !== 0 || pathMask(r, x - 1, y) !== 0 || pathMask(r, x + 1, y) !== 0 || pathMask(r, x, y - 1) !== 0 || pathMask(r, x, y + 1) !== 0;
  for (let y = 2; y < H - 2; y++)
    for (let x = 2; x < W - 2; x++) {
      if (r.blocked[y * W + x] || occupancy[y * W + x]) continue;
      if (liquidMask(r, x, y) !== 0) continue;
      const dv = dist(x, y, r.village.cx, r.village.cy);
      if (dv < r.village.radius + 1.5) continue;
      if (nearPath(x, y)) continue;
      let clear = false;
      for (const p of r.pois) if (dist(x, y, p.x, p.y) < (p.id === "lair" ? 7.5 : 3.5)) clear = true;
      if (clear) continue;
      const f = forest.fbm(x / 10, y / 10, 3);
      const rk = rocks.at(x / 7, y / 7);
      const jx = x + rng.range(0.2, 0.8), jy = y + rng.range(0.2, 0.8);
      if (rng.chance(Math.pow(Math.max(0, f - 0.35), 2) * 1.6)) {
        const vi = propVariant(rng, "tree");
        const img = propImgs[vi];
        const s = rng.range(0.85, 1.2) * (vi === 1 ? 1.1 : 1);
        const w = 104 * s, h = (img.height / img.width) * 104 * s;
        addProp({ x: jx, y: jy, img, w, h, kind: "tree", blocks: true, radius: 0.55, occludes: true });
        mark(jx, jy, 1.6);
      } else if (rk > 0.72 && rng.chance(0.35)) {
        const vi = propVariant(rng, "rock");
        const img = propImgs[vi];
        const s = rng.range(0.7, 1.1) * (vi === 5 ? 1.2 : 1);
        const w = 64 * s, h = (img.height / img.width) * 64 * s;
        addProp({ x: jx, y: jy, img, w, h, kind: "rock", blocks: vi !== 7, radius: vi === 5 ? 0.9 : 0.5, occludes: vi === 5 });
        mark(jx, jy, 1.2);
      } else if (f > 0.42 && rng.chance(0.05)) {
        const vi = propVariant(rng, "bush");
        const img = propImgs[vi];
        const w = 48, h = (img.height / img.width) * 48;
        addProp({ x: jx, y: jy, img, w, h, kind: "bush", blocks: false, radius: 0, occludes: false });
        mark(jx, jy, 1);
      }
    }

  // --- enemy spawns: camps at POIs + scattered packs (tier by distance)
  const maxD = Math.hypot(W, H) * 0.75;
  const tierFor = (d: number) => Math.min(act.enemies.length - 1, Math.floor((d / maxD) * act.enemies.length * 1.3));
  for (const p of r.pois) {
    if (p.id === "waystone") continue;
    if (p.id === "lair") { r.spawns.push({ x: p.x, y: p.y, typeIndex: 0, count: 1, boss: true, radius: 0 }); r.spawns.push({ x: p.x, y: p.y, typeIndex: act.enemies.length - 1, count: 5, radius: 4 }); continue; }
    const d = dist(p.x, p.y, r.village.cx, r.village.cy);
    r.spawns.push({ x: p.x, y: p.y, typeIndex: tierFor(d), count: rng.int(5, 8), radius: 4, elite: p.id === "camp" && p.index === 3 });
  }
  const packs = Math.floor((W * H) / 420);
  for (let i = 0; i < packs; i++) {
    for (let t = 0; t < 40; t++) {
      const x = rng.int(6, W - 7), y = rng.int(6, H - 7);
      const d = dist(x, y, r.village.cx, r.village.cy);
      if (d < r.village.radius + 9) continue;
      if (!isWalkable(r, x + 0.5, y + 0.5)) continue;
      let ti = tierFor(d) + (rng.chance(0.3) ? -1 : 0);
      ti = Math.max(0, Math.min(act.enemies.length - 1, ti));
      r.spawns.push({ x: x + 0.5, y: y + 0.5, typeIndex: ti, count: rng.int(2, 5), radius: 2.5, elite: rng.chance(0.08) });
      break;
    }
  }
  // depth sort props once (y then x)
  r.props.sort((a, b) => a.x + a.y - (b.x + b.y));
  return r;
}

/** Utility to pre-scale large sprites once (huts) – kept for future use. */
export const prescale = scaleCanvas;
