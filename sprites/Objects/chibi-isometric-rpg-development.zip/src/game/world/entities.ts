/**
 * Entity types, derived stats and save format. Simulation lives in scenes/play.ts.
 */
import type { AnimName, Dir4, Sheet } from "../core/assets";
import type { EnemyTypeDef } from "../data/acts";
import { ClassId, classById, EVOLUTION_LEVEL } from "../data/classes";
import { effectiveStats, Item, ItemStats, Slot } from "../data/items";

export interface SaveData {
  version: 1;
  name: string;
  classId: ClassId;
  evolved: boolean;
  seed: string;
  level: number;
  xp: number;
  statPoints: number;
  stats: { str: number; dex: number; vit: number; ene: number };
  gold: number;
  inventory: Item[];
  equipment: Partial<Record<Slot, Item>>;
  act: number;
  maxAct: number;
  chapterIndex: Record<number, number>; // act -> index of current chapter
  chapterProgress: number;
  waypoints: string[]; // "1:village", "1:waystone"
  poisFound: string[]; // "1:altar"
  playtime: number;
  hp: number;
  mp: number;
  bossesKilled: string[];
  deaths: number;
  kills: number;
  shopSeed: number;
  lastSmithUpgradeAct?: number;
}

export function newSave(name: string, classId: ClassId, seed: string): SaveData {
  const c = classById(classId);
  const s: SaveData = {
    version: 1, name, classId, evolved: false, seed, level: 1, xp: 0, statPoints: 0,
    stats: { ...c.base }, gold: 50, inventory: [], equipment: {}, act: 1, maxAct: 1,
    chapterIndex: { 1: 0 }, chapterProgress: 0, waypoints: ["1:village"], poisFound: [], playtime: 0,
    hp: 0, mp: 0, bossesKilled: [], deaths: 0, kills: 0, shopSeed: Math.floor(Math.random() * 1e9),
  };
  const d = derived(s);
  s.hp = d.maxHp;
  s.mp = d.maxMp;
  return s;
}

export interface Derived {
  maxHp: number; maxMp: number; dmg: number; armor: number; reduction: number; speed: number; crit: number; lifeSteal: number; regen: number;
  attackRange: number; attackSpeed: number;
}

export function xpToNext(level: number) {
  return Math.floor(80 * Math.pow(level, 1.9));
}

export function sumItemStats(s: SaveData): ItemStats {
  const out: ItemStats = {};
  for (const k of Object.keys(s.equipment) as Slot[]) {
    const it = s.equipment[k];
    if (!it) continue;
    const es = effectiveStats(it);
    for (const key of Object.keys(es) as (keyof ItemStats)[]) out[key] = (out[key] ?? 0) + (es[key] ?? 0);
  }
  return out;
}

export function derived(s: SaveData): Derived {
  const c = classById(s.classId);
  const it = sumItemStats(s);
  const str = s.stats.str + (it.str ?? 0), dex = s.stats.dex + (it.dex ?? 0), vit = s.stats.vit + (it.vit ?? 0), ene = s.stats.ene + (it.ene ?? 0);
  const caster = c.id === "sorcerer" || c.id === "necromancer";
  const evoBonus = s.evolved ? 1.25 : 1;
  const maxHp = Math.round((40 + vit * c.growth.hp + s.level * 6 + (it.hp ?? 0)) * evoBonus);
  const maxMp = Math.round((20 + ene * c.growth.mp + s.level * 3 + (it.mp ?? 0)) * evoBonus);
  const dmg = Math.round((4 + s.level * 1.4 + (caster ? ene * 0.6 : str * 0.6) + (it.dmg ?? 0) * 1.2) * evoBonus);
  const armor = (it.armor ?? 0) + dex * 0.3 + (c.id === "warrior" ? s.level * 1.5 : 0);
  const reduction = Math.min(0.72, armor / (armor + 30 + s.level * 7));
  const speed = 4.4 * (1 + (it.speed ?? 0) / 100);
  return {
    maxHp, maxMp, dmg, armor: Math.round(armor), reduction, speed,
    crit: 5 + dex * 0.15 + (it.crit ?? 0),
    lifeSteal: it.lifeSteal ?? 0,
    regen: (it.regen ?? 0) + (c.id === "priest" ? 0.5 : 0),
    attackRange: c.ranged ? 7 : 1.4,
    attackSpeed: 1 + dex * 0.004,
  };
}

export const canEvolve = (s: SaveData) => !s.evolved && s.level >= EVOLUTION_LEVEL;

/* ------------------------------------------------------------------ */

export type Faction = "player" | "enemy" | "npc" | "ally";

export interface Actor {
  id: number;
  x: number; y: number;
  dir: Dir4;
  anim: AnimName;
  frame: number;
  animT: number;
  playing: boolean; // non-looping anim in progress
  sheet: Sheet;
  scale: number;
  hp: number; maxHp: number;
  dead: boolean;
  deadT: number;
  faction: Faction;
  speed: number;
  radius: number;
  flash: number;
  name: string;
}

export interface Enemy extends Actor {
  faction: "enemy";
  def: EnemyTypeDef;
  level: number;
  dmg: number;
  xp: number;
  homeX: number; homeY: number;
  state: "idle" | "chase" | "attack" | "return";
  attackCd: number;
  attackHit: boolean;
  elite: boolean;
  boss: boolean;
  wanderT: number;
  wx: number; wy: number;
  slow: number; // seconds
  cursed: number;
  aggro: number;
  corpseUsed: boolean;
  stun: number;
}

export interface Ally extends Actor {
  faction: "ally";
  dmg: number;
  life: number;
  attackCd: number;
  attackHit: boolean;
  target: Enemy | null;
}

export interface Npc extends Actor {
  faction: "npc";
  role: "elder" | "smith" | "merchant" | "traveler";
  title: string;
  bobT: number;
}

export interface Projectile {
  x: number; y: number; vx: number; vy: number;
  dmg: number; owner: Faction; color: string; color2?: string;
  radius: number; pierce: number; life: number; kind: "fire" | "holy" | "bone" | "dark" | "ice" | "arrow"; hit: Set<number>;
  splash?: number;
}

export interface Drop {
  id: number;
  x: number; y: number;
  item: Item;
  bob: number;
  gold?: number;
  life: number;
}

export interface FloatText { x: number; y: number; text: string; color: string; life: number; vy: number; size: number }

export interface Effect {
  kind: "ring" | "beam" | "pillar" | "crack" | "meteor" | "aura" | "slashArc" | "summonCircle" | "portalBurst";
  x: number; y: number; x2?: number; y2?: number;
  radius?: number; color: string; color2?: string; life: number; maxLife: number; data?: number;
}

let actorId = 1;
export const nextActorId = () => actorId++;
