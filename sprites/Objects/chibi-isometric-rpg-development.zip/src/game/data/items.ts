/**
 * Items: equipment (5 slots), potions and quest materials.
 * Equipment is generated procedurally from level + rarity + affix tables (Diablo-like).
 */
import { RNG } from "../core/rng";

export type Slot = "weapon" | "armor" | "helm" | "boots" | "ring";
export type Rarity = "normal" | "magic" | "rare" | "unique";
export type ItemKind = "equip" | "potion_hp" | "potion_mp" | "material" | "gold";

export interface ItemStats {
  dmg?: number; armor?: number; str?: number; dex?: number; vit?: number; ene?: number;
  hp?: number; mp?: number; lifeSteal?: number; speed?: number; crit?: number; regen?: number;
}

export interface Item {
  uid: number;
  kind: ItemKind;
  name: string;
  slot?: Slot;
  rarity: Rarity;
  level: number;
  stats: ItemStats;
  upgrade: number;
  price: number;
  qty: number;
  materialId?: string;
  potionSize?: number; // 1 small, 2 medium, 3 large
}

let UID = 1;
export const nextUid = () => UID++;
export const setUidFloor = (n: number) => { UID = Math.max(UID, n + 1); };

export const RARITY_COLOR: Record<Rarity, string> = { normal: "#e8dcc0", magic: "#6f8cff", rare: "#ffe55a", unique: "#c98a4a" };

const BASES: Record<Slot, { names: string[]; main: "dmg" | "armor"; mult: number }> = {
  weapon: { names: ["Espada Curta", "Machado", "Maça", "Cajado", "Lâmina Longa", "Martelo de Guerra", "Cetro", "Foice"], main: "dmg", mult: 3.2 },
  armor: { names: ["Gibão", "Cota de Malha", "Couraça", "Manto", "Armadura de Placas", "Veste Rúnica"], main: "armor", mult: 2.4 },
  helm: { names: ["Capuz", "Elmo", "Coroa", "Máscara", "Capacete de Ferro"], main: "armor", mult: 1.2 },
  boots: { names: ["Botas", "Grevas", "Sandálias", "Botas de Couro"], main: "armor", mult: 0.9 },
  ring: { names: ["Anel", "Amuleto", "Sinete", "Talismã"], main: "armor", mult: 0.3 },
};

const PREFIXES: { n: string; s: ItemStats }[] = [
  { n: "Brutal", s: { str: 4 } }, { n: "Ágil", s: { dex: 4 } }, { n: "Robusto", s: { vit: 4 } }, { n: "Arcano", s: { ene: 4 } },
  { n: "Sanguinário", s: { lifeSteal: 3 } }, { n: "Veloz", s: { speed: 6 } }, { n: "Cruel", s: { crit: 5 } }, { n: "Vital", s: { hp: 25 } },
  { n: "Místico", s: { mp: 20 } }, { n: "Regenerativo", s: { regen: 1 } },
];
const SUFFIXES: { n: string; s: ItemStats }[] = [
  { n: "do Urso", s: { str: 6, vit: 2 } }, { n: "da Raposa", s: { dex: 6 } }, { n: "do Titã", s: { vit: 7 } }, { n: "da Coruja", s: { ene: 7 } },
  { n: "do Vampiro", s: { lifeSteal: 5 } }, { n: "do Vento", s: { speed: 10 } }, { n: "da Precisão", s: { crit: 8 } }, { n: "da Vida", s: { hp: 45 } },
  { n: "da Mente", s: { mp: 40 } }, { n: "das Cinzas", s: { dmg: 4 } }, { n: "da Rocha", s: { armor: 6 } },
];
const UNIQUES: { n: string; slot: Slot; s: ItemStats }[] = [
  { n: "Lamento de Vorhal", slot: "weapon", s: { dmg: 12, lifeSteal: 8, str: 10 } },
  { n: "Coração de Mammon", slot: "ring", s: { hp: 120, mp: 80, vit: 10 } },
  { n: "Véu de Asmodeus", slot: "helm", s: { ene: 15, crit: 12, mp: 60 } },
  { n: "Ira de Azazel", slot: "armor", s: { armor: 25, str: 15, hp: 150 } },
  { n: "Passos do Imperador", slot: "boots", s: { speed: 25, dex: 15, armor: 10 } },
];

function scale(v: number, level: number, rng: RNG) {
  return Math.max(1, Math.round(v * (1 + level * 0.28) * rng.range(0.85, 1.15)));
}

export function rollRarity(rng: RNG, magicFind = 0): Rarity {
  const r = rng.next() * (1 - Math.min(0.5, magicFind / 200));
  if (r < 0.02) return "unique";
  if (r < 0.12) return "rare";
  if (r < 0.42) return "magic";
  return "normal";
}

export function generateEquip(rng: RNG, level: number, forcedRarity?: Rarity, forcedSlot?: Slot): Item {
  const rarity = forcedRarity ?? rollRarity(rng);
  const slot = forcedSlot ?? rng.pick(["weapon", "weapon", "armor", "helm", "boots", "ring"] as Slot[]);
  const base = BASES[slot];
  const stats: ItemStats = {};
  stats[base.main] = scale(base.mult * 3, level, rng);
  let name = rng.pick(base.names);
  const addStats = (s: ItemStats, mult: number) => {
    for (const k of Object.keys(s) as (keyof ItemStats)[]) stats[k] = (stats[k] ?? 0) + scale((s[k] ?? 0) * mult, level, rng);
  };
  if (rarity === "unique") {
    const u = rng.pick(UNIQUES.filter((x) => x.slot === slot)) ?? UNIQUES[0];
    name = u.n;
    addStats(u.s, 0.7);
  } else if (rarity === "rare") {
    const p = rng.pick(PREFIXES), s = rng.pick(SUFFIXES);
    name = `${p.n} ${name} ${s.n}`;
    addStats(p.s, 0.6);
    addStats(s.s, 0.6);
    addStats(rng.pick(PREFIXES).s, 0.4);
  } else if (rarity === "magic") {
    if (rng.chance(0.5)) { const p = rng.pick(PREFIXES); name = `${p.n} ${name}`; addStats(p.s, 0.6); }
    else { const s = rng.pick(SUFFIXES); name = `${name} ${s.n}`; addStats(s.s, 0.6); }
  }
  const priceMult = { normal: 1, magic: 2.5, rare: 6, unique: 15 }[rarity];
  return { uid: nextUid(), kind: "equip", name, slot, rarity, level, stats, upgrade: 0, price: Math.round((20 + level * 12) * priceMult), qty: 1 };
}

export function makePotion(kind: "potion_hp" | "potion_mp", size: 1 | 2 | 3, qty = 1): Item {
  const names = kind === "potion_hp" ? ["Poção de Vida Menor", "Poção de Vida", "Poção de Vida Maior"] : ["Poção de Mana Menor", "Poção de Mana", "Poção de Mana Maior"];
  return { uid: nextUid(), kind, name: names[size - 1], rarity: "normal", level: size * 10, stats: {}, upgrade: 0, price: [25, 90, 300][size - 1], qty, potionSize: size };
}
export const potionAmount = (size: number) => [60, 220, 700][size - 1] ?? 60;

export function makeMaterial(id: string, name: string, qty = 1): Item {
  return { uid: nextUid(), kind: "material", name, rarity: "magic", level: 1, stats: {}, upgrade: 0, price: 5, qty, materialId: id };
}

/** Effective stats including upgrade bonus (+8% main stat per level). */
export function effectiveStats(it: Item): ItemStats {
  const out: ItemStats = { ...it.stats };
  if (it.upgrade > 0) {
    const m = 1 + it.upgrade * 0.08;
    if (out.dmg) out.dmg = Math.round(out.dmg * m);
    if (out.armor) out.armor = Math.round(out.armor * m);
  }
  return out;
}

export const upgradeCost = (it: Item) => Math.round((40 + it.level * 15) * Math.pow(1.6, it.upgrade));

export const STAT_LABEL: Record<keyof ItemStats, string> = {
  dmg: "Dano", armor: "Armadura", str: "Força", dex: "Destreza", vit: "Vitalidade", ene: "Energia", hp: "Vida", mp: "Mana",
  lifeSteal: "Roubo de Vida %", speed: "Velocidade %", crit: "Crítico %", regen: "Regen. Vida/s",
};

/** Draws a small hand-styled icon for an item into the given rect. */
export function drawItemIcon(ctx: CanvasRenderingContext2D, it: Item, x: number, y: number, s: number) {
  ctx.save();
  ctx.translate(x + s / 2, y + s / 2);
  const col = RARITY_COLOR[it.rarity];
  ctx.lineWidth = 2;
  ctx.strokeStyle = "#1a0b05";
  if (it.kind === "potion_hp" || it.kind === "potion_mp") {
    const c = it.kind === "potion_hp" ? "#d8282a" : "#2a62d8";
    const sz = 0.5 + (it.potionSize ?? 1) * 0.15;
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(0, s * 0.12, s * 0.28 * sz, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#c9a24a";
    ctx.fillRect(-s * 0.08, -s * 0.38 * sz, s * 0.16, s * 0.2);
    ctx.strokeRect(-s * 0.08, -s * 0.38 * sz, s * 0.16, s * 0.2);
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.beginPath(); ctx.arc(-s * 0.08, s * 0.04, s * 0.07, 0, Math.PI * 2); ctx.fill();
  } else if (it.kind === "material") {
    ctx.fillStyle = "#9fd88a";
    ctx.beginPath(); ctx.moveTo(0, -s * 0.3); ctx.lineTo(s * 0.25, 0); ctx.lineTo(0, s * 0.3); ctx.lineTo(-s * 0.25, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
  } else if (it.kind === "gold") {
    ctx.fillStyle = "#ffd25a";
    ctx.beginPath(); ctx.arc(0, 0, s * 0.28, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  } else {
    ctx.fillStyle = col;
    switch (it.slot) {
      case "weapon":
        ctx.rotate(-Math.PI / 4);
        ctx.fillStyle = "#c8ccd8"; ctx.fillRect(-s * 0.06, -s * 0.38, s * 0.12, s * 0.6); ctx.strokeRect(-s * 0.06, -s * 0.38, s * 0.12, s * 0.6);
        ctx.fillStyle = col; ctx.fillRect(-s * 0.2, s * 0.2, s * 0.4, s * 0.08); ctx.strokeRect(-s * 0.2, s * 0.2, s * 0.4, s * 0.08);
        ctx.fillStyle = "#5a3a1a"; ctx.fillRect(-s * 0.05, s * 0.28, s * 0.1, s * 0.16);
        break;
      case "armor":
        ctx.beginPath(); ctx.moveTo(-s * 0.3, -s * 0.3); ctx.lineTo(s * 0.3, -s * 0.3); ctx.lineTo(s * 0.34, 0); ctx.lineTo(s * 0.2, s * 0.34); ctx.lineTo(-s * 0.2, s * 0.34); ctx.lineTo(-s * 0.34, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.fillRect(-s * 0.05, -s * 0.25, s * 0.1, s * 0.5);
        break;
      case "helm":
        ctx.beginPath(); ctx.arc(0, 0, s * 0.3, Math.PI, 0); ctx.lineTo(s * 0.3, s * 0.2); ctx.lineTo(-s * 0.3, s * 0.2); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = "#1a0b05"; ctx.fillRect(-s * 0.22, s * 0.0, s * 0.44, s * 0.08);
        break;
      case "boots":
        ctx.beginPath(); ctx.moveTo(-s * 0.15, -s * 0.3); ctx.lineTo(s * 0.1, -s * 0.3); ctx.lineTo(s * 0.1, s * 0.1); ctx.lineTo(s * 0.32, s * 0.25); ctx.lineTo(-s * 0.15, s * 0.3); ctx.closePath(); ctx.fill(); ctx.stroke();
        break;
      case "ring":
        ctx.lineWidth = s * 0.1; ctx.strokeStyle = col;
        ctx.beginPath(); ctx.arc(0, s * 0.05, s * 0.22, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = "#ff5a8a"; ctx.beginPath(); ctx.arc(0, -s * 0.2, s * 0.1, 0, Math.PI * 2); ctx.fill();
        break;
    }
  }
  ctx.restore();
}
