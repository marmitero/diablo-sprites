/**
 * Act / biome / bestiary / chapter definitions. See docs/CONTENT.md.
 * Chapters are templates: the per-run RNG picks 8..12 of them (boss always last, in order of `tier`).
 */
import type { BiomeStyle } from "../core/assets";
import type { AnimName } from "../core/assets";

export interface EnemyTypeDef {
  id: string;
  name: string;
  layers: string[];
  hp: number; // base at level 1 (scaled)
  dmg: number;
  speed: number; // tiles/s
  xp: number;
  ranged?: boolean;
  attackAnim: AnimName;
  scale?: number;
  aggro?: number; // tiles
  projectileColor?: string;
  boss?: boolean;
  dropMult?: number;
}

export type ChapterKind = "kill" | "collect" | "deliver" | "explore" | "elite" | "boss";

export interface ChapterTemplate {
  id: string;
  title: string;
  kind: ChapterKind;
  text: string; // Elder's briefing
  done: string; // Elder's reply when done
  target?: string; // enemy type id / item id / poi id / npc id
  count?: number;
  tier: number; // ordering bucket 0..3 (boss = 9)
  rewardGold: number;
  rewardXp: number;
}

export interface ActDef {
  id: number;
  name: string;
  subtitle: string;
  villageName: string;
  biome: BiomeStyle;
  propHue: number; // hue-rotate for forest props to re-skin per biome
  propSat: number;
  propBright: number;
  hutHue: number;
  liquidKind: "water" | "lava" | "none" | "acid" | "ice";
  levelRange: [number, number];
  enemies: EnemyTypeDef[];
  boss: EnemyTypeDef;
  chapters: ChapterTemplate[];
  intro: string;
  bossIntro: string;
  outro: string;
  collectible: { id: string; name: string };
  music: "act1" | "act2" | "act3" | "act4" | "act5";
  ambientColor: string; // tint overlay
  size: number; // map size (tiles)
}

const human = (hair: string, torso: string, legs: string, feet: string, wpn: string, extra: string[] = []) => ["body_tanned", feet, legs, torso, hair, wpn, ...extra];

export const ACTS: ActDef[] = [
  {
    id: 1,
    name: "Ato I — As Cinzas de Belial",
    subtitle: "Floresta de Vorhal",
    villageName: "Aldeia de Vorhal",
    biome: { ground: ["#2f4a22", "#4a6b2c", "#6f8f3c"], detail: "#8fb04a", path: ["#6b4a2a", "#a07a4a"], liquid: ["#1e3f5a", "#3a7aa8"], liquidGlow: "#9adfff" },
    propHue: 0, propSat: 1, propBright: 1, hutHue: 0,
    liquidKind: "water",
    levelRange: [1, 12],
    enemies: [
      { id: "zombie", name: "Zumbi Camponês", layers: ["body_dark", "legs_white", "torso_shirt_brown", "hair_messy_black", "tint:#3a6a3a@0.45"], hp: 28, dmg: 5, speed: 1.6, xp: 8, attackAnim: "slash" },
      { id: "skeleton", name: "Esqueleto", layers: ["body_skeleton", "wpn_dagger"], hp: 22, dmg: 6, speed: 2.4, xp: 10, attackAnim: "slash" },
      { id: "cultist", name: "Cultista de Belial", layers: human("hair_long_raven", "torso_shirt_maroon", "legs_robe", "feet_black", "wpn_wand", ["head_cloth_hood"]), hp: 20, dmg: 7, speed: 2.0, xp: 12, ranged: true, attackAnim: "spellcast", projectileColor: "#ff4a4a" },
      { id: "bandit", name: "Desertor", layers: human("hair_mohawk_red", "torso_leather", "legs_red", "feet_brown", "wpn_saber", ["head_bandana"]), hp: 34, dmg: 8, speed: 2.6, xp: 14, attackAnim: "slash" },
    ],
    boss: { id: "belial", name: "Belial, Senhor das Mentiras", layers: ["body_red_orc", "legs_gold", "torso_gold", "torso_gold_arms", "hands_gold", "head_gold_helm", "wpn_longsword", "tint:#ff2a2a@0.25"], hp: 900, dmg: 22, speed: 2.2, xp: 600, attackAnim: "slash", scale: 2.1, aggro: 9, boss: true, dropMult: 6 },
    chapters: [
      { id: "a1c1", title: "Os Mortos Caminham", kind: "kill", target: "zombie", count: 8, tier: 0, text: "Os nossos mortos não descansam. Zumbis rondam a orla da floresta. Dê-lhes paz, herói.", done: "Que descansem. Mas isso é só o começo.", rewardGold: 60, rewardXp: 40 },
      { id: "a1c2", title: "Ervas para o Ferreiro", kind: "collect", target: "herb", count: 6, tier: 0, text: "O ferreiro precisa de Raízes de Cinza para temperar o aço. Os monstros as carregam... por que, não sei.", done: "Ótimo. Leve-as ao ferreiro depois, ele saberá o que fazer.", rewardGold: 50, rewardXp: 35 },
      { id: "a1c3", title: "Entrega ao Ferreiro", kind: "deliver", target: "smith", count: 1, tier: 1, text: "Entregue as raízes ao ferreiro Gorm. Fale com ele.", done: "Gorm me contou. Seu equipamento vai agradecer.", rewardGold: 40, rewardXp: 30 },
      { id: "a1c4", title: "Ossos Inquietos", kind: "kill", target: "skeleton", count: 12, tier: 1, text: "Esqueletos saem do antigo cemitério. Destrua-os antes que cheguem à aldeia.", done: "Ouço menos ossos rangendo à noite. Obrigado.", rewardGold: 80, rewardXp: 60 },
      { id: "a1c5", title: "O Altar Profano", kind: "explore", target: "altar", count: 1, tier: 1, text: "Os cultistas construíram um altar na floresta. Encontre-o e marque sua localização.", done: "Então é verdade. Eles invocam algo ali...", rewardGold: 70, rewardXp: 70 },
      { id: "a1c6", title: "Cultistas de Belial", kind: "kill", target: "cultist", count: 10, tier: 2, text: "Os cultistas sussurram o nome dele. Silencie-os.", done: "Silêncio... finalmente.", rewardGold: 100, rewardXp: 90 },
      { id: "a1c7", title: "O Capitão Desertor", kind: "elite", target: "bandit", count: 1, tier: 2, text: "Um capitão desertor comanda os bandidos. Ele é forte. Prepare-se.", done: "Um traidor a menos neste mundo.", rewardGold: 150, rewardXp: 120 },
      { id: "a1c8", title: "Suprimentos para o Mercador", kind: "collect", target: "herb", count: 10, tier: 2, text: "O mercador precisa de mais raízes para as poções. Colete e traga.", done: "As poções agora serão mais fortes.", rewardGold: 90, rewardXp: 70 },
      { id: "a1c9", title: "A Pedra do Portal", kind: "explore", target: "waystone", count: 1, tier: 2, text: "Há uma pedra antiga que ecoa com o portal da aldeia. Ative-a para viajar mais rápido.", done: "Agora os caminhos se encurtam.", rewardGold: 60, rewardXp: 80 },
      { id: "a1c10", title: "A Horda", kind: "kill", target: "any", count: 30, tier: 3, text: "Eles vêm em números. Diminua a horda antes de enfrentar o senhor deles.", done: "Você está pronto. Eu sinto.", rewardGold: 200, rewardXp: 200 },
      { id: "a1c11", title: "Entrega ao Viajante", kind: "deliver", target: "traveler", count: 1, tier: 3, text: "O viajante tem um mapa do covil. Leve-lhe minha carta.", done: "Agora você sabe onde ele se esconde.", rewardGold: 60, rewardXp: 60 },
      { id: "a1c12", title: "A Fortaleza de Belial", kind: "boss", target: "belial", count: 1, tier: 9, text: "Belial aguarda em sua fortaleza no coração negro da floresta. Vá, e que a profecia se cumpra.", done: "Belial caiu... mas ele riu ao morrer. Disse que era apenas um dos quatro pilares. Há mais além do deserto.", rewardGold: 500, rewardXp: 500 },
    ],
    intro: "A Floresta de Vorhal já foi verde e cheia de canções. Hoje, os mortos caminham entre as árvores e o culto de Belial queima o que restou.",
    bossIntro: "BELIAL: Herói da profecia? Patético. Sou apenas um pilar. Derrube-me e o teto do mundo ainda cairá sobre você.",
    outro: "Com Belial morto, você descobre a verdade: ele era um dos Quatro Pilares do Inferno. O caminho para o deserto de Mammon se abre.",
    collectible: { id: "herb", name: "Raiz de Cinza" },
    music: "act1",
    ambientColor: "rgba(0,0,0,0)",
    size: 112,
  },
  {
    id: 2,
    name: "Ato II — A Ganância de Mammon",
    subtitle: "Deserto de Qaresh",
    villageName: "Oásis de Qaresh",
    biome: { ground: ["#9a7a44", "#c9a560", "#e8cf8a"], detail: "#f3e3b0", path: ["#7a5a34", "#b08a58"], liquid: ["#1e5f6a", "#3aa8b8"], liquidGlow: "#bffcff" },
    propHue: -15, propSat: 0.45, propBright: 1.12, hutHue: 20,
    liquidKind: "water",
    levelRange: [12, 24],
    enemies: [
      { id: "sandghoul", name: "Ghoul das Areias", layers: ["body_dark", "legs_white", "hair_messy_black", "tint:#c9a560@0.4"], hp: 70, dmg: 14, speed: 2.4, xp: 30, attackAnim: "slash" },
      { id: "scarabwarrior", name: "Lacaio de Mammon", layers: human("hair_shorthawk_gray", "torso_gold", "legs_gold", "feet_gold", "wpn_saber", ["hands_gold"]), hp: 95, dmg: 17, speed: 2.4, xp: 38, attackAnim: "slash" },
      { id: "sandmage", name: "Vidente da Areia", layers: human("hair_long_white", "torso_shirt_white", "legs_robe", "feet_brown", "wpn_wand", ["head_cloth_hood"]), hp: 60, dmg: 20, speed: 2.0, xp: 42, ranged: true, attackAnim: "spellcast", projectileColor: "#ffd25a" },
      { id: "goldskel", name: "Esqueleto Dourado", layers: ["body_skeleton", "legs_gold", "torso_gold", "head_gold_helm", "wpn_spear"], hp: 85, dmg: 16, speed: 2.8, xp: 36, attackAnim: "thrust" },
      { id: "dunebandit", name: "Saqueador das Dunas", layers: human("hair_bedhead_raven", "torso_leather", "legs_magenta", "feet_brown", "wpn_dagger", ["head_bandana"]), hp: 80, dmg: 15, speed: 3.0, xp: 34, attackAnim: "slash" },
    ],
    boss: { id: "mammon", name: "Mammon, o Devorador de Ouro", layers: ["body_orc", "legs_gold", "torso_gold", "torso_gold_arms", "hands_gold", "head_gold_helm", "wpn_mace", "tint:#ffd25a@0.3"], hp: 3200, dmg: 48, speed: 2.0, xp: 2200, attackAnim: "slash", scale: 2.3, aggro: 9, boss: true, dropMult: 8 },
    chapters: [
      { id: "a2c1", title: "Fome das Areias", kind: "kill", target: "sandghoul", count: 12, tier: 0, text: "Ghouls devoram as caravanas. Limpe as dunas próximas.", done: "As caravanas agradecem.", rewardGold: 200, rewardXp: 150 },
      { id: "a2c2", title: "Fragmentos de Ouro Amaldiçoado", kind: "collect", target: "gold", count: 8, tier: 0, text: "Mammon espalha ouro amaldiçoado. Colete fragmentos para que o ferreiro os purifique.", done: "Ouro sujo de sangue. Mas útil.", rewardGold: 180, rewardXp: 140 },
      { id: "a2c3", title: "A Forja do Oásis", kind: "deliver", target: "smith", count: 1, tier: 1, text: "Leve os fragmentos ao ferreiro.", done: "Ele conseguiu fundir. Impressionante.", rewardGold: 120, rewardXp: 100 },
      { id: "a2c4", title: "Lacaios Dourados", kind: "kill", target: "scarabwarrior", count: 14, tier: 1, text: "Os lacaios de Mammon guardam o templo. Reduza suas fileiras.", done: "Menos guardas, mais chance.", rewardGold: 260, rewardXp: 200 },
      { id: "a2c5", title: "O Templo Enterrado", kind: "explore", target: "altar", count: 1, tier: 1, text: "Dizem que há um templo soterrado. Encontre sua entrada.", done: "Então Mammon dorme sob a areia.", rewardGold: 220, rewardXp: 220 },
      { id: "a2c6", title: "Videntes Cegos", kind: "kill", target: "sandmage", count: 12, tier: 2, text: "Os videntes guiam os ghouls. Cegue-os para sempre.", done: "Os ghouls vagam sem rumo agora.", rewardGold: 300, rewardXp: 250 },
      { id: "a2c7", title: "O Cobrador", kind: "elite", target: "goldskel", count: 1, tier: 2, text: "Um esqueleto dourado gigante cobra pedágio na estrada. Mate-o.", done: "Estrada livre.", rewardGold: 400, rewardXp: 320 },
      { id: "a2c8", title: "Pedra do Portal", kind: "explore", target: "waystone", count: 1, tier: 2, text: "Ative a pedra do portal do deserto.", done: "Viajar ficou mais fácil.", rewardGold: 150, rewardXp: 200 },
      { id: "a2c9", title: "Tributo ao Mercador", kind: "collect", target: "gold", count: 14, tier: 2, text: "O mercador quer fragmentos para poções maiores.", done: "Poções melhores à venda.", rewardGold: 280, rewardXp: 220 },
      { id: "a2c10", title: "Tempestade de Lâminas", kind: "kill", target: "any", count: 45, tier: 3, text: "Reduza a horda do deserto.", done: "Você está pronto para o templo.", rewardGold: 500, rewardXp: 500 },
      { id: "a2c11", title: "O Templo de Mammon", kind: "boss", target: "mammon", count: 1, tier: 9, text: "Mammon espera no templo dourado. Não se deixe seduzir.", done: "Mammon caiu. O pântano de Asmodeus é o próximo.", rewardGold: 1200, rewardXp: 1500 },
    ],
    intro: "O Deserto de Qaresh esconde o Templo de Mammon. Aqui, a ganância tem dentes e o ouro é amaldiçoado.",
    bossIntro: "MAMMON: Tudo tem um preço, herói. O seu será a sua alma.",
    outro: "Mammon jaz morto sobre seu ouro. Dois pilares restam. O Pântano Putrefato de Asmodeus o aguarda.",
    collectible: { id: "gold", name: "Fragmento de Ouro Amaldiçoado" },
    music: "act2",
    ambientColor: "rgba(255,200,100,0.06)",
    size: 120,
  },
  {
    id: 3,
    name: "Ato III — A Luxúria de Asmodeus",
    subtitle: "Pântano Putrefato",
    villageName: "Palafitas de Morr",
    biome: { ground: ["#1e2a1a", "#2f4428", "#4a5f30"], detail: "#6f8f3c", path: ["#3a2f22", "#5f4f3a"], liquid: ["#2a3a14", "#4f6a22"], liquidGlow: "#a0ff5a" },
    propHue: 25, propSat: 0.7, propBright: 0.75, hutHue: 60,
    liquidKind: "acid",
    levelRange: [24, 36],
    enemies: [
      { id: "bogwretch", name: "Miserável do Lodo", layers: ["body_orc", "legs_white", "tint:#3a5a2a@0.4"], hp: 180, dmg: 30, speed: 2.2, xp: 80, attackAnim: "slash" },
      { id: "succubus", name: "Súcubo", layers: human("hair_long_raven", "torso_shirt_maroon", "legs_magenta", "feet_black", "wpn_wand", ["tint:#ff3a8a@0.2"]), hp: 150, dmg: 36, speed: 2.8, xp: 95, ranged: true, attackAnim: "spellcast", projectileColor: "#ff3a9a" },
      { id: "plagueknight", name: "Cavaleiro da Peste", layers: ["body_darkelf", "legs_metal", "torso_chain", "torso_plate", "head_chain_hood", "wpn_longsword", "tint:#3a6a2a@0.3"], hp: 260, dmg: 40, speed: 2.3, xp: 110, attackAnim: "slash" },
      { id: "swampskel", name: "Esqueleto Pantanoso", layers: ["body_skeleton", "wpn_spear", "tint:#4a7a2a@0.4"], hp: 170, dmg: 32, speed: 2.9, xp: 85, attackAnim: "thrust" },
      { id: "witch", name: "Bruxa do Brejo", layers: human("hair_long_white", "torso_shirt_brown", "legs_robe", "feet_brown", "wpn_wand", ["head_cloth_hood", "tint:#2a5a2a@0.3"]), hp: 160, dmg: 44, speed: 1.9, xp: 100, ranged: true, attackAnim: "spellcast", projectileColor: "#a0ff5a" },
    ],
    boss: { id: "asmodeus", name: "Asmodeus, Príncipe da Luxúria", layers: ["body_darkelf", "legs_robe", "torso_shirt_maroon", "hair_long_raven", "wpn_trident", "tint:#ff2a8a@0.3"], hp: 9000, dmg: 95, speed: 2.4, xp: 7000, attackAnim: "thrust", scale: 2.3, aggro: 10, boss: true, dropMult: 10 },
    chapters: [
      { id: "a3c1", title: "Lodo Vivo", kind: "kill", target: "bogwretch", count: 14, tier: 0, text: "O lodo se ergue e caminha. Destrua os miseráveis.", done: "O pântano respira um pouco melhor.", rewardGold: 600, rewardXp: 500 },
      { id: "a3c2", title: "Pétalas Venenosas", kind: "collect", target: "petal", count: 10, tier: 0, text: "Colete Pétalas de Sangue. O ferreiro faz antídotos com elas.", done: "Antídotos prontos.", rewardGold: 500, rewardXp: 450 },
      { id: "a3c3", title: "Ao Ferreiro", kind: "deliver", target: "smith", count: 1, tier: 1, text: "Entregue as pétalas ao ferreiro.", done: "Ele já trabalha.", rewardGold: 300, rewardXp: 300 },
      { id: "a3c4", title: "Sussurros", kind: "kill", target: "succubus", count: 14, tier: 1, text: "As súcubos atraem os homens para o lodo. Acabe com elas.", done: "Menos sussurros à noite.", rewardGold: 700, rewardXp: 600 },
      { id: "a3c5", title: "O Jardim Negro", kind: "explore", target: "altar", count: 1, tier: 1, text: "Asmodeus cultiva um jardim de carne. Encontre-o.", done: "Que horror...", rewardGold: 650, rewardXp: 650 },
      { id: "a3c6", title: "Cavaleiros Caídos", kind: "kill", target: "plagueknight", count: 12, tier: 2, text: "Os cavaleiros da peste já foram homens de honra. Dê-lhes um fim digno.", done: "Descansem, irmãos.", rewardGold: 800, rewardXp: 700 },
      { id: "a3c7", title: "A Bruxa-Mãe", kind: "elite", target: "witch", count: 1, tier: 2, text: "A Bruxa-Mãe comanda o coven. Mate-a.", done: "O coven se dispersa.", rewardGold: 1000, rewardXp: 900 },
      { id: "a3c8", title: "Pedra do Portal", kind: "explore", target: "waystone", count: 1, tier: 2, text: "Ative a pedra do pântano.", done: "Bom.", rewardGold: 400, rewardXp: 500 },
      { id: "a3c9", title: "Poções do Mercador", kind: "collect", target: "petal", count: 16, tier: 2, text: "O mercador precisa de pétalas.", done: "Poções maiores à venda.", rewardGold: 700, rewardXp: 600 },
      { id: "a3c10", title: "Carta ao Viajante", kind: "deliver", target: "traveler", count: 1, tier: 3, text: "O viajante conhece o caminho ao palácio. Entregue minha carta.", done: "Agora você sabe o caminho.", rewardGold: 400, rewardXp: 400 },
      { id: "a3c11", title: "A Marcha do Lodo", kind: "kill", target: "any", count: 60, tier: 3, text: "Enfraqueça as hostes do pântano.", done: "Pronto para o palácio.", rewardGold: 1200, rewardXp: 1300 },
      { id: "a3c12", title: "O Palácio de Asmodeus", kind: "boss", target: "asmodeus", count: 1, tier: 9, text: "Asmodeus o espera em seu palácio de carne. Não olhe nos olhos dele.", done: "Asmodeus está morto. As montanhas geladas de Azazel são o próximo destino.", rewardGold: 3000, rewardXp: 4000 },
    ],
    intro: "O Pântano Putrefato engole quem entra. Asmodeus governa de um palácio de carne e sussurros.",
    bossIntro: "ASMODEUS: Que determinação deliciosa. Deixe-me saboreá-la.",
    outro: "Com Asmodeus derrotado, restam Azazel e as montanhas geladas de Khar-Thul.",
    collectible: { id: "petal", name: "Pétala de Sangue" },
    music: "act3",
    ambientColor: "rgba(40,80,20,0.12)",
    size: 124,
  },
  {
    id: 4,
    name: "Ato IV — A Ira de Azazel",
    subtitle: "Montanhas de Khar-Thul",
    villageName: "Refúgio de Khar-Thul",
    biome: { ground: ["#9fb4c8", "#d0e0ee", "#f4f8ff"], detail: "#ffffff", path: ["#5a5f6a", "#8a90a0"], liquid: ["#6ab0d8", "#b0e0ff"], liquidGlow: "#ffffff" },
    propHue: 180, propSat: 0.35, propBright: 1.25, hutHue: 190,
    liquidKind: "ice",
    levelRange: [36, 50],
    enemies: [
      { id: "frostorc", name: "Orc do Gelo", layers: ["body_orc", "legs_metal", "torso_leather", "wpn_mace", "tint:#7ab8ff@0.3"], hp: 480, dmg: 70, speed: 2.4, xp: 260, attackAnim: "slash" },
      { id: "icewraith", name: "Espectro Gélido", layers: ["body_skeleton", "legs_robe", "head_cloth_hood", "wpn_wand", "tint:#9ad7ff@0.5"], hp: 380, dmg: 85, speed: 2.6, xp: 290, ranged: true, attackAnim: "spellcast", projectileColor: "#bff3ff" },
      { id: "berserker", name: "Berserker de Azazel", layers: ["body_red_orc", "legs_metal", "torso_chain", "head_metal_helm", "wpn_longsword"], hp: 620, dmg: 95, speed: 3.0, xp: 330, attackAnim: "slash" },
      { id: "frostknight", name: "Cavaleiro Congelado", layers: ["body_light", "legs_metal", "torso_plate", "torso_plate_arms", "head_metal_helm", "hands_metal", "wpn_spear", "tint:#9ad7ff@0.4"], hp: 700, dmg: 80, speed: 2.2, xp: 350, attackAnim: "thrust" },
      { id: "shaman", name: "Xamã da Nevasca", layers: human("hair_long_white", "torso_shirt_teal", "legs_robe", "feet_brown", "wpn_wand", ["head_chain_hood", "tint:#5ab8ff@0.25"]), hp: 420, dmg: 110, speed: 1.9, xp: 320, ranged: true, attackAnim: "spellcast", projectileColor: "#e0f0ff" },
    ],
    boss: { id: "azazel", name: "Azazel, o Flagelo da Ira", layers: ["body_red_orc", "legs_metal", "torso_plate", "torso_plate_arms", "hands_metal", "head_metal_helm", "wpn_longsword", "tint:#ff4a1a@0.35"], hp: 26000, dmg: 190, speed: 2.8, xp: 25000, attackAnim: "slash", scale: 2.5, aggro: 11, boss: true, dropMult: 12 },
    chapters: [
      { id: "a4c1", title: "Sangue na Neve", kind: "kill", target: "frostorc", count: 16, tier: 0, text: "Orcs do gelo cercam o refúgio. Afaste-os.", done: "A neve está vermelha, mas estamos vivos.", rewardGold: 2000, rewardXp: 2000 },
      { id: "a4c2", title: "Cristais de Ira", kind: "collect", target: "crystal", count: 12, tier: 0, text: "Cristais de Ira caem dos servos de Azazel. O ferreiro quer estudá-los.", done: "Eles pulsam de raiva.", rewardGold: 1800, rewardXp: 1800 },
      { id: "a4c3", title: "A Forja Gelada", kind: "deliver", target: "smith", count: 1, tier: 1, text: "Entregue os cristais ao ferreiro.", done: "Armas de ira. Irônico.", rewardGold: 1200, rewardXp: 1200 },
      { id: "a4c4", title: "Espectros", kind: "kill", target: "icewraith", count: 14, tier: 1, text: "Espectros gélidos congelam os caçadores. Dissipe-os.", done: "O ar está menos frio.", rewardGold: 2400, rewardXp: 2300 },
      { id: "a4c5", title: "O Trono de Gelo", kind: "explore", target: "altar", count: 1, tier: 1, text: "Encontre o trono de gelo onde Azazel julga seus prisioneiros.", done: "Um trono de corpos congelados...", rewardGold: 2200, rewardXp: 2500 },
      { id: "a4c6", title: "Fúria Cega", kind: "kill", target: "berserker", count: 14, tier: 2, text: "Berserkers avançam sem medo. Mostre a eles o que é medo.", done: "Eles temem agora.", rewardGold: 2800, rewardXp: 2800 },
      { id: "a4c7", title: "O Campeão de Azazel", kind: "elite", target: "frostknight", count: 1, tier: 2, text: "O campeão de Azazel guarda a passagem. Derrube-o.", done: "A passagem está aberta.", rewardGold: 3500, rewardXp: 3500 },
      { id: "a4c8", title: "Pedra do Portal", kind: "explore", target: "waystone", count: 1, tier: 2, text: "Ative a pedra das montanhas.", done: "Bom.", rewardGold: 1500, rewardXp: 2000 },
      { id: "a4c9", title: "Avalanche", kind: "kill", target: "any", count: 70, tier: 3, text: "Diminua as hostes antes da cidadela.", done: "Pronto.", rewardGold: 4000, rewardXp: 5000 },
      { id: "a4c10", title: "A Cidadela de Azazel", kind: "boss", target: "azazel", count: 1, tier: 9, text: "Azazel o espera na cidadela do pico. Sua ira é lendária. A sua precisa ser maior.", done: "Azazel caiu... e então uma aparição surgiu: LÚCIFER. Ele o julga por se envolver e o desafia a ir aos seus domínios.", rewardGold: 10000, rewardXp: 15000 },
    ],
    intro: "As Montanhas de Khar-Thul são o reino da Ira. Azazel comanda orcs do gelo de uma cidadela no pico mais alto.",
    bossIntro: "AZAZEL: VENHA! Deixe-me esmagar essa profecia com minhas próprias mãos!",
    outro: "Azazel cai. Das sombras, uma aparição: LÚCIFER, Imperador do Submundo. 'Interessante... sua determinação. Você se envolve em assuntos que não lhe pertencem. Venha aos meus domínios, se ousar.'",
    collectible: { id: "crystal", name: "Cristal de Ira" },
    music: "act4",
    ambientColor: "rgba(150,200,255,0.10)",
    size: 128,
  },
  {
    id: 5,
    name: "Ato V — O Imperador do Submundo",
    subtitle: "Domínios de Lúcifer",
    villageName: "Bastião dos Condenados",
    biome: { ground: ["#2a0e0a", "#4a1a10", "#6a2a16"], detail: "#ff6a2a", path: ["#1a0a08", "#3a1c12"], liquid: ["#ff4a00", "#ffb000"], liquidGlow: "#fff0a0" },
    propHue: 230, propSat: 0.6, propBright: 0.55, hutHue: -20,
    liquidKind: "lava",
    levelRange: [50, 66],
    enemies: [
      { id: "hellknight", name: "Cavaleiro Infernal", layers: ["body_red_orc", "legs_metal", "torso_plate", "torso_plate_arms", "head_metal_helm", "wpn_longsword", "tint:#ff2a0a@0.3"], hp: 1400, dmg: 160, speed: 2.6, xp: 900, attackAnim: "slash" },
      { id: "demonmage", name: "Mago Demoníaco", layers: ["body_darkelf", "legs_robe", "torso_shirt_maroon", "head_cloth_hood", "wpn_wand", "tint:#ff4a1a@0.35"], hp: 1000, dmg: 200, speed: 2.2, xp: 950, ranged: true, attackAnim: "spellcast", projectileColor: "#ff4a1a" },
      { id: "boneLord", name: "Senhor dos Ossos", layers: ["body_skeleton", "legs_gold", "torso_gold", "head_gold_helm", "wpn_trident", "tint:#ff8a2a@0.3"], hp: 1600, dmg: 170, speed: 2.4, xp: 1000, attackAnim: "thrust" },
      { id: "fallen", name: "Anjo Caído", layers: ["body_light", "legs_white", "torso_shirt_white", "hair_long_white", "wpn_saber", "tint:#ffd25a@0.25"], hp: 1300, dmg: 190, speed: 3.2, xp: 1100, attackAnim: "slash" },
      { id: "pitlord", name: "Senhor do Abismo", layers: ["body_orc", "legs_metal", "torso_chain", "wpn_mace", "tint:#8a0a0a@0.5"], hp: 2400, dmg: 220, speed: 2.0, xp: 1500, attackAnim: "slash", scale: 1.4 },
    ],
    boss: { id: "lucifer", name: "Lúcifer, Imperador do Submundo", layers: ["body_light", "legs_gold", "torso_gold", "torso_gold_arms", "hands_gold", "hair_long_white", "wpn_longsword", "tint:#ff1a1a@0.3"], hp: 80000, dmg: 380, speed: 3.0, xp: 100000, attackAnim: "slash", scale: 2.8, aggro: 12, boss: true, dropMult: 20 },
    chapters: [
      { id: "a5c1", title: "Portões de Ferro", kind: "kill", target: "hellknight", count: 18, tier: 0, text: "Os cavaleiros infernais guardam os portões. Rompa a linha.", done: "A linha quebrou.", rewardGold: 8000, rewardXp: 10000 },
      { id: "a5c2", title: "Essência Infernal", kind: "collect", target: "essence", count: 14, tier: 0, text: "Colete Essências Infernais dos demônios. O ferreiro forjará algo digno de Lúcifer.", done: "Ele treme ao tocá-las.", rewardGold: 7000, rewardXp: 9000 },
      { id: "a5c3", title: "A Última Forja", kind: "deliver", target: "smith", count: 1, tier: 1, text: "Entregue as essências ao ferreiro.", done: "Sua arma agora arde.", rewardGold: 5000, rewardXp: 6000 },
      { id: "a5c4", title: "Magos do Abismo", kind: "kill", target: "demonmage", count: 16, tier: 1, text: "Os magos demoníacos mantêm os portais abertos. Feche-os com sangue.", done: "Menos portais.", rewardGold: 9000, rewardXp: 11000 },
      { id: "a5c5", title: "O Coliseu", kind: "explore", target: "altar", count: 1, tier: 1, text: "Encontre o Coliseu onde Lúcifer assiste aos condenados lutarem.", done: "Ele estava assistindo você.", rewardGold: 8000, rewardXp: 12000 },
      { id: "a5c6", title: "Anjos Caídos", kind: "kill", target: "fallen", count: 14, tier: 2, text: "Os anjos caídos são os mais perigosos. Lembre-se do que eles foram.", done: "Descansem, caídos.", rewardGold: 10000, rewardXp: 13000 },
      { id: "a5c7", title: "O Senhor do Abismo", kind: "elite", target: "pitlord", count: 1, tier: 2, text: "Um Senhor do Abismo guarda a escadaria do trono. Derrube-o.", done: "A escadaria está livre.", rewardGold: 14000, rewardXp: 16000 },
      { id: "a5c8", title: "Pedra do Portal", kind: "explore", target: "waystone", count: 1, tier: 2, text: "Ative a pedra dos domínios infernais.", done: "Bom.", rewardGold: 6000, rewardXp: 8000 },
      { id: "a5c9", title: "Legião", kind: "kill", target: "any", count: 90, tier: 3, text: "Destrua a legião antes do trono.", done: "Você é a profecia.", rewardGold: 15000, rewardXp: 25000 },
      { id: "a5c10", title: "O Trono de Lúcifer", kind: "boss", target: "lucifer", count: 1, tier: 9, text: "Lúcifer o aguarda em seu trono. Esta é a história que você contará. Vá terminá-la.", done: "Lúcifer caiu. A guerra de cem anos acabou. O mundo é livre, e seu nome será lembrado para sempre.", rewardGold: 50000, rewardXp: 100000 },
    ],
    intro: "Os Domínios de Lúcifer: rios de lava, cidades de ossos e o trono do Imperador do Submundo. Aqui termina a profecia.",
    bossIntro: "LÚCIFER: Você veio. Admirável. Agora vejamos se a profecia sobrevive a mim.",
    outro: "Lúcifer está morto. Os Quatro Pilares caíram. Após cem anos, o mundo conhece a paz. E tudo começou com um nome.",
    collectible: { id: "essence", name: "Essência Infernal" },
    music: "act5",
    ambientColor: "rgba(255,60,0,0.12)",
    size: 130,
  },
];

export const actById = (id: number) => ACTS[Math.max(0, Math.min(ACTS.length - 1, id - 1))];

/** NPC definitions, same roles in every village, re-skinned per act. */
export interface NpcDef { id: "elder" | "smith" | "merchant" | "traveler"; name: string; title: string; layers: string[]; hutIndex: number }
export const NPCS: NpcDef[] = [
  { id: "elder", name: "Ancião Oromir", title: "Guardião da Profecia", layers: ["body_light", "feet_brown", "legs_robe", "torso_shirt_brown", "hair_long_white", "beard_white", "wpn_wand"], hutIndex: 0 },
  { id: "smith", name: "Gorm", title: "Ferreiro", layers: ["body_tanned", "feet_metal", "legs_red", "torso_leather", "hands_leather", "hair_shorthawk_gray", "beard_gray", "wpn_mace"], hutIndex: 1 },
  { id: "merchant", name: "Sela", title: "Mercadora de Poções", layers: ["body_light", "feet_brown", "legs_teal", "torso_shirt_teal", "hair_ponytail_blonde"], hutIndex: 2 },
  { id: "traveler", name: "Vashti", title: "Viajante Errante", layers: ["body_dark", "feet_black", "legs_magenta", "torso_leather", "torso_leather_shoulders", "hair_bedhead_raven", "head_leather_cap", "wpn_dagger"], hutIndex: 4 },
];
