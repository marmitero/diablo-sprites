/**
 * Class & skill definitions. See docs/CONTENT.md for the design table.
 * Skill `kind` drives the combat system (src/game/scenes/play.ts -> castSkill).
 */
import type { AnimName } from "../core/assets";
import type { SfxName } from "../core/audio";

export type ClassId = "warrior" | "priest" | "necromancer" | "sorcerer";

export type SkillKind =
  | "melee_aoe" | "projectile" | "dash" | "buff" | "quake" | "heal" | "nova" | "shield"
  | "summon" | "corpse" | "curse" | "chain" | "teleport" | "meteor" | "army" | "judgement" | "phantom";

export interface SkillDef {
  id: string;
  name: string;
  desc: string;
  kind: SkillKind;
  mp: number;
  cooldown: number; // seconds
  dmg: number; // multiplier of base damage
  radius?: number; // tiles
  range?: number; // tiles
  color: string;
  color2?: string;
  sfx: SfxName;
  anim: AnimName;
  unlock: number; // level
  evo?: boolean; // only after evolution
}

export interface ClassDef {
  id: ClassId;
  name: string;
  evoName: string;
  title: string;
  desc: string;
  evoDesc: string;
  base: { str: number; dex: number; vit: number; ene: number };
  growth: { hp: number; mp: number }; // per vit / per ene
  layers: string[]; // LPC layers
  evoLayers: string[];
  attackAnim: AnimName;
  ranged: boolean;
  skills: SkillDef[];
  portrait: string;
}

export const CLASSES: ClassDef[] = [
  {
    id: "warrior",
    name: "Guerreiro",
    evoName: "Cavaleiro da Ruína",
    title: "Lâmina de Ferro",
    desc: "Veterano das trincheiras da Guerra dos Cem Anos. Força bruta, armadura pesada e golpes que abalam a terra. Simples, direto, implacável.",
    evoDesc: "Juramentado às cinzas, o Cavaleiro da Ruína canaliza a fúria dos caídos em lâminas fantasmas.",
    base: { str: 30, dex: 20, vit: 25, ene: 10 },
    growth: { hp: 4, mp: 1 },
    layers: ["body_light", "feet_metal", "legs_metal", "torso_chain", "torso_plate", "torso_plate_arms", "hands_metal", "hair_shorthawk_gray", "head_metal_helm", "wpn_longsword"],
    evoLayers: ["body_light", "feet_gold", "legs_gold", "torso_chain", "torso_gold", "torso_gold_arms", "hands_gold", "head_gold_helm", "wpn_longsword", "tint:#ff6a3a@0.12"],
    attackAnim: "slash",
    ranged: false,
    portrait: "warrior",
    skills: [
      { id: "whirl", name: "Golpe Giratório", desc: "Gira a lâmina atingindo todos ao redor.", kind: "melee_aoe", mp: 8, cooldown: 1.2, dmg: 1.4, radius: 2.2, color: "#ffd27a", sfx: "sword", anim: "slash", unlock: 1 },
      { id: "charge", name: "Investida", desc: "Avança com violência, derrubando inimigos no caminho.", kind: "dash", mp: 10, cooldown: 4, dmg: 1.6, range: 6, color: "#ff8a3a", sfx: "dash", anim: "thrust", unlock: 3 },
      { id: "warcry", name: "Grito de Guerra", desc: "Aumenta dano e defesa por 10s.", kind: "buff", mp: 15, cooldown: 18, dmg: 0, radius: 4, color: "#ff5a3a", sfx: "shout", anim: "spellcast", unlock: 6 },
      { id: "quake", name: "Terremoto", desc: "Racha o chão em área, causando dano massivo.", kind: "quake", mp: 25, cooldown: 9, dmg: 3.0, radius: 3.5, color: "#c98a4a", sfx: "quake", anim: "slash", unlock: 10 },
      { id: "phantom", name: "Lâminas Fantasmas", desc: "Invoca lâminas espectrais que giram ao seu redor por 8s.", kind: "phantom", mp: 35, cooldown: 20, dmg: 1.0, radius: 2.5, color: "#9ad7ff", sfx: "sword", anim: "spellcast", unlock: 18, evo: true },
    ],
  },
  {
    id: "priest",
    name: "Sacerdote",
    evoName: "Inquisidor",
    title: "Voz da Luz",
    desc: "Último clérigo de uma ordem destruída. Pune com martelos sagrados, cura feridas e ergue escudos de fé. Equilíbrio entre suporte e combate.",
    evoDesc: "O Inquisidor abandona a misericórdia: a Luz agora julga e consome os ímpios.",
    base: { str: 18, dex: 18, vit: 22, ene: 27 },
    growth: { hp: 3, mp: 2 },
    layers: ["body_light", "feet_brown", "legs_robe", "torso_shirt_white", "hands_leather", "hair_plain_brown", "head_cloth_hood", "wpn_mace"],
    evoLayers: ["body_light", "feet_gold", "legs_robe", "torso_shirt_white", "torso_gold", "hands_gold", "head_gold_helm", "wpn_mace", "tint:#ffe9a8@0.12"],
    attackAnim: "slash",
    ranged: false,
    portrait: "priest",
    skills: [
      { id: "hammer", name: "Martelo Sagrado", desc: "Arremessa um martelo de luz que atravessa inimigos.", kind: "projectile", mp: 6, cooldown: 0.6, dmg: 1.3, range: 9, color: "#fff2b0", color2: "#ffcf5a", sfx: "holy", anim: "spellcast", unlock: 1 },
      { id: "heal", name: "Cura", desc: "Restaura 35% da vida.", kind: "heal", mp: 20, cooldown: 8, dmg: 0, color: "#b8ffb0", sfx: "heal", anim: "spellcast", unlock: 2 },
      { id: "purify", name: "Luz Purificadora", desc: "Explosão sagrada em área ao redor.", kind: "nova", mp: 18, cooldown: 5, dmg: 1.8, radius: 3.2, color: "#fff8d0", color2: "#ffd27a", sfx: "holy", anim: "spellcast", unlock: 5 },
      { id: "shield", name: "Escudo Divino", desc: "Absorve dano por 8s.", kind: "shield", mp: 22, cooldown: 16, dmg: 0, color: "#9ad7ff", sfx: "heal", anim: "spellcast", unlock: 9 },
      { id: "judgement", name: "Juízo Final", desc: "Pilares de luz caem sobre todos os inimigos próximos.", kind: "judgement", mp: 40, cooldown: 18, dmg: 3.5, radius: 6, color: "#fffbe0", color2: "#ffb347", sfx: "holy", anim: "spellcast", unlock: 18, evo: true },
    ],
  },
  {
    id: "necromancer",
    name: "Necromante",
    evoName: "Senhor das Almas",
    title: "Pastor dos Mortos",
    desc: "Exilado que fala com os que a guerra levou. Ergue esqueletos, explode cadáveres e amaldiçoa os vivos. Comanda, não enfrenta.",
    evoDesc: "O Senhor das Almas não ergue servos: ergue exércitos. A morte lhe obedece.",
    base: { str: 15, dex: 22, vit: 20, ene: 28 },
    growth: { hp: 3, mp: 2.2 },
    layers: ["body_light", "feet_black", "legs_robe", "torso_shirt_maroon", "hands_leather", "hair_long_raven", "head_cloth_hood", "wpn_dagger", "tint:#5a2a7a@0.25"],
    evoLayers: ["body_skeleton", "feet_black", "legs_robe", "torso_shirt_maroon", "head_cloth_hood", "wpn_dagger", "tint:#3a0a5a@0.35"],
    attackAnim: "thrust",
    ranged: true,
    portrait: "necromancer",
    skills: [
      { id: "bonespear", name: "Lança de Osso", desc: "Dispara uma lança óssea perfurante.", kind: "projectile", mp: 7, cooldown: 0.5, dmg: 1.4, range: 10, color: "#e8e0c8", color2: "#9fd88a", sfx: "bone", anim: "spellcast", unlock: 1 },
      { id: "raise", name: "Erguer Esqueleto", desc: "Invoca um esqueleto guerreiro (máx. 3).", kind: "summon", mp: 15, cooldown: 3, dmg: 0.8, color: "#9fd88a", sfx: "summon", anim: "spellcast", unlock: 2 },
      { id: "corpse", name: "Explosão de Cadáver", desc: "Detona corpos próximos ao alvo, dano em área.", kind: "corpse", mp: 14, cooldown: 2, dmg: 2.2, radius: 2.5, range: 8, color: "#b8ff5a", color2: "#6a1a1a", sfx: "bone", anim: "spellcast", unlock: 5 },
      { id: "curse", name: "Maldição", desc: "Inimigos na área sofrem +50% dano por 8s.", kind: "curse", mp: 16, cooldown: 10, dmg: 0, radius: 4, range: 8, color: "#b06aff", sfx: "curse", anim: "spellcast", unlock: 9 },
      { id: "army", name: "Exército dos Mortos", desc: "Ergue 5 esqueletos de elite instantaneamente.", kind: "army", mp: 45, cooldown: 25, dmg: 1.2, color: "#5aff9a", sfx: "summon", anim: "spellcast", unlock: 18, evo: true },
    ],
  },
  {
    id: "sorcerer",
    name: "Feiticeiro",
    evoName: "Arquimago",
    title: "Tecelão de Elementos",
    desc: "Estudioso das torres caídas. Fogo, gelo e raio obedecem à sua vontade. Frágil, mas devastador à distância.",
    evoDesc: "O Arquimago rasga o céu e chama meteoros. Nada sobrevive ao seu domínio elemental.",
    base: { str: 12, dex: 20, vit: 18, ene: 35 },
    growth: { hp: 2.5, mp: 2.5 },
    layers: ["body_tanned", "feet_brown", "legs_robe", "torso_shirt_teal", "hands_leather", "hair_ponytail_blonde", "head_leather_cap", "wpn_wand", "tint:#2a4aff@0.12"],
    evoLayers: ["body_tanned", "feet_gold", "legs_robe", "torso_shirt_teal", "torso_gold", "hands_gold", "hair_ponytail_blonde", "head_chainhat", "wpn_wand", "tint:#ff8a2a@0.15"],
    attackAnim: "spellcast",
    ranged: true,
    portrait: "sorcerer",
    skills: [
      { id: "fireball", name: "Bola de Fogo", desc: "Projétil flamejante que explode no impacto.", kind: "projectile", mp: 8, cooldown: 0.55, dmg: 1.6, range: 10, radius: 1.5, color: "#ff8a2a", color2: "#ffd27a", sfx: "fire", anim: "spellcast", unlock: 1 },
      { id: "frostnova", name: "Nova de Gelo", desc: "Congela e fere inimigos ao redor.", kind: "nova", mp: 16, cooldown: 5, dmg: 1.2, radius: 3.5, color: "#bff3ff", color2: "#5ab8ff", sfx: "ice", anim: "spellcast", unlock: 3 },
      { id: "chain", name: "Raio em Cadeia", desc: "Relâmpago que salta entre até 5 inimigos.", kind: "chain", mp: 14, cooldown: 2.2, dmg: 1.5, range: 8, color: "#e0f0ff", color2: "#7ab8ff", sfx: "bolt", anim: "spellcast", unlock: 6 },
      { id: "teleport", name: "Teleporte", desc: "Teleporta até o cursor.", kind: "teleport", mp: 12, cooldown: 3, dmg: 0, range: 8, color: "#c89aff", sfx: "dash", anim: "spellcast", unlock: 9 },
      { id: "meteor", name: "Meteoro", desc: "Chama um meteoro devastador no alvo.", kind: "meteor", mp: 45, cooldown: 12, dmg: 5, radius: 3, range: 10, color: "#ff5a1a", color2: "#ffd27a", sfx: "meteor", anim: "spellcast", unlock: 18, evo: true },
    ],
  },
];

export const EVOLUTION_LEVEL = 18;
export const classById = (id: ClassId) => CLASSES.find((c) => c.id === id)!;
