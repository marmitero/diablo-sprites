/**
 * In-game UI (all canvas): Diablo-style bottom bar with HP/MP orbs, skill bar with cooldown sweeps,
 * XP bar, quest tracker, minimap, log, banners, story overlay and panels:
 * inventory / character / skills / quests / NPC dialogs (elder, smith, merchant, traveler) / portal / pause / death.
 */
import { A } from "../core/assets";
import { audio } from "../core/audio";
import { bar, button, fancyText, FONT_BODY, inRect, orb, panel, Rect, text, VH, VW, wrapText } from "../core/ui";
import { hashString, RNG } from "../core/rng";
import { ACTS } from "../data/acts";
import { EVOLUTION_LEVEL } from "../data/classes";
import { drawItemIcon, effectiveStats, generateEquip, Item, ItemStats, makePotion, RARITY_COLOR, Slot, STAT_LABEL, upgradeCost } from "../data/items";
import { canEvolve, Drop, Npc, xpToNext } from "../world/entities";
import { INV_SIZE, PlayScene } from "./play";

export type PanelId = null | "inventory" | "character" | "skills" | "quests" | "elder" | "smith" | "merchant" | "traveler" | "portal" | "pause" | "map" | "dead";

const SLOTS: Slot[] = ["weapon", "armor", "helm", "boots", "ring"];
const SLOT_LABEL: Record<Slot, string> = { weapon: "Arma", armor: "Armadura", helm: "Elmo", boots: "Botas", ring: "Anel" };

export class PlayUI {
  p: PlayScene;
  panel: PanelId = null;
  hoverItem: Item | null = null;
  hoverRect: Rect | null = null;
  shopStock: Item[] = [];
  shopKey = "";
  tooltipItem: Item | null = null;
  tooltipPos = { x: 0, y: 0 };
  pauseSel = 0;
  dialogMsg = "";
  msgT = 0;

  constructor(p: PlayScene) { this.p = p; }
  get time() { return this.p.time; }
  get mouse() { return this.p.g.mouse; }

  /* ---------------- layout ---------------- */
  skillRects(): Rect[] { return this.p.skills.map((_, i) => ({ x: VW / 2 - 150 + i * 60, y: VH - 74, w: 54, h: 54 })); }
  potionRects(): [Rect, Rect] { return [{ x: VW / 2 - 230, y: VH - 70, w: 44, h: 50 }, { x: VW / 2 + 188, y: VH - 70, w: 44, h: 50 }]; }
  minimapRect(): Rect { return { x: VW - 212, y: 12, w: 200, h: 140 }; }
  bigPanel(): Rect { return { x: VW / 2 - 330, y: 70, w: 660, h: 540 }; }
  invGridRect(): Rect { return { x: VW / 2 - 330 + 250, y: 70 + 60, w: 8 * 48, h: 5 * 48 }; }
  invCell(i: number): Rect { const g = this.invGridRect(); return { x: g.x + (i % 8) * 48, y: g.y + Math.floor(i / 8) * 48, w: 46, h: 46 }; }
  equipCell(i: number): Rect { const b = this.bigPanel(); return { x: b.x + 30 + (i % 2) * 90, y: b.y + 70 + Math.floor(i / 2) * 90, w: 70, h: 70 }; }
  pointerOverUI(x: number, y: number): boolean {
    if (this.panel) return true;
    if (y > VH - 110 && x > VW / 2 - 330 && x < VW / 2 + 330) return true;
    if (inRect(x, y, this.minimapRect())) return true;
    return false;
  }

  /* ---------------- NPC ---------------- */
  openNpc(n: Npc) {
    audio.sfx("select");
    this.panel = n.role;
    this.dialogMsg = "";
    const p = this.p;
    if (n.role === "smith" || n.role === "traveler") { if (p.deliverTo(n.role)) this.dialogMsg = "Entrega recebida! Volte ao Ancião."; }
    if (n.role === "traveler") this.ensureStock();
    p.player.moveTarget = null;
  }
  ensureStock() {
    const p = this.p;
    const key = `${p.save.shopSeed}:${p.act.id}:${Math.floor(p.save.level / 4)}`;
    if (key === this.shopKey) return;
    this.shopKey = key;
    const rng = new RNG(hashString(key));
    this.shopStock = [];
    for (let i = 0; i < 6; i++) this.shopStock.push(generateEquip(rng, Math.max(1, p.save.level + rng.int(-1, 2)), rng.chance(0.15) ? "rare" : rng.chance(0.5) ? "magic" : "normal"));
  }

  /* ---------------- input ---------------- */
  onKeyDown(k: string, e: KeyboardEvent): boolean {
    const p = this.p;
    if (k === "Escape") {
      if (this.panel && this.panel !== "dead") { this.panel = null; audio.sfx("back"); }
      else if (!this.panel) { this.panel = "pause"; this.pauseSel = 0; audio.sfx("select"); }
      return true;
    }
    if (this.panel === "dead") { if (k === "Enter" || k === " ") p.respawn(); return true; }
    if (this.panel === "pause") {
      if (k === "ArrowUp") { this.pauseSel = (this.pauseSel + 3) % 4; audio.sfx("hover"); }
      if (k === "ArrowDown") { this.pauseSel = (this.pauseSel + 1) % 4; audio.sfx("hover"); }
      if (k === "Enter") this.pauseAction(this.pauseSel);
      return true;
    }
    const toggles: Record<string, PanelId> = { i: "inventory", c: "character", k: "skills", j: "quests", m: "map" };
    if (toggles[k] !== undefined) { this.panel = this.panel === toggles[k] ? null : toggles[k]; audio.sfx("page"); return true; }
    if (this.panel && (k === "q" || k === "e")) return false;
    if (e.key === "Tab") { e.preventDefault(); this.panel = this.panel === "map" ? null : "map"; return true; }
    return false;
  }
  pauseRects(): Rect[] { return [0, 1, 2, 3].map((i) => ({ x: VW / 2 - 130, y: 270 + i * 64, w: 260, h: 50 })); }
  pauseAction(i: number) {
    const p = this.p;
    audio.sfx("select");
    if (i === 0) this.panel = null;
    if (i === 1) { p.persist(); p.addLog("Jogo salvo.", "#ffe9a8"); this.panel = null; }
    if (i === 2) { audio.setMusicVol(audio.musicVol > 0 ? 0 : 0.6); }
    if (i === 3) { p.persist().then(async () => { const { MenuScene } = await import("./menu"); p.g.goto(new MenuScene(p.g)); }); }
  }

  onMouseDown(x: number, y: number, b: number): boolean {
    const p = this.p, s = p.save;
    if (this.panel === "dead") { if (b === 0 && inRect(x, y, { x: VW / 2 - 120, y: VH / 2 + 60, w: 240, h: 50 })) p.respawn(); return true; }
    if (this.panel === "pause") { this.pauseRects().forEach((r, i) => { if (inRect(x, y, r)) this.pauseAction(i); }); return true; }
    // HUD skill bar / potions
    if (b === 0) {
      for (const [i, r] of this.skillRects().entries()) if (inRect(x, y, r)) { p.activeSkill = i; audio.sfx("hover"); return true; }
      const [hpR, mpR] = this.potionRects();
      if (inRect(x, y, hpR)) { p.usePotion("potion_hp"); return true; }
      if (inRect(x, y, mpR)) { p.usePotion("potion_mp"); return true; }
      if (inRect(x, y, this.minimapRect())) { this.panel = "map"; return true; }
    }
    if (!this.panel) return false;
    const big = this.bigPanel();
    const closeR: Rect = { x: big.x + big.w - 40, y: big.y + 8, w: 32, h: 32 };
    if (inRect(x, y, closeR)) { this.panel = null; audio.sfx("back"); return true; }
    if (!inRect(x, y, big) && this.panel !== "map") { if (b === 0) { this.panel = null; audio.sfx("back"); } return true; }
    switch (this.panel) {
      case "inventory": case "merchant": case "traveler": case "smith": {
        // inventory grid click
        for (let i = 0; i < INV_SIZE; i++) {
          const it = s.inventory[i];
          if (!it) continue;
          if (inRect(x, y, this.invCell(i))) {
            if (this.panel === "merchant" || this.panel === "traveler") { // sell
              const price = Math.max(1, Math.floor(it.price / 4));
              s.gold += price * (it.kind === "equip" ? 1 : 1); it.qty--; if (it.qty <= 0 || it.kind === "equip") s.inventory.splice(i, 1);
              audio.sfx("coin"); p.addLog(`Vendido ${it.name} por ${price} ouro.`, "#ffd25a");
            } else if (it.kind === "equip") p.equip(it);
            else if (it.kind === "potion_hp") p.usePotion("potion_hp");
            else if (it.kind === "potion_mp") p.usePotion("potion_mp");
            return true;
          }
        }
        if (this.panel === "inventory") {
          SLOTS.forEach((sl, i) => { if (inRect(x, y, this.equipCell(i)) && s.equipment[sl]) p.unequip(sl); });
        }
        if (this.panel === "merchant") {
          this.merchantItems().forEach((it, i) => { const r = this.leftRowRect(i); if (inRect(x, y, r)) this.buy(it); });
        }
        if (this.panel === "traveler") {
          this.shopStock.forEach((it, i) => { const r = this.leftRowRect(i); if (inRect(x, y, r)) { if (this.buy(it)) this.shopStock.splice(i, 1); } });
          const refresh: Rect = { x: big.x + 20, y: big.y + 470, w: 200, h: 40 };
          const cost = 40 * p.act.id;
          if (inRect(x, y, refresh)) { if (s.gold >= cost) { s.gold -= cost; s.shopSeed++; this.shopKey = ""; this.ensureStock(); audio.sfx("coin"); } else audio.sfx("error"); }
        }
        if (this.panel === "smith") {
          SLOTS.forEach((sl, i) => {
            const it = s.equipment[sl];
            const r = this.leftRowRect(i);
            if (it && inRect(x, y, r)) {
              const cost = upgradeCost(it);
              if (it.upgrade >= 10) { this.dialogMsg = "Já está no máximo (+10)."; audio.sfx("error"); }
              else if (s.gold >= cost) { s.gold -= cost; it.upgrade++; p.recalc(); audio.sfx("equip"); this.dialogMsg = `${it.name} agora é +${it.upgrade}!`; p.effects.push({ kind: "aura", x: p.player.x, y: p.player.y, color: "#ffb347", life: 0.8, maxLife: 0.8 }); }
              else { this.dialogMsg = "Ouro insuficiente."; audio.sfx("error"); }
            }
          });
        }
        return true;
      }
      case "character": {
        const keys = ["str", "dex", "vit", "ene"] as const;
        keys.forEach((k, i) => {
          if (inRect(x, y, this.statPlusRect(i)) && s.statPoints > 0) {
            const n = this.p.g.keys.has("Shift") ? Math.min(5, s.statPoints) : 1;
            s.stats[k] += n; s.statPoints -= n; p.recalc(); audio.sfx("select");
          }
        });
        return true;
      }
      case "elder": {
        const ch = p.currentChapter();
        const opts = this.elderOptions();
        opts.forEach((o, i) => { if (inRect(x, y, this.optionRect(i))) {
          if (o.id === "complete" && ch) { p.completeChapter(ch); this.dialogMsg = ch.done; }
          else if (o.id === "evolve") { p.evolve(); this.panel = null; }
          else if (o.id === "close") { this.panel = null; audio.sfx("back"); }
          else if (o.id === "lore") { this.dialogMsg = p.act.intro; audio.sfx("page"); }
        } });
        return true;
      }
      case "portal": {
        p.waypointList().forEach((w, i) => { if (inRect(x, y, this.portalRect(i))) p.travel(w); });
        return true;
      }
      case "skills": {
        p.skills.forEach((_, i) => { if (inRect(x, y, { x: big.x + 30, y: big.y + 70 + i * 90, w: big.w - 60, h: 80 })) { p.activeSkill = i; audio.sfx("hover"); } });
        return true;
      }
      case "map": { this.panel = null; return true; }
    }
    return true;
  }
  buy(it: Item): boolean {
    const p = this.p, s = p.save;
    if (s.gold < it.price) { this.dialogMsg = "Ouro insuficiente."; audio.sfx("error"); return false; }
    const copy: Item = { ...it, stats: { ...it.stats }, qty: 1 };
    if (it.kind === "equip") copy.uid = it.uid; else copy.uid = Date.now() + Math.floor(Math.random() * 1000);
    if (!p.addItem(copy)) { this.dialogMsg = "Inventário cheio."; audio.sfx("error"); return false; }
    s.gold -= it.price; audio.sfx("coin"); this.dialogMsg = `Comprou ${it.name}.`;
    return true;
  }
  merchantItems(): Item[] {
    const a = this.p.act.id;
    const out: Item[] = [makePotion("potion_hp", 1), makePotion("potion_mp", 1)];
    if (a >= 2) out.push(makePotion("potion_hp", 2), makePotion("potion_mp", 2));
    if (a >= 3) out.push(makePotion("potion_hp", 3), makePotion("potion_mp", 3));
    return out;
  }
  leftRowRect(i: number): Rect { const b = this.bigPanel(); return { x: b.x + 20, y: b.y + 70 + i * 62, w: 215, h: 56 }; }
  optionRect(i: number): Rect { const b = this.bigPanel(); return { x: b.x + 40, y: b.y + 330 + i * 52, w: b.w - 80, h: 44 }; }
  statPlusRect(i: number): Rect { const b = this.bigPanel(); return { x: b.x + 250, y: b.y + 100 + i * 44, w: 34, h: 34 }; }
  elderOptions(): { id: string; label: string; disabled?: boolean }[] {
    const p = this.p; const ch = p.currentChapter();
    const out: { id: string; label: string; disabled?: boolean }[] = [];
    if (ch) out.push({ id: "complete", label: p.chapterReady(ch) ? `Concluir: ${ch.title}` : `(Em andamento) ${ch.title}`, disabled: !p.chapterReady(ch) || ch.kind === "boss" });
    if (canEvolve(p.save)) out.push({ id: "evolve", label: `✦ Ascender a ${p.cls.evoName}` });
    else if (!p.save.evolved) out.push({ id: "evolve", label: `Ascensão (nível ${EVOLUTION_LEVEL})`, disabled: true });
    out.push({ id: "lore", label: "Conte-me sobre esta região" });
    out.push({ id: "close", label: "Até logo" });
    return out;
  }

  /* ---------------- drops ---------------- */
  drawDrop(ctx: CanvasRenderingContext2D, d: Drop, sx: number, sy: number) {
    const bob = Math.sin(d.bob) * 3;
    ctx.save();
    ctx.globalAlpha = 0.35; ctx.fillStyle = "#000"; ctx.beginPath(); ctx.ellipse(sx, sy, 10, 5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
    const col = d.gold ? "#ffd25a" : RARITY_COLOR[d.item.rarity];
    ctx.shadowColor = col; ctx.shadowBlur = d.item.rarity === "normal" && !d.gold ? 4 : 14;
    drawItemIcon(ctx, d.item, sx - 14, sy - 30 + bob, 28);
    ctx.restore();
    if (this.p.hoverDrop === d || d.item.rarity === "unique" || d.item.rarity === "rare") {
      ctx.save(); ctx.font = `13px ${FONT_BODY}`; ctx.textAlign = "center";
      const w = ctx.measureText(d.item.name).width + 10;
      ctx.fillStyle = "rgba(0,0,0,0.7)"; ctx.fillRect(sx - w / 2, sy - 52 + bob, w, 16);
      ctx.fillStyle = col; ctx.fillText(d.item.name, sx, sy - 40 + bob); ctx.restore();
    }
  }

  /* ---------------- render ---------------- */
  render(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, d = p.d;
    this.tooltipItem = null;
    // boss bar
    if (p.bossAlive && !p.bossAlive.dead && p.dist(p.player, p.bossAlive) < 16) {
      const b = p.bossAlive;
      fancyText(ctx, b.name, VW / 2, 40, { size: 22, align: "center", colors: ["#ffb3a0", "#c9402a"], glow: "#ff2a1a" });
      bar(ctx, { x: VW / 2 - 250, y: 50, w: 500, h: 14 }, b.hp / b.maxHp, "#c9202a", "#1a0505", "#8a2a1a");
    } else if (p.hoverEnemy) {
      const e = p.hoverEnemy;
      text(ctx, `${e.name}  nv.${e.level}`, VW / 2, 40, 16, e.elite ? "#ffd25a" : "#f0dca0", "center");
      bar(ctx, { x: VW / 2 - 120, y: 48, w: 240, h: 10 }, e.hp / e.maxHp, e.elite ? "#d8a02a" : "#c9202a");
    }
    // bottom bar background
    ctx.save();
    const bg = ctx.createLinearGradient(0, VH - 110, 0, VH);
    bg.addColorStop(0, "rgba(10,6,4,0)"); bg.addColorStop(0.3, "rgba(20,14,10,0.95)"); bg.addColorStop(1, "#0a0604");
    ctx.fillStyle = bg; ctx.fillRect(VW / 2 - 340, VH - 110, 680, 110);
    ctx.strokeStyle = "#6a4a1a"; ctx.lineWidth = 2; ctx.strokeRect(VW / 2 - 340, VH - 96, 680, 96);
    ctx.restore();
    // xp bar
    bar(ctx, { x: VW / 2 - 150, y: VH - 14, w: 300, h: 8 }, s.xp / xpToNext(s.level), "#9a7aff", "#140c22", "#5a3a8a");
    text(ctx, `Nível ${s.level}`, VW / 2 - 158, VH - 7, 12, "#d8c8ff", "right");
    // orbs
    orb(ctx, VW / 2 - 290, VH - 60, 42, s.hp / d.maxHp, ["#ff4a3a", "#7a0a0a"], this.time, `${Math.ceil(s.hp)}`);
    orb(ctx, VW / 2 + 290, VH - 60, 42, s.mp / d.maxMp, ["#4a7aff", "#0a1a7a"], this.time, `${Math.floor(s.mp)}`);
    if (p.player.buffs.shield > 0) text(ctx, `Escudo ${Math.round(p.player.buffs.shieldHp)}`, VW / 2 - 290, VH - 108, 12, "#9ad7ff", "center");
    // potions
    const [hpR, mpR] = this.potionRects();
    const hpN = s.inventory.filter((i) => i.kind === "potion_hp").reduce((a, b) => a + b.qty, 0);
    const mpN = s.inventory.filter((i) => i.kind === "potion_mp").reduce((a, b) => a + b.qty, 0);
    for (const [r, n, kind, key] of [[hpR, hpN, "potion_hp", "Q"], [mpR, mpN, "potion_mp", "E"]] as const) {
      ctx.fillStyle = "#15100c"; ctx.fillRect(r.x, r.y, r.w, r.h); ctx.strokeStyle = "#6a4a1a"; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
      drawItemIcon(ctx, makePotion(kind, 1), r.x + 6, r.y + 4, 32);
      text(ctx, `${n}`, r.x + r.w - 5, r.y + r.h - 5, 13, n ? "#fff" : "#777", "right");
      text(ctx, key, r.x + 4, r.y + 12, 11, "#c9a24a");
    }
    // skills
    this.skillRects().forEach((r, i) => {
      const sk = p.skills[i];
      const locked = s.level < sk.unlock;
      const cd = p.player.cooldowns[sk.id] ?? 0;
      ctx.save();
      const g = ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
      g.addColorStop(0, locked ? "#222" : "#2a1e14"); g.addColorStop(1, locked ? "#111" : "#120c08");
      ctx.fillStyle = g; ctx.fillRect(r.x, r.y, r.w, r.h);
      // rune icon
      ctx.translate(r.x + r.w / 2, r.y + r.h / 2);
      ctx.fillStyle = locked ? "#444" : sk.color; ctx.shadowColor = sk.color; ctx.shadowBlur = locked ? 0 : 10;
      this.drawSkillRune(ctx, sk.kind, 16);
      ctx.restore();
      if (cd > 0) { ctx.save(); ctx.fillStyle = "rgba(0,0,0,0.7)"; ctx.beginPath(); ctx.moveTo(r.x + r.w / 2, r.y + r.h / 2); ctx.arc(r.x + r.w / 2, r.y + r.h / 2, 40, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (cd / sk.cooldown)); ctx.closePath(); ctx.clip(); ctx.fillRect(r.x, r.y, r.w, r.h); ctx.restore(); text(ctx, cd.toFixed(1), r.x + r.w / 2, r.y + r.h / 2 + 5, 14, "#fff", "center"); }
      if (s.mp < sk.mp && !locked) { ctx.fillStyle = "rgba(40,60,160,0.35)"; ctx.fillRect(r.x, r.y, r.w, r.h); }
      ctx.strokeStyle = p.activeSkill === i ? "#ffcf5a" : "#6a4a1a"; ctx.lineWidth = p.activeSkill === i ? 2 : 1; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
      text(ctx, `${i + 1}`, r.x + 4, r.y + 13, 11, "#c9a24a");
      if (locked) text(ctx, `nv${sk.unlock}`, r.x + r.w / 2, r.y + r.h - 5, 10, "#aaa", "center");
      if (!this.panel && inRect(this.mouse.x, this.mouse.y, r)) this.skillTooltip(ctx, sk, r.x + r.w / 2, r.y - 10);
    });
    text(ctx, `${s.gold} ouro`, VW / 2 + 158, VH - 7, 12, "#ffd25a", "left");
    // quest tracker
    const ch = p.currentChapter();
    if (ch && !this.panel) {
      panel(ctx, { x: 12, y: 12, w: 300, h: 92 }, { alpha: 0.75 });
      fancyText(ctx, `Cap. ${(s.chapterIndex[p.act.id] ?? 0) + 1}/${p.chapters.length}: ${ch.title}`, 24, 38, { size: 15 });
      const prog = ch.kind === "collect" ? p.countMaterial(ch.target!) : s.chapterProgress;
      const ready = p.chapterReady(ch);
      const desc = ch.kind === "kill" ? `Abater ${ch.target === "any" ? "inimigos" : p.act.enemies.find((e) => e.id === ch.target)?.name ?? ch.target}` : ch.kind === "collect" ? `Coletar ${p.act.collectible.name}` : ch.kind === "deliver" ? `Falar com ${ch.target === "smith" ? "o Ferreiro" : "a Viajante"}` : ch.kind === "explore" ? `Encontrar: ${ch.target === "altar" ? "local misterioso" : "Pedra do Portal"}` : ch.kind === "elite" ? `Matar o Campeão ${p.act.enemies.find((e) => e.id === ch.target)?.name ?? ""}` : `Derrotar ${p.act.boss.name}`;
      text(ctx, desc, 24, 62, 13, "#d8c8a0");
      text(ctx, ready && ch.kind !== "boss" ? "✔ Fale com o Ancião" : `${Math.min(prog, ch.count ?? 1)} / ${ch.count ?? 1}`, 24, 84, 14, ready ? "#9fff9a" : "#f0dca0");
      bar(ctx, { x: 200, y: 74, w: 100, h: 10 }, Math.min(1, prog / (ch.count ?? 1)), ready ? "#4aa84a" : "#b8862b");
    }
    // minimap
    this.drawMinimap(ctx, this.minimapRect(), 2.2);
    // log
    p.log.forEach((l, i) => { ctx.globalAlpha = Math.min(1, l.t); text(ctx, l.text, 16, VH - 130 - (p.log.length - 1 - i) * 20, 14, l.color); ctx.globalAlpha = 1; });
    if (p.savedFlash > 0) text(ctx, "✦ Salvo", VW - 20, VH - 20, 14, "#ffe9a8", "right");
    text(ctx, `Seed ${s.seed} • Ato ${p.act.id}`, VW - 20, VH - 40, 12, "#8a7a60", "right");
    // banner
    if (p.banner) {
      const a = Math.min(1, p.banner.t, (5 - p.banner.t) * 2);
      ctx.save(); ctx.globalAlpha = Math.max(0, a);
      fancyText(ctx, p.banner.title, VW / 2, 180, { size: 40, align: "center", glow: "#ff8a2a", wave: 2, time: this.time });
      text(ctx, p.banner.sub, VW / 2, 215, 20, "#f0dca0", "center");
      ctx.restore();
    }
    // panels
    if (this.panel) this.renderPanel(ctx);
    if (this.tooltipItem) this.itemTooltip(ctx, this.tooltipItem, this.tooltipPos.x, this.tooltipPos.y);
    // story overlay
    if (p.storyOverlay) {
      const so = p.storyOverlay;
      ctx.fillStyle = `rgba(0,0,0,${Math.min(0.8, so.t * 2)})`; ctx.fillRect(0, 0, VW, VH);
      panel(ctx, { x: VW / 2 - 420, y: VH / 2 - 150, w: 840, h: 300 }, { title: "CRÔNICA" });
      let y = VH / 2 - 90;
      for (const line of so.lines) { const ls = wrapText(ctx, line, 760, 18); for (const l of ls) { text(ctx, l, VW / 2, y, 18, "#f4e8c8", "center"); y += 24; } y += 10; }
      text(ctx, "Clique ou Espaço para continuar", VW / 2, VH / 2 + 130, 13, "#9a8a70", "center");
    }
    if (this.msgT > 0) this.msgT -= 0.016;
  }

  drawSkillRune(ctx: CanvasRenderingContext2D, kind: string, s: number) {
    ctx.beginPath();
    switch (kind) {
      case "melee_aoe": case "phantom": for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s, Math.sin(a) * s); } ctx.lineWidth = 3; ctx.strokeStyle = ctx.fillStyle; ctx.stroke(); break;
      case "dash": case "teleport": ctx.moveTo(-s, 0); ctx.lineTo(s * 0.3, -s * 0.7); ctx.lineTo(s * 0.3, -s * 0.2); ctx.lineTo(s, 0); ctx.lineTo(s * 0.3, s * 0.2); ctx.lineTo(s * 0.3, s * 0.7); ctx.closePath(); ctx.fill(); break;
      case "buff": case "shield": ctx.moveTo(0, -s); ctx.lineTo(s, -s * 0.5); ctx.lineTo(s * 0.8, s * 0.4); ctx.lineTo(0, s); ctx.lineTo(-s * 0.8, s * 0.4); ctx.lineTo(-s, -s * 0.5); ctx.closePath(); ctx.fill(); break;
      case "quake": case "meteor": ctx.arc(0, 0, s * 0.9, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#000"; ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = i * 1.26; ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s, Math.sin(a) * s); } ctx.lineWidth = 2; ctx.strokeStyle = "#000"; ctx.stroke(); break;
      case "projectile": case "chain": ctx.arc(0, 0, s * 0.5, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(-s, s * 0.8); ctx.lineTo(-s * 0.3, s * 0.2); ctx.lineWidth = 4; ctx.strokeStyle = ctx.fillStyle; ctx.stroke(); break;
      case "heal": case "judgement": ctx.fillRect(-s * 0.25, -s, s * 0.5, s * 2); ctx.fillRect(-s, -s * 0.25, s * 2, s * 0.5); break;
      case "nova": ctx.arc(0, 0, s, 0, Math.PI * 2); ctx.lineWidth = 3; ctx.strokeStyle = ctx.fillStyle; ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, s * 0.4, 0, Math.PI * 2); ctx.fill(); break;
      case "summon": case "army": ctx.arc(0, -s * 0.3, s * 0.55, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(-s * 0.45, s * 0.1, s * 0.9, s * 0.7); ctx.fillStyle = "#000"; ctx.fillRect(-s * 0.3, -s * 0.4, s * 0.2, s * 0.2); ctx.fillRect(s * 0.1, -s * 0.4, s * 0.2, s * 0.2); break;
      case "corpse": for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s * (i % 2 ? 0.5 : 1), Math.sin(a) * s * (i % 2 ? 0.5 : 1)); } ctx.lineWidth = 3; ctx.strokeStyle = ctx.fillStyle; ctx.stroke(); break;
      case "curse": ctx.moveTo(0, -s); ctx.lineTo(s * 0.8, s * 0.7); ctx.lineTo(-s * 0.8, s * 0.7); ctx.closePath(); ctx.lineWidth = 3; ctx.strokeStyle = ctx.fillStyle; ctx.stroke(); ctx.beginPath(); ctx.arc(0, s * 0.15, s * 0.25, 0, Math.PI * 2); ctx.fill(); break;
      default: ctx.arc(0, 0, s * 0.6, 0, Math.PI * 2); ctx.fill();
    }
  }
  skillTooltip(ctx: CanvasRenderingContext2D, sk: { name: string; desc: string; mp: number; cooldown: number; unlock: number; dmg: number }, x: number, y: number) {
    const lines = wrapText(ctx, sk.desc, 220, 13);
    const h = 70 + lines.length * 16;
    panel(ctx, { x: x - 130, y: y - h, w: 260, h }, { dark: true });
    fancyText(ctx, sk.name, x, y - h + 28, { size: 16, align: "center" });
    lines.forEach((l, i) => text(ctx, l, x, y - h + 50 + i * 16, 13, "#e8dcc0", "center"));
    text(ctx, `Mana ${sk.mp} • Recarga ${sk.cooldown}s${sk.dmg ? ` • Dano x${sk.dmg}` : ""}`, x, y - 14, 12, "#9ad7ff", "center");
  }
  itemTooltip(ctx: CanvasRenderingContext2D, it: Item, x: number, y: number) {
    const es = effectiveStats(it);
    const lines: [string, string][] = [];
    if (it.kind === "equip") { lines.push([`${SLOT_LABEL[it.slot!]} • nível ${it.level}${it.upgrade ? ` • +${it.upgrade}` : ""}`, "#9a8a70"]); for (const k of Object.keys(es) as (keyof ItemStats)[]) lines.push([`+${es[k]} ${STAT_LABEL[k]}`, "#9ad7ff"]); }
    else if (it.kind === "potion_hp" || it.kind === "potion_mp") lines.push([`Restaura ${[60, 220, 700][(it.potionSize ?? 1) - 1]} ${it.kind === "potion_hp" ? "de vida" : "de mana"}`, "#9ad7ff"]);
    else if (it.kind === "material") lines.push(["Material de missão", "#9fd88a"]);
    lines.push([`Valor: ${it.price} ouro`, "#ffd25a"]);
    const w = 240, h = 48 + lines.length * 18;
    const px = Math.min(VW - w - 10, x + 14), py = Math.max(10, Math.min(VH - h - 10, y - h / 2));
    panel(ctx, { x: px, y: py, w, h }, { dark: true });
    text(ctx, it.name, px + 12, py + 26, 15, RARITY_COLOR[it.rarity]);
    lines.forEach((l, i) => text(ctx, l[0], px + 12, py + 46 + i * 18, 13, l[1]));
  }

  drawMinimap(ctx: CanvasRenderingContext2D, r: Rect, scale: number, full = false) {
    const p = this.p, reg = p.region;
    ctx.save();
    ctx.fillStyle = "rgba(5,3,8,0.85)"; ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.strokeStyle = "#6a4a1a"; ctx.lineWidth = 2; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
    ctx.beginPath(); ctx.rect(r.x + 2, r.y + 2, r.w - 4, r.h - 4); ctx.clip();
    const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    const px = p.player.x, py = p.player.y;
    const toM = (x: number, y: number): [number, number] => [cx + ((x - px) - (y - py)) * scale, cy + ((x - px) + (y - py)) * scale * 0.5];
    const range = full ? reg.W : Math.ceil(r.w / scale);
    const step = full ? 1 : 1;
    for (let y = Math.max(0, Math.floor(py - range)); y < Math.min(reg.H, py + range); y += step)
      for (let x = Math.max(0, Math.floor(px - range)); x < Math.min(reg.W, px + range); x += step) {
        if (!reg.explored[y * reg.W + x]) continue;
        const [mx, my] = toM(x, y);
        if (mx < r.x - 4 || mx > r.x + r.w + 4 || my < r.y - 4 || my > r.y + r.h + 4) continue;
        const blocked = reg.blocked[y * reg.W + x];
        const lm = reg.liquidV[y * (reg.W + 1) + x];
        const pm = reg.pathV[y * (reg.W + 1) + x];
        ctx.fillStyle = lm ? (p.act.liquidKind === "lava" ? "#ff6a2a" : "#3a7aa8") : pm ? "#a07a4a" : blocked ? "#5a5a5a" : p.act.biome.ground[1];
        ctx.globalAlpha = 0.9;
        ctx.fillRect(mx - scale / 2, my - scale / 4, scale, scale / 2);
      }
    ctx.globalAlpha = 1;
    // village ring
    const [vx, vy] = toM(reg.village.cx, reg.village.cy);
    ctx.strokeStyle = "rgba(255,220,120,0.8)"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(vx, vy, reg.village.radius * scale, reg.village.radius * scale * 0.5, 0, 0, Math.PI * 2); ctx.stroke();
    for (const poi of reg.pois) {
      if (!poi.discovered) continue;
      const [mx, my] = toM(poi.x, poi.y);
      ctx.fillStyle = poi.id === "lair" ? "#ff2a1a" : poi.id === "waystone" ? "#9ad7ff" : poi.id === "altar" ? "#c86aff" : "#ffb347";
      ctx.beginPath(); ctx.arc(mx, my, full ? 5 : 3.5, 0, Math.PI * 2); ctx.fill();
    }
    for (const n of p.npcs) { const [mx, my] = toM(n.x, n.y); ctx.fillStyle = "#ffe9a8"; ctx.fillRect(mx - 1.5, my - 1.5, 3, 3); }
    for (const e of p.enemies) { if (e.dead || p.dist(e, p.player) > range) continue; const [mx, my] = toM(e.x, e.y); ctx.fillStyle = e.boss ? "#ff2a1a" : e.elite ? "#ffd25a" : "#d84a3a"; ctx.fillRect(mx - 1.5, my - 1.5, e.boss ? 5 : 3, e.boss ? 5 : 3); }
    const [ppx, ppy] = toM(reg.village.portal.x, reg.village.portal.y); ctx.fillStyle = "#6fa8ff"; ctx.beginPath(); ctx.arc(ppx, ppy, 3, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    if (!full) text(ctx, p.act.subtitle, r.x + r.w / 2, r.y + r.h - 6, 11, "#c8b890", "center");
  }

  renderPanel(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, big = this.bigPanel();
    const m = this.mouse;
    if (this.panel === "dead") {
      ctx.fillStyle = `rgba(60,0,0,${Math.min(0.75, p.deadT * 0.5)})`; ctx.fillRect(0, 0, VW, VH);
      fancyText(ctx, "VOCÊ MORREU", VW / 2, VH / 2 - 20, { size: 64, align: "center", colors: ["#ff8a6a", "#8a0a0a"], glow: "#ff2a1a", wave: 3, time: this.time });
      text(ctx, "A profecia ainda não terminou. Renasça na aldeia (perdeu 10% do ouro).", VW / 2, VH / 2 + 25, 16, "#f0dca0", "center");
      button(ctx, { x: VW / 2 - 120, y: VH / 2 + 60, w: 240, h: 50 }, "RENASCER", inRect(m.x, m.y, { x: VW / 2 - 120, y: VH / 2 + 60, w: 240, h: 50 }), { time: this.time });
      return;
    }
    if (this.panel === "map") {
      ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(0, 0, VW, VH);
      this.drawMinimap(ctx, { x: 140, y: 60, w: 1000, h: 600 }, 5, true);
      fancyText(ctx, `${p.act.subtitle} — Mapa (M/Tab fecha)`, VW / 2, 50, { size: 22, align: "center" });
      text(ctx, "Vermelho: covil do chefe • Azul: pedra do portal • Roxo: local misterioso • Laranja: acampamento", VW / 2, 690, 13, "#c8b890", "center");
      return;
    }
    if (this.panel === "pause") {
      ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(0, 0, VW, VH);
      panel(ctx, { x: VW / 2 - 180, y: 200, w: 360, h: 340 }, { title: "PAUSA" });
      ["CONTINUAR", "SALVAR JOGO", audio.musicVol > 0 ? "MÚSICA: LIGADA" : "MÚSICA: DESLIGADA", "SALVAR E SAIR"].forEach((l, i) => { const r = this.pauseRects()[i]; const hov = inRect(m.x, m.y, r) || this.pauseSel === i; if (inRect(m.x, m.y, r) && this.pauseSel !== i) { this.pauseSel = i; audio.sfx("hover"); } button(ctx, r, l, hov, { time: this.time, size: 18 }); });
      return;
    }
    ctx.fillStyle = "rgba(0,0,0,0.45)"; ctx.fillRect(0, 0, VW, VH);
    const titles: Record<string, string> = { inventory: "INVENTÁRIO", character: "PERSONAGEM", skills: "HABILIDADES", quests: "DIÁRIO DE MISSÕES", elder: "ANCIÃO OROMIR", smith: "GORM, O FERREIRO", merchant: "SELA, MERCADORA", traveler: "VASHTI, VIAJANTE", portal: "PORTAL DA ALDEIA" };
    panel(ctx, big, { title: titles[this.panel!] ?? "" });
    const closeR: Rect = { x: big.x + big.w - 40, y: big.y + 8, w: 32, h: 32 };
    button(ctx, closeR, "X", inRect(m.x, m.y, closeR), { size: 14 });
    switch (this.panel) {
      case "inventory": case "merchant": case "traveler": case "smith": this.renderInventoryLike(ctx); break;
      case "character": this.renderCharacter(ctx); break;
      case "skills": this.renderSkills(ctx); break;
      case "quests": this.renderQuests(ctx); break;
      case "elder": this.renderElder(ctx); break;
      case "portal": this.renderPortal(ctx); break;
    }
  }

  renderInventoryLike(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, big = this.bigPanel(), m = this.mouse;
    // grid
    const g = this.invGridRect();
    fancyText(ctx, `Mochila ${s.inventory.length}/${INV_SIZE}  •  ${s.gold} ouro`, g.x, g.y - 12, { size: 15 });
    for (let i = 0; i < INV_SIZE; i++) {
      const c = this.invCell(i);
      ctx.fillStyle = "#120c08"; ctx.fillRect(c.x, c.y, c.w, c.h); ctx.strokeStyle = "#3a2a1a"; ctx.strokeRect(c.x + 0.5, c.y + 0.5, c.w - 1, c.h - 1);
      const it = s.inventory[i];
      if (it) {
        if (it.rarity !== "normal") { ctx.save(); ctx.shadowColor = RARITY_COLOR[it.rarity]; ctx.shadowBlur = 10; ctx.strokeStyle = RARITY_COLOR[it.rarity]; ctx.strokeRect(c.x + 1.5, c.y + 1.5, c.w - 3, c.h - 3); ctx.restore(); }
        drawItemIcon(ctx, it, c.x + 5, c.y + 5, 36);
        if (it.qty > 1) text(ctx, `${it.qty}`, c.x + c.w - 4, c.y + c.h - 4, 12, "#fff", "right");
        if (it.upgrade) text(ctx, `+${it.upgrade}`, c.x + 3, c.y + 12, 11, "#ffb347");
        if (inRect(m.x, m.y, c)) { this.tooltipItem = it; this.tooltipPos = { x: m.x, y: m.y }; }
      }
    }
    const hint = this.panel === "inventory" ? "Clique: equipar/usar • Clique no equipamento para remover" : this.panel === "smith" ? "Clique em um item equipado (esquerda) para melhorar" : "Clique em item da mochila para VENDER (25% do valor) • Esquerda: comprar";
    text(ctx, hint, g.x, g.y + g.h + 24, 12, "#9a8a70");
    if (this.panel === "inventory") {
      // equipment slots
      SLOTS.forEach((sl, i) => {
        const c = this.equipCell(i);
        ctx.fillStyle = "#1a120c"; ctx.fillRect(c.x, c.y, c.w, c.h); ctx.strokeStyle = "#6a4a1a"; ctx.strokeRect(c.x + 0.5, c.y + 0.5, c.w - 1, c.h - 1);
        text(ctx, SLOT_LABEL[sl], c.x + c.w / 2, c.y - 4, 12, "#c9a24a", "center");
        const it = s.equipment[sl];
        if (it) { drawItemIcon(ctx, it, c.x + 11, c.y + 11, 48); if (it.upgrade) text(ctx, `+${it.upgrade}`, c.x + 4, c.y + 14, 12, "#ffb347"); if (inRect(m.x, m.y, c)) { this.tooltipItem = it; this.tooltipPos = { x: m.x, y: m.y }; } }
      });
      const d = p.d;
      const statsY = big.y + 360;
      [["Dano", d.dmg], ["Armadura", `${d.armor} (${Math.round(d.reduction * 100)}%)`], ["Crítico", `${d.crit.toFixed(1)}%`], ["Roubo de vida", `${d.lifeSteal}%`], ["Vida", `${Math.ceil(s.hp)}/${d.maxHp}`], ["Mana", `${Math.floor(s.mp)}/${d.maxMp}`]].forEach(([k, v], i) => { text(ctx, `${k}:`, big.x + 30, statsY + i * 22, 14, "#c9a24a"); text(ctx, `${v}`, big.x + 210, statsY + i * 22, 14, "#f0dca0", "right"); });
    } else if (this.panel === "merchant") {
      text(ctx, "Poções à venda", big.x + 20, big.y + 60, 15, "#f0dca0");
      this.merchantItems().forEach((it, i) => this.shopRow(ctx, it, i));
      text(ctx, this.dialogMsg || "“Poções frescas. Bem, relativamente frescas.”", big.x + 20, big.y + 500, 13, "#d8c8a0");
    } else if (this.panel === "traveler") {
      text(ctx, "Equipamentos raros", big.x + 20, big.y + 60, 15, "#f0dca0");
      this.shopStock.forEach((it, i) => this.shopRow(ctx, it, i));
      const refresh: Rect = { x: big.x + 20, y: big.y + 470, w: 200, h: 40 };
      button(ctx, refresh, `NOVO ESTOQUE (${40 * p.act.id})`, inRect(m.x, m.y, refresh), { size: 13, time: this.time });
      text(ctx, this.dialogMsg || "“Vindo de terras distantes... e caras.”", big.x + 20, big.y + 530, 13, "#d8c8a0");
    } else if (this.panel === "smith") {
      text(ctx, "Equipado — melhorar (+8% por nível)", big.x + 20, big.y + 60, 14, "#f0dca0");
      SLOTS.forEach((sl, i) => {
        const r = this.leftRowRect(i); const it = s.equipment[sl];
        ctx.fillStyle = inRect(m.x, m.y, r) && it ? "#2a1e14" : "#15100c"; ctx.fillRect(r.x, r.y, r.w, r.h); ctx.strokeStyle = "#4a3a1a"; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
        if (it) { drawItemIcon(ctx, it, r.x + 6, r.y + 10, 36); text(ctx, it.name.slice(0, 20), r.x + 50, r.y + 22, 12, RARITY_COLOR[it.rarity]); text(ctx, `+${it.upgrade} → +${it.upgrade + 1}: ${upgradeCost(it)} ouro`, r.x + 50, r.y + 42, 12, s.gold >= upgradeCost(it) ? "#ffd25a" : "#ff8a6a"); if (inRect(m.x, m.y, r)) { this.tooltipItem = it; this.tooltipPos = { x: m.x, y: m.y }; } }
        else text(ctx, `${SLOT_LABEL[sl]}: vazio`, r.x + 12, r.y + 34, 13, "#7a6a5a");
      });
      text(ctx, this.dialogMsg || "“Aço bom precisa de fogo bom. E de ouro.”", big.x + 20, big.y + 420, 13, "#d8c8a0");
    }
  }
  shopRow(ctx: CanvasRenderingContext2D, it: Item, i: number) {
    const r = this.leftRowRect(i), m = this.mouse, s = this.p.save;
    ctx.fillStyle = inRect(m.x, m.y, r) ? "#2a1e14" : "#15100c"; ctx.fillRect(r.x, r.y, r.w, r.h); ctx.strokeStyle = "#4a3a1a"; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
    drawItemIcon(ctx, it, r.x + 6, r.y + 10, 36);
    text(ctx, it.name.slice(0, 22), r.x + 50, r.y + 22, 12, RARITY_COLOR[it.rarity]);
    text(ctx, `${it.price} ouro`, r.x + 50, r.y + 42, 13, s.gold >= it.price ? "#ffd25a" : "#ff8a6a");
    if (inRect(m.x, m.y, r)) { this.tooltipItem = it; this.tooltipPos = { x: m.x, y: m.y }; }
  }
  renderCharacter(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, big = this.bigPanel(), d = p.d, m = this.mouse;
    fancyText(ctx, `${s.name} — ${s.evolved ? p.cls.evoName : p.cls.name}`, big.x + 30, big.y + 60, { size: 20 });
    text(ctx, `Nível ${s.level} • XP ${s.xp}/${xpToNext(s.level)} • Pontos disponíveis: ${s.statPoints}`, big.x + 30, big.y + 84, 14, s.statPoints > 0 ? "#9fff9a" : "#d8c8a0");
    const keys = ["str", "dex", "vit", "ene"] as const;
    const labels = { str: "Força", dex: "Destreza", vit: "Vitalidade", ene: "Energia" };
    keys.forEach((k, i) => {
      const y = big.y + 124 + i * 44;
      text(ctx, labels[k], big.x + 30, y, 17, "#c9a24a"); text(ctx, `${s.stats[k]}`, big.x + 220, y, 17, "#f0dca0", "right");
      const r = this.statPlusRect(i);
      button(ctx, r, "+", inRect(m.x, m.y, r), { size: 18, disabled: s.statPoints <= 0 });
    });
    text(ctx, "Força: dano corpo a corpo • Destreza: armadura/crítico • Vitalidade: vida • Energia: mana/dano mágico (Shift+clique = +5)", big.x + 30, big.y + 310, 12, "#9a8a70");
    const right = big.x + 330;
    [["Vida máxima", d.maxHp], ["Mana máxima", d.maxMp], ["Dano base", d.dmg], ["Armadura", `${d.armor} (-${Math.round(d.reduction * 100)}% dano)`], ["Chance crítica", `${d.crit.toFixed(1)}%`], ["Roubo de vida", `${d.lifeSteal}%`], ["Regeneração", `${d.regen.toFixed(1)}/s`], ["Velocidade", `${d.speed.toFixed(1)}`], ["Abates", s.kills], ["Mortes", s.deaths], ["Chefes derrotados", s.bossesKilled.length]].forEach(([k, v], i) => { text(ctx, `${k}`, right, big.y + 124 + i * 26, 14, "#c9a24a"); text(ctx, `${v}`, big.x + big.w - 40, big.y + 124 + i * 26, 14, "#f0dca0", "right"); });
    text(ctx, s.evolved ? `Classe evoluída: ${p.cls.evoName}` : `Evolução para ${p.cls.evoName} no nível ${EVOLUTION_LEVEL} (Ancião)`, big.x + 30, big.y + 500, 14, "#ffb347");
  }
  renderSkills(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, big = this.bigPanel();
    p.cls.skills.forEach((sk, i) => {
      const r: Rect = { x: big.x + 30, y: big.y + 70 + i * 90, w: big.w - 60, h: 80 };
      const locked = s.level < sk.unlock || (sk.evo && !s.evolved);
      ctx.fillStyle = p.activeSkill === i ? "#2a1e14" : "#15100c"; ctx.fillRect(r.x, r.y, r.w, r.h); ctx.strokeStyle = locked ? "#3a2a1a" : "#6a4a1a"; ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
      ctx.save(); ctx.translate(r.x + 40, r.y + 40); ctx.fillStyle = locked ? "#444" : sk.color; ctx.shadowColor = sk.color; ctx.shadowBlur = locked ? 0 : 12; this.drawSkillRune(ctx, sk.kind, 20); ctx.restore();
      fancyText(ctx, `${i + 1}. ${sk.name}${sk.evo ? "  ✦ evolução" : ""}`, r.x + 90, r.y + 28, { size: 17, colors: locked ? ["#888", "#555"] : undefined });
      text(ctx, sk.desc, r.x + 90, r.y + 50, 13, locked ? "#777" : "#e8dcc0");
      text(ctx, locked ? (sk.evo && !s.evolved ? `Requer ascensão (nível ${EVOLUTION_LEVEL})` : `Desbloqueia no nível ${sk.unlock}`) : `Mana ${sk.mp} • Recarga ${sk.cooldown}s${sk.dmg ? ` • Dano ${Math.round(p.d.dmg * sk.dmg * (1 + s.level * 0.025))}` : ""}`, r.x + 90, r.y + 70, 12, locked ? "#aa6a5a" : "#9ad7ff");
    });
    text(ctx, "Botão direito usa a habilidade ativa (roda do mouse troca). Teclas 1-5 usam diretamente.", big.x + 30, big.y + 528, 12, "#9a8a70");
  }
  renderQuests(ctx: CanvasRenderingContext2D) {
    const p = this.p, s = p.save, big = this.bigPanel();
    fancyText(ctx, p.act.name, big.x + 30, big.y + 60, { size: 18 });
    const idx = s.chapterIndex[p.act.id] ?? 0;
    p.chapters.forEach((ch, i) => {
      const y = big.y + 92 + i * 34;
      const done = i < idx, cur = i === idx;
      const col = done ? "#7a9a6a" : cur ? "#ffe9a8" : "#6a5a4a";
      text(ctx, `${done ? "✔" : cur ? "➤" : "•"} Capítulo ${i + 1}: ${cur || done ? ch.title : "???"}`, big.x + 30, y, 15, col);
      if (cur) { const lines = wrapText(ctx, ch.text, big.w - 100, 13); lines.forEach((l, j) => text(ctx, l, big.x + 50, y + 18 + j * 15, 13, "#d8c8a0")); }
    });
    text(ctx, `Atos liberados: ${s.maxAct}/5 • Chefes mortos: ${s.bossesKilled.join(", ") || "nenhum"}`, big.x + 30, big.y + 520, 13, "#9a8a70");
  }
  renderElder(ctx: CanvasRenderingContext2D) {
    const p = this.p, big = this.bigPanel(), m = this.mouse;
    const ch = p.currentChapter();
    const msg = this.dialogMsg || (ch ? (p.chapterReady(ch) && ch.kind !== "boss" ? `Você conseguiu? ${ch.done}` : ch.text) : "Você completou todos os capítulos deste ato. O portal o levará adiante — se tiver coragem.");
    const lines = wrapText(ctx, msg, big.w - 220, 17);
    const img = A.data?.portraits.elder;
    if (img) {
      const w = 160, h = 230, sc = Math.min(w / img.width, h / img.height);
      ctx.save(); ctx.shadowColor = "#ffb347"; ctx.shadowBlur = 16;
      ctx.drawImage(img, big.x + 20 + (w - img.width * sc) / 2, big.y + 50 + (h - img.height * sc) / 2, img.width * sc, img.height * sc);
      ctx.restore();
    }
    lines.forEach((l, i) => text(ctx, l, big.x + 200, big.y + 80 + i * 24, 17, "#f4e8c8"));
    this.elderOptions().forEach((o, i) => { const r = this.optionRect(i); button(ctx, r, o.label, inRect(m.x, m.y, r) && !o.disabled, { size: 15, disabled: o.disabled, time: this.time }); });
  }
  portalRect(i: number): Rect { const b = this.bigPanel(); return { x: b.x + 40, y: b.y + 100 + i * 52, w: b.w - 80, h: 44 }; }
  renderPortal(ctx: CanvasRenderingContext2D) {
    const p = this.p, big = this.bigPanel(), m = this.mouse;
    text(ctx, "O portal pulsa com energia azul. Destinos conhecidos:", big.x + 40, big.y + 70, 16, "#f0dca0");
    const list = p.waypointList();
    list.forEach((w, i) => { const r = this.portalRect(i); button(ctx, r, w.label, inRect(m.x, m.y, r), { size: 15, time: this.time, active: w.act === p.act.id }); });
    text(ctx, "Pedras do Portal são descobertas explorando cada região. Cada ato é muito mais difícil que o anterior.", big.x + 40, big.y + 520, 12, "#9a8a70");
  }
}

