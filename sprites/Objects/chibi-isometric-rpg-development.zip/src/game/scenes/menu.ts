/**
 * Title screen: parallax painted background, embers/fog particles, animated logo, ornate buttons,
 * 3 save slots, options (volumes), credits (+ Hall of Heroes from DB), seed picker for new runs.
 */
import { A } from "../core/assets";
import { audio } from "../core/audio";
import { button, drawParticles, fancyText, inRect, panel, Particle, Rect, text, updateParticles, VH, VW, vignette, wrapText } from "../core/ui";
import { makeSeedString } from "../core/rng";
import type { Game, SaveSummary, Scene } from "../Game";
import { classById } from "../data/classes";

/** PS1-style on-screen letter picker (no typing required, keyboard also works). */
export class LetterPicker {
  rows = ["ABCDEFGHIJ", "KLMNOPQRST", "UVWXYZ0123", "456789-' ."];
  cx = 0; cy = 0;
  value = "";
  max: number;
  constructor(initial = "", max = 12) { this.value = initial; this.max = max; }
  layout(): { r: Rect; ch: string }[] {
    const out: { r: Rect; ch: string }[] = [];
    const cell = 52, gap = 6;
    const w = this.rows[0].length * (cell + gap);
    const x0 = VW / 2 - w / 2, y0 = 330;
    this.rows.forEach((row, ry) => [...row].forEach((ch, rx) => out.push({ r: { x: x0 + rx * (cell + gap), y: y0 + ry * (cell + gap), w: cell, h: cell }, ch })));
    return out;
  }
  specialRects() {
    return { back: { x: VW / 2 - 240, y: 575, w: 150, h: 44 }, ok: { x: VW / 2 + 90, y: 575, w: 150, h: 44 }, rnd: { x: VW / 2 - 75, y: 575, w: 150, h: 44 } };
  }
  push(ch: string) { if (this.value.length < this.max) { this.value += ch; audio.sfx("select"); } else audio.sfx("error"); }
  pop() { this.value = this.value.slice(0, -1); audio.sfx("back"); }
  key(k: string): "ok" | "back" | null {
    if (k === "Enter") return "ok";
    if (k === "Escape") return "back";
    if (k === "Backspace") { this.pop(); return null; }
    if (k === "ArrowLeft") { this.cx = (this.cx + 9) % 10; audio.sfx("hover"); }
    else if (k === "ArrowRight") { this.cx = (this.cx + 1) % 10; audio.sfx("hover"); }
    else if (k === "ArrowUp") { this.cy = (this.cy + 3) % 4; audio.sfx("hover"); }
    else if (k === "ArrowDown") { this.cy = (this.cy + 1) % 4; audio.sfx("hover"); }
    else if (k === " ") this.push(this.rows[this.cy][this.cx]);
    else if (k.length === 1 && /[a-z0-9\-'.]/i.test(k)) this.push(k.toUpperCase());
    return null;
  }
  click(x: number, y: number): "ok" | "back" | "rnd" | null {
    for (const c of this.layout()) if (inRect(x, y, c.r)) { this.push(c.ch === " " ? " " : c.ch); return null; }
    const s = this.specialRects();
    if (inRect(x, y, s.ok)) return "ok";
    if (inRect(x, y, s.back)) return "back";
    if (inRect(x, y, s.rnd)) return "rnd";
    return null;
  }
  hover(x: number, y: number) {
    for (const [i, c] of this.layout().entries()) if (inRect(x, y, c.r)) { const nx = i % 10, ny = Math.floor(i / 10); if (nx !== this.cx || ny !== this.cy) { this.cx = nx; this.cy = ny; audio.sfx("hover"); } }
  }
  render(ctx: CanvasRenderingContext2D, title: string, time: number, mx: number, my: number, showRnd = false) {
    fancyText(ctx, title, VW / 2, 215, { size: 34, align: "center", glow: "#ff8a2a" });
    // value box
    panel(ctx, { x: VW / 2 - 260, y: 240, w: 520, h: 62 }, { dark: true });
    const caret = Math.floor(time * 2) % 2 === 0 ? "_" : " ";
    fancyText(ctx, (this.value || "") + caret, VW / 2, 283, { size: 36, align: "center", colors: ["#fff6d8", "#ffcf5a"], wave: 0 });
    for (const [i, c] of this.layout().entries()) {
      const sel = i % 10 === this.cx && Math.floor(i / 10) === this.cy;
      button(ctx, c.r, c.ch === " " ? "␣" : c.ch, sel, { size: 22, time });
    }
    const s = this.specialRects();
    button(ctx, s.back, "APAGAR", inRect(mx, my, s.back), { size: 18, time });
    if (showRnd) button(ctx, s.rnd, "ALEATÓRIO", inRect(mx, my, s.rnd), { size: 16, time });
    button(ctx, s.ok, "CONFIRMAR", inRect(mx, my, s.ok), { size: 18, time, disabled: this.value.trim().length === 0 });
    text(ctx, "Setas / mouse para escolher, Espaço ou clique para inserir, Enter para confirmar", VW / 2, 650, 14, "#9a8a70", "center");
  }
}

type MenuState = "main" | "slots_new" | "slots_continue" | "seed" | "options" | "credits" | "quit";

export class MenuScene implements Scene {
  g: Game;
  state: MenuState = "main";
  time = 0;
  sel = 0;
  particles: Particle[] = [];
  fog: { x: number; y: number; s: number; a: number; v: number }[] = [];
  saves: SaveSummary[] = [];
  deeds: Array<{ playerName: string; className: string; level: number; bossName: string; act: number }> = [];
  picker = new LetterPicker("", 16);
  chosenSlot = 1;
  confirmDelete = -1;
  parX = 0; parY = 0;
  mainItems = ["INICIAR JOGO", "CONTINUAR", "OPÇÕES", "CRÉDITOS", "SAIR DO JOGO"];
  creditsScroll = 0;
  quitT = 0;

  constructor(g: Game) {
    this.g = g;
    for (let i = 0; i < 14; i++) this.fog.push({ x: Math.random() * VW, y: 380 + Math.random() * 340, s: 180 + Math.random() * 260, a: 0.05 + Math.random() * 0.08, v: 6 + Math.random() * 14 });
  }
  enter() { audio.playMusic("menu"); this.refreshSaves(); }
  async refreshSaves() { this.saves = await this.g.listSaves(); }

  itemRects(): Rect[] {
    return this.mainItems.map((_, i) => ({ x: VW / 2 - 150, y: 345 + i * 62, w: 300, h: 48 }));
  }
  slotRects(): Rect[] { return [0, 1, 2].map((i) => ({ x: VW / 2 - 330, y: 230 + i * 130, w: 660, h: 112 })); }
  backRect(): Rect { return { x: VW / 2 - 100, y: 640, w: 200, h: 44 }; }

  update(dt: number) {
    this.time += dt;
    const m = this.g.mouse;
    this.parX += ((m.x - VW / 2) / VW - this.parX) * dt * 3;
    this.parY += ((m.y - VH / 2) / VH - this.parY) * dt * 3;
    if (Math.random() < dt * 25) this.particles.push({ x: Math.random() * VW, y: VH + 10, vx: (Math.random() - 0.5) * 30, vy: -40 - Math.random() * 60, life: 4 + Math.random() * 4, maxLife: 8, size: 1 + Math.random() * 2.5, color: Math.random() < 0.3 ? "#ffd27a" : "#ff6a2a", glow: true });
    updateParticles(this.particles, dt);
    for (const f of this.fog) { f.x += f.v * dt; if (f.x - f.s > VW) f.x = -f.s; }
    if (this.state === "credits") this.creditsScroll += dt * 28;
    if (this.state === "quit") { this.quitT += dt; }
  }

  render(ctx: CanvasRenderingContext2D) {
    const a = A.data!;
    // parallax layers
    const sw = VW * 1.1, sh = VH * 1.1;
    ctx.drawImage(a.menuSky, -VW * 0.05 - this.parX * 18, -VH * 0.05 - this.parY * 10, sw, sh);
    // fog
    for (const f of this.fog) {
      const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.s);
      g.addColorStop(0, `rgba(120,60,80,${f.a})`);
      g.addColorStop(1, "rgba(120,60,80,0)");
      ctx.fillStyle = g;
      ctx.fillRect(f.x - f.s, f.y - f.s, f.s * 2, f.s * 2);
    }
    drawParticles(ctx, this.particles, -this.parX * 30, 0);
    ctx.drawImage(a.menuFg, -VW * 0.06 - this.parX * 55, -VH * 0.06 - this.parY * 30 + 10, VW * 1.12, VH * 1.12);
    vignette(ctx, 0.75);
    if (this.state === "main" || this.state === "quit") {
      // logo (bob + glow pulse)
      const lw = 560, lh = (a.logo.height / a.logo.width) * 560;
      const ly = 70 + Math.sin(this.time * 1.2) * 6;
      ctx.save();
      ctx.shadowColor = `rgba(255,110,30,${0.5 + Math.sin(this.time * 2) * 0.25})`;
      ctx.shadowBlur = 30;
      ctx.drawImage(a.logo, VW / 2 - lw / 2 - this.parX * 8, ly, lw, lh);
      ctx.restore();
      fancyText(ctx, "Um RPG isométrico de ação", VW / 2, 60 + lh + 36, { size: 18, align: "center", colors: ["#d8c8a0", "#8a7a5a"], wave: 1.2, time: this.time });
    }
    switch (this.state) {
      case "main": this.renderMain(ctx); break;
      case "slots_new": case "slots_continue": this.renderSlots(ctx); break;
      case "seed": this.picker.render(ctx, "SEED DO MUNDO", this.time, this.g.mouse.x, this.g.mouse.y, true); text(ctx, "A mesma seed gera sempre o mesmo mundo, aldeias, caminhos e hordas.", VW / 2, 318, 14, "#c8b890", "center"); break;
      case "options": this.renderOptions(ctx); break;
      case "credits": this.renderCredits(ctx); break;
      case "quit":
        ctx.fillStyle = `rgba(0,0,0,${Math.min(1, this.quitT)})`; ctx.fillRect(0, 0, VW, VH);
        fancyText(ctx, "Até a próxima batalha, herói.", VW / 2, VH / 2, { size: 36, align: "center", alpha: Math.min(1, this.quitT) });
        text(ctx, "Você pode fechar esta aba. (Clique para voltar ao menu)", VW / 2, VH / 2 + 40, 16, "#9a8a70", "center");
        break;
    }
    text(ctx, "v0.9 MVP — Seed-based procedural world", 12, VH - 10, 12, "#6a5a4a");
  }

  renderMain(ctx: CanvasRenderingContext2D) {
    const rects = this.itemRects();
    rects.forEach((r, i) => button(ctx, r, this.mainItems[i], this.sel === i, { time: this.time, size: 24 }));
  }

  renderSlots(ctx: CanvasRenderingContext2D) {
    fancyText(ctx, this.state === "slots_new" ? "ESCOLHA UM SLOT PARA A NOVA JORNADA" : "CONTINUAR JORNADA", VW / 2, 190, { size: 30, align: "center", glow: "#ff8a2a" });
    const rects = this.slotRects();
    rects.forEach((r, i) => {
      const s = this.saves.find((x) => x.slot === i + 1);
      const hov = this.sel === i;
      panel(ctx, r, { dark: !hov });
      if (hov) { ctx.save(); ctx.strokeStyle = "#ffcf5a"; ctx.lineWidth = 2; ctx.shadowColor = "#ff9a2a"; ctx.shadowBlur = 14; ctx.strokeRect(r.x + 3, r.y + 3, r.w - 6, r.h - 6); ctx.restore(); }
      fancyText(ctx, `SLOT ${i + 1}`, r.x + 24, r.y + 40, { size: 22 });
      if (s) {
        const c = classById(s.className as never);
        const portrait = A.data!.portraits[c?.portrait ?? "warrior"];
        const ph = 96, pw = (portrait.width / portrait.height) * ph;
        ctx.drawImage(portrait, r.x + 130, r.y + 8, pw, ph);
        text(ctx, `${s.playerName}`, r.x + 240, r.y + 36, 22, "#fff0c8");
        text(ctx, `${s.data?.evolved ? c?.evoName : c?.name ?? s.className} • Nível ${s.level} • Ato ${s.act}`, r.x + 240, r.y + 62, 16, "#d8c8a0");
        const pt = Math.floor(s.playtime || 0);
        text(ctx, `Seed: ${s.seed} • Tempo: ${Math.floor(pt / 3600)}h ${Math.floor((pt % 3600) / 60)}m • Mortes: ${s.data?.deaths ?? 0}`, r.x + 240, r.y + 86, 14, "#9a8a70");
        const del: Rect = { x: r.x + r.w - 120, y: r.y + 34, w: 100, h: 40 };
        button(ctx, del, this.confirmDelete === i ? "CERTEZA?" : "APAGAR", inRect(this.g.mouse.x, this.g.mouse.y, del), { size: 14, time: this.time });
      } else {
        text(ctx, "— Vazio —", r.x + 240, r.y + 62, 20, "#7a6a5a");
      }
    });
    button(ctx, this.backRect(), "VOLTAR", inRect(this.g.mouse.x, this.g.mouse.y, this.backRect()), { size: 18, time: this.time });
  }

  optionRects() {
    return { music: { x: VW / 2 - 200, y: 300, w: 400, h: 22 } as Rect, sfx: { x: VW / 2 - 200, y: 380, w: 400, h: 22 } as Rect, testSfx: { x: VW / 2 + 220, y: 372, w: 120, h: 38 } as Rect };
  }
  renderOptions(ctx: CanvasRenderingContext2D) {
    panel(ctx, { x: VW / 2 - 320, y: 200, w: 640, h: 330 }, { title: "OPÇÕES" });
    const r = this.optionRects();
    const slider = (rect: Rect, v: number, label: string) => {
      text(ctx, label, rect.x, rect.y - 12, 18, "#f0dca0");
      ctx.fillStyle = "#1a1210"; ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
      const g = ctx.createLinearGradient(rect.x, 0, rect.x + rect.w, 0); g.addColorStop(0, "#8a2a1a"); g.addColorStop(1, "#ffb347");
      ctx.fillStyle = g; ctx.fillRect(rect.x + 2, rect.y + 2, (rect.w - 4) * v, rect.h - 4);
      ctx.strokeStyle = "#c9a24a"; ctx.strokeRect(rect.x + 0.5, rect.y + 0.5, rect.w - 1, rect.h - 1);
      ctx.fillStyle = "#ffe9a8"; ctx.fillRect(rect.x + (rect.w - 4) * v - 4, rect.y - 4, 10, rect.h + 8);
      text(ctx, `${Math.round(v * 100)}%`, rect.x + rect.w + 14, rect.y + 17, 16, "#d8c8a0");
    };
    slider(r.music, audio.musicVol, "Volume da Música");
    slider(r.sfx, audio.sfxVol, "Volume dos Efeitos");
    button(ctx, r.testSfx, "TESTAR", inRect(this.g.mouse.x, this.g.mouse.y, r.testSfx), { size: 14, time: this.time });
    const lines = ["Controles: WASD / clique para mover • Clique esquerdo ataca • 1-5 habilidades • Q/E poções",
      "I inventário • C personagem • K habilidades • J missões • M mapa • ESC pausa",
      "Arte dos personagens: LPC (CC-BY-SA 3.0). Áudio 100% sintetizado em tempo real."];
    lines.forEach((l, i) => text(ctx, l, VW / 2, 450 + i * 22, 14, "#b8a890", "center"));
    button(ctx, this.backRect(), "VOLTAR", inRect(this.g.mouse.x, this.g.mouse.y, this.backRect()), { size: 18, time: this.time });
  }

  renderCredits(ctx: CanvasRenderingContext2D) {
    panel(ctx, { x: VW / 2 - 420, y: 120, w: 840, h: 500 }, { title: "CRÉDITOS", alpha: 0.85 });
    ctx.save();
    ctx.beginPath(); ctx.rect(VW / 2 - 400, 150, 800, 450); ctx.clip();
    const lines = [
      ["PILARES DO INFERNO", 34], ["Um RPG isométrico de ação em canvas", 16], ["", 10],
      ["DIREÇÃO, CÓDIGO, GAME DESIGN", 20], ["Equipe Pilares", 16], ["", 10],
      ["ARTE", 20], ["Personagens, NPCs e inimigos: Universal LPC Spritesheet (Liberated Pixel Cup)", 14],
      ["Autores: Stephen Challener (Redshrike), Johannes Sjölund (wulax), Matthew Krohn (makrohn),", 13],
      ["Luke Mehl, Manuel Riecke, Thane Brimhall, Marcel van de Steeg, Lanea Zimmerman (Sharm) e outros — CC-BY-SA 3.0 / GPL 3.0", 13],
      ["Pinturas (menu, logo, retratos, props, cabanas): geradas e pós-processadas para este projeto", 14], ["", 10],
      ["ÁUDIO", 20], ["Trilhas e efeitos sintetizados em tempo real (Web Audio API)", 14], ["", 10],
      ["INSPIRAÇÃO", 20], ["Diablo II (Blizzard North) — eterno.", 14], ["", 20],
      ["HALL DOS HERÓIS", 24],
      ...(this.deeds.length ? this.deeds.map((d) => [`${d.playerName} (${classById(d.className as never)?.name ?? d.className} nv.${d.level}) derrotou ${d.bossName}`, 14] as [string, number]) : [["Nenhum pilar caiu ainda. Seja o primeiro.", 14] as [string, number]]),
      ["", 40], ["Obrigado por jogar.", 22],
    ] as [string, number][];
    let y = 600 - this.creditsScroll;
    for (const [t, s] of lines) {
      if (y > 140 && y < 610) {
        if (s >= 20) fancyText(ctx, t, VW / 2, y, { size: s, align: "center" });
        else text(ctx, t, VW / 2, y, s, "#e8dcc0", "center");
      }
      y += s + 10;
    }
    if (y < 140) this.creditsScroll = 0;
    ctx.restore();
    button(ctx, this.backRect(), "VOLTAR", inRect(this.g.mouse.x, this.g.mouse.y, this.backRect()), { size: 18, time: this.time });
  }

  /* ---------------- input ---------------- */
  onMouseMove(x: number, y: number) {
    if (this.state === "main") {
      this.itemRects().forEach((r, i) => { if (inRect(x, y, r) && this.sel !== i) { this.sel = i; audio.sfx("hover"); } });
    } else if (this.state === "slots_new" || this.state === "slots_continue") {
      this.slotRects().forEach((r, i) => { if (inRect(x, y, r) && this.sel !== i) { this.sel = i; audio.sfx("hover"); } });
    } else if (this.state === "seed") this.picker.hover(x, y);
    else if (this.state === "options" && this.g.mouse.down[0]) this.dragSlider(x, y);
  }
  dragSlider(x: number, y: number) {
    const r = this.optionRects();
    const v = (rect: Rect) => Math.max(0, Math.min(1, (x - rect.x) / rect.w));
    if (inRect(x, y, { ...r.music, y: r.music.y - 10, h: r.music.h + 20 })) audio.setMusicVol(v(r.music));
    if (inRect(x, y, { ...r.sfx, y: r.sfx.y - 10, h: r.sfx.h + 20 })) audio.setSfxVol(v(r.sfx));
  }
  onMouseDown(x: number, y: number, b: number) {
    if (b !== 0) return;
    switch (this.state) {
      case "main": this.itemRects().forEach((r, i) => { if (inRect(x, y, r)) this.activate(i); }); break;
      case "slots_new": case "slots_continue": {
        if (inRect(x, y, this.backRect())) { this.back(); return; }
        this.slotRects().forEach((r, i) => {
          const s = this.saves.find((x) => x.slot === i + 1);
          const del: Rect = { x: r.x + r.w - 120, y: r.y + 34, w: 100, h: 40 };
          if (s && inRect(x, y, del)) {
            if (this.confirmDelete === i) { this.g.deleteSlot(i + 1).then(() => this.refreshSaves()); this.confirmDelete = -1; audio.sfx("back"); }
            else { this.confirmDelete = i; audio.sfx("select"); }
            return;
          }
          if (inRect(x, y, r)) this.chooseSlot(i + 1);
        });
        break;
      }
      case "seed": {
        const res = this.picker.click(x, y);
        if (res === "ok" && this.picker.value.trim()) this.startNewGame(this.picker.value.trim());
        else if (res === "back") { if (this.picker.value) this.picker.pop(); else this.back(); }
        else if (res === "rnd") { this.picker.value = makeSeedString(); audio.sfx("select"); }
        break;
      }
      case "options": {
        if (inRect(x, y, this.backRect())) { this.back(); return; }
        if (inRect(x, y, this.optionRects().testSfx)) { audio.sfx("levelup"); return; }
        this.dragSlider(x, y);
        break;
      }
      case "credits": if (inRect(x, y, this.backRect())) this.back(); break;
      case "quit": this.state = "main"; this.quitT = 0; audio.playMusic("menu"); break;
    }
  }
  onKeyDown(k: string) {
    if (this.state === "main") {
      if (k === "ArrowUp") { this.sel = (this.sel + this.mainItems.length - 1) % this.mainItems.length; audio.sfx("hover"); }
      if (k === "ArrowDown") { this.sel = (this.sel + 1) % this.mainItems.length; audio.sfx("hover"); }
      if (k === "Enter") this.activate(this.sel);
    } else if (this.state === "slots_new" || this.state === "slots_continue") {
      if (k === "ArrowUp") { this.sel = (this.sel + 2) % 3; audio.sfx("hover"); }
      if (k === "ArrowDown") { this.sel = (this.sel + 1) % 3; audio.sfx("hover"); }
      if (k === "Enter") this.chooseSlot(this.sel + 1);
      if (k === "Escape") this.back();
    } else if (this.state === "seed") {
      const r = this.picker.key(k);
      if (r === "ok" && this.picker.value.trim()) this.startNewGame(this.picker.value.trim());
      if (r === "back") this.back();
    } else if (k === "Escape") this.back();
  }
  back() { audio.sfx("back"); this.state = "main"; this.confirmDelete = -1; }
  activate(i: number) {
    audio.sfx("select");
    this.sel = 0;
    switch (i) {
      case 0: this.state = "slots_new"; this.refreshSaves(); break;
      case 1: this.state = "slots_continue"; this.refreshSaves(); break;
      case 2: this.state = "options"; break;
      case 3: this.state = "credits"; this.creditsScroll = 0; this.g.listDeeds().then((d) => (this.deeds = d)); break;
      case 4: this.state = "quit"; audio.stopMusic(); try { window.close(); } catch { /* */ } break;
    }
  }
  chooseSlot(slot: number) {
    const s = this.saves.find((x) => x.slot === slot);
    if (this.state === "slots_continue") {
      if (!s) { audio.sfx("error"); return; }
      audio.sfx("select");
      this.g.currentSlot = slot;
      this.g.prepareLoaded(s.data);
      import("./play").then(({ PlayScene }) => this.g.goto(new PlayScene(this.g, s.data), 1.2));
    } else {
      audio.sfx("select");
      this.chosenSlot = slot;
      this.picker = new LetterPicker(makeSeedString(), 16);
      this.state = "seed";
    }
  }
  async startNewGame(seed: string) {
    audio.sfx("portal");
    this.g.currentSlot = this.chosenSlot;
    const { CutsceneScene } = await import("./cutscene");
    this.g.goto(new CutsceneScene(this.g, seed), 1.0);
  }
}
