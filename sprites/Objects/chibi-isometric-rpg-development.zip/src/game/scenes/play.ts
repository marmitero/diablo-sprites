/**
 * Gameplay scene: world simulation (player, enemies, allies, projectiles, loot, quests, portals),
 * isometric rendering with depth sorting + occlusion, and persistence hooks.
 * HUD / panels are in playUI.ts.
 */
import { alphaAt, AnimName, ANIM, composeSheet, Dir4, drawSheetFrame, TILE_H, TILE_W } from "../core/assets";
import { audio } from "../core/audio";
import { Particle, updateParticles, VH, VW } from "../core/ui";
import { hashString, RNG } from "../core/rng";
import type { Game, Scene } from "../Game";
import { ACTS, ActDef, ChapterTemplate, EnemyTypeDef, NPCS } from "../data/acts";
import { classById, ClassDef, EVOLUTION_LEVEL, SkillDef } from "../data/classes";
import { generateEquip, Item, makeMaterial, makePotion, potionAmount, Slot } from "../data/items";
import { Actor, Ally, canEvolve, Derived, derived, Drop, Effect, Enemy, FloatText, nextActorId, Npc, Projectile, SaveData, xpToNext } from "../world/entities";
import { generateRegion, inVillage, isWalkable, liquidMask, pathMask, Prop, Region } from "../world/mapgen";
import { PlayUI } from "./playUI";

const FPS = 11;
export const INV_SIZE = 40;

export interface Player extends Actor {
  faction: "player";
  moveTarget: { x: number; y: number } | null;
  attackTarget: Enemy | null;
  attackHit: boolean;
  cooldowns: Record<string, number>;
  buffs: { warcry: number; shield: number; shieldHp: number; phantom: number; phantomTick: number };
  castQueue: { skill: SkillDef; tx: number; ty: number } | null;
  attackCd: number;
  pendingCast: boolean;
  invuln: number;
}

export function selectChapters(act: ActDef, seed: string): ChapterTemplate[] {
  const rng = new RNG(hashString(seed + "|chapters" + act.id));
  const boss = act.chapters.find((c) => c.kind === "boss")!;
  const others = act.chapters.filter((c) => c.kind !== "boss");
  const n = Math.min(others.length, rng.int(7, 11));
  const picked = rng.shuffle([...others]).slice(0, n);
  picked.sort((a, b) => a.tier - b.tier || act.chapters.indexOf(a) - act.chapters.indexOf(b));
  return [...picked, boss];
}

export class PlayScene implements Scene {
  g: Game;
  save: SaveData;
  cls: ClassDef;
  d!: Derived;
  region!: Region;
  act!: ActDef;
  regions = new Map<number, Region>();
  player!: Player;
  enemies: Enemy[] = [];
  allies: Ally[] = [];
  npcs: Npc[] = [];
  projectiles: Projectile[] = [];
  drops: Drop[] = [];
  floats: FloatText[] = [];
  effects: Effect[] = [];
  particles: Particle[] = [];
  cam = { x: 0, y: 0 };
  shake = 0;
  time = 0;
  chapters: ChapterTemplate[] = [];
  ui: PlayUI;
  hoverEnemy: Enemy | null = null;
  hoverNpc: Npc | null = null;
  hoverDrop: Drop | null = null;
  activeSkill = 0;
  log: { text: string; color: string; t: number }[] = [];
  banner: { title: string; sub: string; t: number } | null = null;
  autosaveT = 0;
  saving = false;
  savedFlash = 0;
  dead = false;
  deadT = 0;
  bossAlive: Enemy | null = null;
  storyOverlay: { lines: string[]; t: number; onDone?: () => void } | null = null;
  enemyKilledTypes: Record<string, number> = {};
  dropId = 1;
  firstRun: boolean;

  constructor(g: Game, save: SaveData, firstRun = false) {
    this.g = g;
    this.save = save;
    this.cls = classById(save.classId);
    this.firstRun = firstRun;
    this.ui = new PlayUI(this);
  }

  enter() {
    this.recalc();
    this.enterAct(this.save.act, "village");
    if (this.save.hp <= 0) this.save.hp = this.d.maxHp;
    if (this.firstRun) this.showStory([ACTS[0].intro, "Fale com o Ancião Oromir, na cabana mais próxima, para receber sua primeira missão.", "Controles: WASD ou clique para mover • Clique em inimigos para atacar • 1-5 habilidades • Q/E poções • I inventário • J missões"]);
    else this.addLog(`Bem-vindo de volta, ${this.save.name}.`, "#ffe9a8");
  }
  exit() { audio.stopMusic(); }

  /* ---------------- stats / sheet ---------------- */
  recalc() {
    this.d = derived(this.save);
    if (this.player) {
      this.player.maxHp = this.d.maxHp;
      this.player.sheet = composeSheet(this.save.evolved ? this.cls.evoLayers : this.cls.layers);
      this.player.speed = this.d.speed;
    }
    this.save.hp = Math.min(this.save.hp, this.d.maxHp);
    this.save.mp = Math.min(this.save.mp, this.d.maxMp);
  }
  get skills(): SkillDef[] { return this.cls.skills.filter((s) => !s.evo || this.save.evolved); }

  /* ---------------- act / region ---------------- */
  enterAct(actId: number, at: "village" | "waystone") {
    this.save.act = actId;
    this.act = ACTS[actId - 1];
    if (!this.regions.has(actId)) this.regions.set(actId, generateRegion(this.save.seed, actId));
    this.region = this.regions.get(actId)!;
    this.chapters = selectChapters(this.act, this.save.seed);
    if (this.save.chapterIndex[actId] === undefined) this.save.chapterIndex[actId] = 0;
    // restore discovered POIs
    for (const p of this.region.pois) p.discovered = this.save.poisFound.includes(`${actId}:${p.id}${p.id === "camp" ? p.index : ""}`);
    const spawn = at === "waystone" ? this.region.pois.find((p) => p.id === "waystone") ?? this.region.village.spawn : this.region.village.spawn;
    const sheet = composeSheet(this.save.evolved ? this.cls.evoLayers : this.cls.layers);
    if (!this.player) {
      this.player = {
        id: nextActorId(), x: spawn.x, y: spawn.y, dir: 2, anim: "walk", frame: 0, animT: 0, playing: false, sheet, scale: 1.15,
        hp: this.save.hp, maxHp: this.d.maxHp, dead: false, deadT: 0, faction: "player", speed: this.d.speed, radius: 0.35, flash: 0, name: this.save.name,
        moveTarget: null, attackTarget: null, attackHit: false, cooldowns: {}, buffs: { warcry: 0, shield: 0, shieldHp: 0, phantom: 0, phantomTick: 0 }, castQueue: null, attackCd: 0, pendingCast: false, invuln: 0,
      };
    } else { this.player.x = spawn.x; this.player.y = spawn.y; this.player.moveTarget = null; this.player.attackTarget = null; }
    this.enemies = []; this.allies = []; this.projectiles = []; this.drops = []; this.effects = []; this.particles = []; this.floats = [];
    this.bossAlive = null;
    this.spawnNpcs();
    this.spawnEnemies();
    this.snapCamera();
    audio.playMusic("village");
    this.banner = { title: this.act.name, sub: `${this.act.villageName} — ${this.act.subtitle}`, t: 5 };
  }

  spawnNpcs() {
    this.npcs = this.region.village.npcs.map((s) => {
      const def = NPCS.find((n) => n.id === s.id)!;
      return { id: nextActorId(), x: s.x, y: s.y, dir: 2 as Dir4, anim: "walk" as AnimName, frame: 0, animT: 0, playing: false, sheet: composeSheet(def.layers), scale: 1.15, hp: 1, maxHp: 1, dead: false, deadT: 0, faction: "npc" as const, speed: 0, radius: 0.4, flash: 0, name: def.name, role: def.id, title: def.title, bobT: Math.random() * 10 };
    });
  }

  enemyLevelFor(def: EnemyTypeDef, tier: number, dist: number): number {
    const [lo, hi] = this.act.levelRange;
    const maxD = Math.hypot(this.region.W, this.region.H) * 0.7;
    return Math.round(lo + (hi - lo) * Math.min(1, Math.max(0, dist / maxD) * 0.7 + tier / this.act.enemies.length * 0.3));
  }

  makeEnemy(def: EnemyTypeDef, x: number, y: number, level: number, elite: boolean, boss: boolean): Enemy {
    const [lo] = this.act.levelRange;
    const lvlMult = 1 + (level - lo) * 0.13;
    const layers = elite ? [...def.layers, "tint:#ffd25a@0.35"] : def.layers;
    const hp = Math.round(def.hp * lvlMult * (elite ? 3.5 : 1));
    return {
      id: nextActorId(), x, y, dir: 2, anim: "walk", frame: 0, animT: Math.random() * 5, playing: false, sheet: composeSheet(layers),
      scale: (def.scale ?? 1) * (elite ? 1.25 : 1) * (boss ? 1 : 1.05), hp, maxHp: hp, dead: false, deadT: 0, faction: "enemy", speed: def.speed * (elite ? 1.15 : 1),
      radius: 0.35 * (def.scale ?? 1), flash: 0, name: boss ? def.name : elite ? `Campeão ${def.name}` : def.name,
      def, level, dmg: Math.round(def.dmg * lvlMult * (elite ? 1.6 : 1)), xp: Math.round(def.xp * lvlMult * (elite ? 4 : 1)), homeX: x, homeY: y,
      state: "idle", attackCd: Math.random(), attackHit: false, elite, boss, wanderT: Math.random() * 3, wx: x, wy: y, slow: 0, cursed: 0,
      aggro: def.aggro ?? (def.ranged ? 8 : 7), corpseUsed: false, stun: 0,
    };
  }

  spawnEnemies() {
    const r = this.region;
    const rng = new RNG(hashString(this.save.seed + "spawn" + this.act.id + Math.floor(this.time)));
    const eliteChapter = this.chapters.find((c) => c.kind === "elite");
    for (const sg of r.spawns) {
      if (sg.boss) {
        if (this.save.bossesKilled.includes(this.act.boss.id)) continue;
        const b = this.makeEnemy(this.act.boss, sg.x, sg.y, this.act.levelRange[1], false, true);
        this.enemies.push(b);
        this.bossAlive = b;
        continue;
      }
      const dist = Math.hypot(sg.x - r.village.cx, sg.y - r.village.cy);
      for (let i = 0; i < sg.count; i++) {
        let def = this.act.enemies[sg.typeIndex];
        const elite = !!sg.elite && i === 0;
        if (elite && eliteChapter) def = this.act.enemies.find((e) => e.id === eliteChapter.target) ?? def;
        else if (i > 0 && rng.chance(0.3)) def = this.act.enemies[Math.max(0, sg.typeIndex - 1)];
        let x = sg.x, y = sg.y;
        for (let t = 0; t < 10; t++) {
          const a = rng.range(0, Math.PI * 2), dd = rng.range(0, sg.radius);
          x = sg.x + Math.cos(a) * dd; y = sg.y + Math.sin(a) * dd;
          if (isWalkable(r, x, y) && !inVillage(r, x, y)) break;
        }
        if (!isWalkable(r, x, y)) continue;
        this.enemies.push(this.makeEnemy(def, x, y, this.enemyLevelFor(def, sg.typeIndex, dist), elite, false));
      }
    }
  }

  /* ---------------- helpers ---------------- */
  toScreen(x: number, y: number): [number, number] {
    return [(x - y) * (TILE_W / 2) - this.cam.x + VW / 2, (x + y) * (TILE_H / 2) - this.cam.y + VH / 2];
  }
  toWorld(sx: number, sy: number): [number, number] {
    const px = sx + this.cam.x - VW / 2, py = sy + this.cam.y - VH / 2;
    return [(px / (TILE_W / 2) + py / (TILE_H / 2)) / 2, (py / (TILE_H / 2) - px / (TILE_W / 2)) / 2];
  }
  snapCamera() { this.cam.x = (this.player.x - this.player.y) * (TILE_W / 2); this.cam.y = (this.player.x + this.player.y) * (TILE_H / 2); }
  dirTo(dx: number, dy: number): Dir4 {
    // world axes -> screen: sx = dx - dy, sy = (dx + dy)/2
    const sx = dx - dy, sy = dx + dy;
    if (Math.abs(sx) > Math.abs(sy) * 0.9) return sx > 0 ? 3 : 1;
    return sy > 0 ? 2 : 0;
  }
  addLog(t: string, color = "#e8dcc0") { this.log.push({ text: t, color, t: 7 }); if (this.log.length > 6) this.log.shift(); }
  showStory(lines: string[], onDone?: () => void) { this.storyOverlay = { lines, t: 0, onDone }; }
  float(x: number, y: number, t: string, color: string, size = 16) { this.floats.push({ x, y, text: t, color, life: 1.1, vy: -1.2, size }); }
  burst(x: number, y: number, color: string, n = 10, speed = 60, size = 3, life = 0.6, glow = true) {
    const [sx, sy] = [x, y];
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = Math.random() * speed;
      this.particles.push({ x: sx, y: sy, vx: Math.cos(a) * s / 32, vy: Math.sin(a) * s / 32, life: life * (0.5 + Math.random()), maxLife: life, size: size * (0.5 + Math.random()), color, glow, grav: 0 });
    }
  }
  playAnim(a: Actor, anim: AnimName, loop = false) { a.anim = anim; a.frame = 0; a.animT = 0; a.playing = !loop; }
  stepAnim(a: Actor, dt: number, fps = FPS) {
    const def = ANIM[a.anim];
    a.animT += dt * fps;
    if (a.playing) {
      a.frame = Math.floor(a.animT);
      if (a.frame >= def.frames) {
        if (a.dead) { a.frame = def.frames - 1; return; }
        a.playing = false; a.anim = "walk"; a.frame = 0; a.animT = 0;
      }
    } else a.frame = Math.floor(a.animT) % def.frames;
  }
  tryMove(a: Actor, dx: number, dy: number, allowVillage = true): boolean {
    const r = this.region;
    let moved = false;
    const nx = a.x + dx;
    if (isWalkable(r, nx, a.y) && (allowVillage || !inVillage(r, nx, a.y))) { a.x = nx; moved = true; }
    const ny = a.y + dy;
    if (isWalkable(r, a.x, ny) && (allowVillage || !inVillage(r, a.x, ny))) { a.y = ny; moved = true; }
    return moved;
  }
  dist(a: { x: number; y: number }, b: { x: number; y: number }) { return Math.hypot(a.x - b.x, a.y - b.y); }

  /* ---------------- update ---------------- */
  update(dt: number) {
    this.time += dt;
    this.save.playtime += dt;
    this.autosaveT += dt;
    if (this.autosaveT > 90) { this.autosaveT = 0; this.persist(); }
    if (this.savedFlash > 0) this.savedFlash -= dt;
    if (this.banner) { this.banner.t -= dt; if (this.banner.t <= 0) this.banner = null; }
    for (const l of this.log) l.t -= dt;
    this.log = this.log.filter((l) => l.t > 0);
    if (this.storyOverlay) { this.storyOverlay.t += dt; return; }
    if (this.ui.panel === "pause") return;
    const p = this.player;
    if (this.dead) {
      this.deadT += dt;
      this.stepAnim(p, dt);
      this.updateFx(dt);
      return;
    }
    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateAllies(dt);
    this.updateProjectiles(dt);
    this.updateDrops(dt);
    this.updateFx(dt);
    this.updateExploration();
    // camera follow
    const tx = (p.x - p.y) * (TILE_W / 2), ty = (p.x + p.y) * (TILE_H / 2);
    this.cam.x += (tx - this.cam.x) * Math.min(1, dt * 6);
    this.cam.y += (ty - this.cam.y) * Math.min(1, dt * 6);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 30);
    // music
    const inV = inVillage(this.region, p.x, p.y);
    const bossNear = this.bossAlive && !this.bossAlive.dead && this.dist(p, this.bossAlive) < 14;
    audio.playMusic(bossNear ? "boss" : inV ? "village" : this.act.music);
  }

  updatePlayer(dt: number) {
    const p = this.player, s = this.save, d = this.d;
    // regen
    s.hp = Math.min(d.maxHp, s.hp + (d.regen + (inVillage(this.region, p.x, p.y) ? d.maxHp * 0.02 : 0)) * dt);
    s.mp = Math.min(d.maxMp, s.mp + (1.5 + s.stats.ene * 0.03 + s.level * 0.1) * dt);
    for (const k of Object.keys(p.cooldowns)) p.cooldowns[k] = Math.max(0, p.cooldowns[k] - dt);
    p.attackCd = Math.max(0, p.attackCd - dt);
    p.invuln = Math.max(0, p.invuln - dt);
    if (p.flash > 0) p.flash -= dt;
    const b = p.buffs;
    b.warcry = Math.max(0, b.warcry - dt); b.shield = Math.max(0, b.shield - dt);
    if (b.phantom > 0) {
      b.phantom -= dt; b.phantomTick -= dt;
      if (b.phantomTick <= 0) {
        b.phantomTick = 0.45;
        for (const e of this.enemies) if (!e.dead && this.dist(e, p) < 2.6) this.damageEnemy(e, d.dmg * 0.9, false, "#9ad7ff");
      }
    }
    // keyboard movement
    const k = this.g.keys;
    let mx = 0, my = 0;
    // screen-relative: W = up on screen => world (-1,-1); D = right => (+1,-1)
    if (k.has("w") || k.has("ArrowUp")) { mx -= 1; my -= 1; }
    if (k.has("s") || k.has("ArrowDown")) { mx += 1; my += 1; }
    if (k.has("a") || k.has("ArrowLeft")) { mx -= 1; my += 1; }
    if (k.has("d") || k.has("ArrowRight")) { mx += 1; my -= 1; }
    const busy = p.playing && p.anim !== "walk";
    let moving = false;
    if ((mx || my) && !busy) {
      p.moveTarget = null; p.attackTarget = null;
      const l = Math.hypot(mx, my); mx /= l; my /= l;
      this.tryMove(p, mx * p.speed * dt, my * p.speed * dt);
      p.dir = this.dirTo(mx, my); moving = true;
    } else if (p.attackTarget && !busy) {
      const t = p.attackTarget;
      if (t.dead) p.attackTarget = null;
      else if (this.dist(p, t) <= d.attackRange + t.radius) { this.basicAttack(t); }
      else {
        const dx = t.x - p.x, dy = t.y - p.y, l = Math.hypot(dx, dy);
        this.tryMove(p, dx / l * p.speed * dt, dy / l * p.speed * dt);
        p.dir = this.dirTo(dx, dy); moving = true;
      }
    } else if (p.moveTarget && !busy) {
      const dx = p.moveTarget.x - p.x, dy = p.moveTarget.y - p.y, l = Math.hypot(dx, dy);
      if (l < 0.15) p.moveTarget = null;
      else {
        const moved = this.tryMove(p, dx / l * Math.min(l, p.speed * dt), dy / l * Math.min(l, p.speed * dt));
        if (!moved) p.moveTarget = null;
        p.dir = this.dirTo(dx, dy); moving = true;
      }
    }
    // held left mouse: continue moving toward cursor if not over an enemy
    if (this.g.mouse.down[0] && !busy && !this.ui.panel && !this.ui.pointerOverUI(this.g.mouse.x, this.g.mouse.y) && !this.hoverEnemy && !this.hoverNpc) {
      const [wx, wy] = this.toWorld(this.g.mouse.x, this.g.mouse.y);
      p.moveTarget = { x: wx, y: wy };
    }
    if (!busy) {
      if (moving) { if (p.anim !== "walk") { p.anim = "walk"; p.animT = 0; } }
      else { p.anim = "walk"; p.frame = 0; p.animT = 0; }
    }
    // pending cast: execute at hit frame
    if (p.castQueue && p.playing) {
      const def = ANIM[p.anim];
      if (p.frame >= Math.floor(def.frames * 0.5)) { const c = p.castQueue; p.castQueue = null; this.executeSkill(c.skill, c.tx, c.ty); }
    }
    if (moving || busy) this.stepAnim(p, dt, FPS * (busy ? d.attackSpeed : 1));
    // basic attack hit frame
    if (p.playing && p.attackTarget && !p.attackHit && p.frame >= Math.floor(ANIM[p.anim].frames * 0.5)) {
      p.attackHit = true;
      const t = p.attackTarget;
      if (this.cls.ranged) this.fireProjectile(p.x, p.y, t.x, t.y, d.dmg, "player", this.cls.id === "necromancer" ? "bone" : "fire", this.cls.id === "necromancer" ? "#e8e0c8" : "#ff8a2a", 0.3, 0, 0);
      else if (!t.dead && this.dist(p, t) <= d.attackRange + t.radius + 0.4) {
        this.damageEnemy(t, d.dmg, true);
        audio.sfx("sword");
        for (const e of this.enemies) if (e !== t && !e.dead && this.dist(e, p) < 1.5 && this.cls.id === "warrior") this.damageEnemy(e, d.dmg * 0.4, false);
      }
    }
    // hover detection
    const [mwx, mwy] = this.toWorld(this.g.mouse.x, this.g.mouse.y);
    this.hoverEnemy = null; this.hoverNpc = null; this.hoverDrop = null;
    let best = 0.9;
    for (const e of this.enemies) { if (e.dead) continue; const dd = Math.hypot(e.x - mwx + 0.3, e.y - mwy + 0.3) / (e.scale); if (dd < best) { best = dd; this.hoverEnemy = e; } }
    for (const n of this.npcs) { const dd = Math.hypot(n.x - mwx + 0.3, n.y - mwy + 0.3); if (dd < 0.9) this.hoverNpc = n; }
    for (const dr of this.drops) { const dd = Math.hypot(dr.x - mwx, dr.y - mwy); if (dd < 0.6) this.hoverDrop = dr; }
  }

  basicAttack(t: Enemy) {
    const p = this.player;
    if (p.attackCd > 0 || p.playing) return;
    p.dir = this.dirTo(t.x - p.x, t.y - p.y);
    this.playAnim(p, this.cls.attackAnim);
    p.attackHit = false;
    p.attackCd = 0.1;
  }

  /* ---------------- skills ---------------- */
  castSkill(i: number, sx: number, sy: number) {
    const sk = this.skills[i];
    if (!sk || this.dead) return;
    const p = this.player, s = this.save;
    if (s.level < sk.unlock) { this.addLog(`${sk.name} desbloqueia no nível ${sk.unlock}.`, "#ff8a6a"); audio.sfx("error"); return; }
    if ((p.cooldowns[sk.id] ?? 0) > 0) return;
    if (s.mp < sk.mp) { this.float(p.x, p.y - 1.5, "Sem mana!", "#6f8cff"); audio.sfx("error"); return; }
    if (p.playing && p.anim !== "walk") return;
    const [tx, ty] = this.toWorld(sx, sy);
    s.mp -= sk.mp;
    p.cooldowns[sk.id] = sk.cooldown;
    p.moveTarget = null; p.attackTarget = null;
    p.dir = this.dirTo(tx - p.x, ty - p.y);
    this.playAnim(p, sk.anim);
    p.castQueue = { skill: sk, tx, ty };
    audio.sfx(sk.sfx);
  }

  executeSkill(sk: SkillDef, tx: number, ty: number) {
    const p = this.player, d = this.d;
    const dmg = d.dmg * sk.dmg * (1 + this.save.level * 0.025) * (p.buffs.warcry > 0 ? 1.3 : 1);
    const near = (x: number, y: number, r: number) => this.enemies.filter((e) => !e.dead && this.dist(e, { x, y }) < r + e.radius);
    const clampRange = (range: number) => { const l = this.dist(p, { x: tx, y: ty }); if (l > range) { tx = p.x + (tx - p.x) / l * range; ty = p.y + (ty - p.y) / l * range; } };
    switch (sk.kind) {
      case "melee_aoe":
        for (const e of near(p.x, p.y, sk.radius!)) this.damageEnemy(e, dmg, true, sk.color);
        this.effects.push({ kind: "slashArc", x: p.x, y: p.y, radius: sk.radius, color: sk.color, life: 0.4, maxLife: 0.4 });
        break;
      case "dash": {
        clampRange(sk.range!);
        const dx = tx - p.x, dy = ty - p.y, l = Math.hypot(dx, dy) || 1;
        const hit = new Set<number>();
        for (let i = 0; i < l * 4; i++) {
          if (!this.tryMove(p, dx / l * 0.25, dy / l * 0.25)) break;
          for (const e of near(p.x, p.y, 1.1)) if (!hit.has(e.id)) { hit.add(e.id); this.damageEnemy(e, dmg, true, sk.color); e.stun = 1.2; }
          this.burst(p.x, p.y, sk.color, 2, 20, 3, 0.5);
        }
        p.invuln = 0.3;
        break;
      }
      case "buff":
        p.buffs.warcry = 10;
        this.effects.push({ kind: "ring", x: p.x, y: p.y, radius: sk.radius, color: sk.color, life: 0.6, maxLife: 0.6 });
        for (const e of near(p.x, p.y, sk.radius!)) e.stun = Math.max(e.stun, 0.8);
        break;
      case "quake":
        for (const e of near(p.x, p.y, sk.radius!)) { this.damageEnemy(e, dmg, true, sk.color); e.stun = 1; }
        this.effects.push({ kind: "crack", x: p.x, y: p.y, radius: sk.radius, color: sk.color, life: 1.2, maxLife: 1.2 });
        this.shake = 14;
        break;
      case "phantom":
        p.buffs.phantom = 8;
        this.effects.push({ kind: "ring", x: p.x, y: p.y, radius: 2.5, color: sk.color, life: 0.5, maxLife: 0.5 });
        break;
      case "projectile": {
        const kind = sk.id === "fireball" ? "fire" : sk.id === "hammer" ? "holy" : "bone";
        this.fireProjectile(p.x, p.y, tx, ty, dmg, "player", kind, sk.color, 0.35, kind === "holy" ? 3 : 1, sk.radius ?? 0, sk.color2);
        break;
      }
      case "heal":
        this.save.hp = Math.min(d.maxHp, this.save.hp + d.maxHp * 0.35);
        this.float(p.x, p.y - 1.5, `+${Math.round(d.maxHp * 0.35)}`, "#8aff8a", 20);
        this.effects.push({ kind: "aura", x: p.x, y: p.y, color: sk.color, life: 1, maxLife: 1 });
        break;
      case "nova":
        for (const e of near(p.x, p.y, sk.radius!)) { this.damageEnemy(e, dmg, true, sk.color); if (sk.id === "frostnova") e.slow = 3.5; }
        this.effects.push({ kind: "ring", x: p.x, y: p.y, radius: sk.radius, color: sk.color, color2: sk.color2, life: 0.7, maxLife: 0.7 });
        this.burst(p.x, p.y, sk.color2 ?? sk.color, 30, 160, 3, 0.8);
        break;
      case "shield":
        p.buffs.shield = 8; p.buffs.shieldHp = d.maxHp * 0.5;
        this.effects.push({ kind: "aura", x: p.x, y: p.y, color: sk.color, life: 1, maxLife: 1 });
        break;
      case "judgement": {
        const list = near(p.x, p.y, sk.radius!).slice(0, 8);
        if (!list.length) this.float(p.x, p.y - 1.5, "Sem alvos", "#ffd27a");
        for (const e of list) { this.damageEnemy(e, dmg, true, sk.color); this.effects.push({ kind: "pillar", x: e.x, y: e.y, color: sk.color, color2: sk.color2, life: 0.9, maxLife: 0.9 }); }
        this.shake = 8;
        break;
      }
      case "summon":
        if (this.allies.length >= 3) { const old = this.allies.shift(); if (old) this.burst(old.x, old.y, "#9fd88a", 10); }
        this.summonSkeleton(p.x + 0.6, p.y + 0.6, dmg, false);
        break;
      case "army":
        this.allies = this.allies.slice(-3);
        for (let i = 0; i < 5; i++) this.summonSkeleton(p.x + Math.cos(i * 1.26) * 1.2, p.y + Math.sin(i * 1.26) * 1.2, dmg, true);
        this.effects.push({ kind: "summonCircle", x: p.x, y: p.y, radius: 2.5, color: sk.color, life: 1, maxLife: 1 });
        break;
      case "corpse": {
        clampRange(sk.range!);
        const corpses = this.enemies.filter((e) => e.dead && !e.corpseUsed && this.dist(e, { x: tx, y: ty }) < 2.5);
        if (!corpses.length) { this.float(tx, ty, "Nenhum cadáver", "#b8ff5a"); this.save.mp += sk.mp; break; }
        for (const c of corpses.slice(0, 3)) {
          c.corpseUsed = true; c.deadT = 99;
          for (const e of near(c.x, c.y, sk.radius!)) this.damageEnemy(e, dmg, true, sk.color);
          this.effects.push({ kind: "ring", x: c.x, y: c.y, radius: sk.radius, color: sk.color, color2: sk.color2, life: 0.5, maxLife: 0.5 });
          this.burst(c.x, c.y, "#8a1a1a", 25, 140, 4, 0.9, false);
          this.burst(c.x, c.y, sk.color, 12, 100, 3, 0.6);
        }
        this.shake = 5;
        break;
      }
      case "curse":
        clampRange(sk.range!);
        for (const e of near(tx, ty, sk.radius!)) { e.cursed = 8; }
        this.effects.push({ kind: "ring", x: tx, y: ty, radius: sk.radius, color: sk.color, life: 1, maxLife: 1 });
        break;
      case "chain": {
        clampRange(sk.range!);
        let cur: { x: number; y: number } = { x: p.x, y: p.y };
        let cand = this.enemies.filter((e) => !e.dead && this.dist(e, { x: tx, y: ty }) < 3);
        const hit = new Set<number>();
        for (let i = 0; i < 5 && cand.length; i++) {
          cand.sort((a, b) => this.dist(a, cur) - this.dist(b, cur));
          const e = cand[0];
          hit.add(e.id);
          this.effects.push({ kind: "beam", x: cur.x, y: cur.y, x2: e.x, y2: e.y, color: sk.color, color2: sk.color2, life: 0.35, maxLife: 0.35 });
          this.damageEnemy(e, dmg * Math.pow(0.85, i), true, sk.color);
          cur = e;
          cand = this.enemies.filter((x) => !x.dead && !hit.has(x.id) && this.dist(x, cur) < 4.5);
        }
        if (!hit.size) this.float(tx, ty, "Sem alvos", sk.color);
        break;
      }
      case "teleport": {
        clampRange(sk.range!);
        this.burst(p.x, p.y, sk.color, 20, 120, 3, 0.6);
        if (isWalkable(this.region, tx, ty)) { p.x = tx; p.y = ty; p.invuln = 0.4; }
        else this.float(p.x, p.y - 1.5, "Bloqueado", "#ff8a6a");
        this.burst(p.x, p.y, sk.color, 20, 120, 3, 0.6);
        this.effects.push({ kind: "ring", x: p.x, y: p.y, radius: 1.2, color: sk.color, life: 0.4, maxLife: 0.4 });
        break;
      }
      case "meteor":
        clampRange(sk.range!);
        this.effects.push({ kind: "meteor", x: tx, y: ty, radius: sk.radius, color: sk.color, color2: sk.color2, life: 1.0, maxLife: 1.0, data: dmg });
        break;
    }
  }

  summonSkeleton(x: number, y: number, dmg: number, elite: boolean) {
    const hp = Math.round(this.d.maxHp * (elite ? 0.8 : 0.5));
    this.allies.push({
      id: nextActorId(), x, y, dir: 2, anim: "walk", frame: 0, animT: 0, playing: false, sheet: composeSheet(elite ? ["body_skeleton", "torso_chain", "head_chain_hood", "wpn_spear", "tint:#5aff9a@0.25"] : ["body_skeleton", "wpn_dagger", "tint:#9fd88a@0.2"]),
      scale: elite ? 1.2 : 1.05, hp, maxHp: hp, dead: false, deadT: 0, faction: "ally", speed: 4.2, radius: 0.3, flash: 0, name: elite ? "Esqueleto de Elite" : "Esqueleto",
      dmg: dmg * (elite ? 1 : 0.7), life: elite ? 45 : 40, attackCd: 0, attackHit: false, target: null,
    });
    this.effects.push({ kind: "summonCircle", x, y, radius: 0.8, color: "#9fd88a", life: 0.6, maxLife: 0.6 });
  }

  fireProjectile(x: number, y: number, tx: number, ty: number, dmg: number, owner: Projectile["owner"], kind: Projectile["kind"], color: string, radius: number, pierce: number, splash: number, color2?: string) {
    const dx = tx - x, dy = ty - y, l = Math.hypot(dx, dy) || 1;
    const sp = owner === "player" ? 11 : 7;
    this.projectiles.push({ x, y: y, vx: dx / l * sp, vy: dy / l * sp, dmg, owner, color, color2, radius, pierce, life: 1.3, kind, hit: new Set(), splash });
  }

  /* ---------------- damage ---------------- */
  damageEnemy(e: Enemy, amount: number, canCrit: boolean, color = "#ffffff") {
    if (e.dead) return;
    let dmg = amount * (e.cursed > 0 ? 1.5 : 1);
    let crit = false;
    if (canCrit && Math.random() * 100 < this.d.crit) { dmg *= 1.8; crit = true; }
    dmg = Math.round(dmg);
    e.hp -= dmg;
    e.flash = 0.15;
    this.float(e.x, e.y - 1.6 * e.scale, String(dmg), crit ? "#ffe05a" : "#fff", crit ? 22 : 16);
    this.burst(e.x, e.y - 0.6, color === "#ffffff" ? "#ff3a3a" : color, 6, 80, 2.5, 0.5);
    audio.sfx("hit");
    if (this.d.lifeSteal > 0) this.save.hp = Math.min(this.d.maxHp, this.save.hp + dmg * this.d.lifeSteal / 100);
    if (e.state === "idle") { e.state = "chase"; }
    if (e.hp <= 0) this.killEnemy(e);
  }
  damagePlayer(amount: number, from?: { x: number; y: number }) {
    const p = this.player;
    if (p.invuln > 0 || this.dead) return;
    let dmg = amount * (1 - this.d.reduction - (p.buffs.warcry > 0 ? 0.15 : 0));
    if (p.buffs.shield > 0) { const abs = Math.min(p.buffs.shieldHp, dmg * 0.7); p.buffs.shieldHp -= abs; dmg -= abs; if (p.buffs.shieldHp <= 0) p.buffs.shield = 0; }
    dmg = Math.max(1, Math.round(dmg));
    this.save.hp -= dmg;
    p.flash = 0.2;
    this.float(p.x, p.y - 1.8, `-${dmg}`, "#ff5a5a", 18);
    audio.sfx("hurt");
    this.shake = Math.max(this.shake, 3);
    if (from) this.burst(p.x, p.y - 0.6, "#ff2a2a", 5, 60, 2.5, 0.4, false);
    if (this.save.hp <= 0) this.die();
  }
  die() {
    this.dead = true; this.deadT = 0;
    this.save.hp = 0; this.save.deaths++;
    const p = this.player;
    p.dead = true; this.playAnim(p, "hurt");
    audio.sfx("die");
    const loss = Math.floor(this.save.gold * 0.1);
    this.save.gold -= loss;
    this.addLog(`Você morreu. Perdeu ${loss} de ouro.`, "#ff5a5a");
    this.ui.panel = "dead";
  }
  respawn() {
    const p = this.player;
    this.dead = false; p.dead = false; p.playing = false; p.anim = "walk"; p.frame = 0;
    this.save.hp = this.d.maxHp; this.save.mp = this.d.maxMp;
    p.x = this.region.village.spawn.x; p.y = this.region.village.spawn.y;
    p.moveTarget = null; p.attackTarget = null;
    for (const e of this.enemies) if (!e.dead) { e.state = "return"; }
    this.allies = [];
    this.ui.panel = null;
    this.snapCamera();
    audio.sfx("portal");
  }
  killEnemy(e: Enemy) {
    e.dead = true; e.deadT = 0; e.hp = 0;
    this.playAnim(e, "hurt");
    audio.sfx(e.boss ? "boss" : "die");
    this.save.kills++;
    this.enemyKilledTypes[e.def.id] = (this.enemyKilledTypes[e.def.id] ?? 0) + 1;
    this.gainXp(e.xp);
    this.dropLoot(e);
    // chapter progress
    const ch = this.currentChapter();
    if (ch) {
      if (ch.kind === "kill" && (ch.target === "any" || ch.target === e.def.id)) this.save.chapterProgress = Math.min(ch.count ?? 1, this.save.chapterProgress + 1);
      if (ch.kind === "elite" && e.elite && ch.target === e.def.id) this.save.chapterProgress = 1;
      if (ch.kind === "boss" && e.boss) { this.save.chapterProgress = 1; }
      if (this.chapterReady(ch) && ch.kind !== "boss") { this.addLog(`Missão "${ch.title}" pronta! Fale com o Ancião.`, "#ffe9a8"); audio.sfx("quest"); }
    }
    if (e.boss) this.onBossKilled(e);
  }
  onBossKilled(e: Enemy) {
    const s = this.save;
    if (!s.bossesKilled.includes(e.def.id)) s.bossesKilled.push(e.def.id);
    this.bossAlive = null;
    this.g.recordDeed(s, e.def.name);
    // auto-complete boss chapter
    const ch = this.currentChapter();
    if (ch && ch.kind === "boss") this.completeChapter(ch);
    const nextAct = this.act.id + 1;
    if (nextAct <= ACTS.length) {
      s.maxAct = Math.max(s.maxAct, nextAct);
      const wp = `${nextAct}:village`;
      if (!s.waypoints.includes(wp)) s.waypoints.push(wp);
    }
    const lines = [this.act.outro];
    if (this.act.id === 4) lines.push("LÚCIFER: Mortal... você derrubou meus pilares. Sua determinação me diverte. Venha aos meus domínios — se tiver coragem de terminar o que começou.");
    if (this.act.id === 5) lines.push(`${s.name}, nunca esquecerei esse nome. Esse é o nome de quem libertou o mundo da guerra. — Fim (por enquanto). Continue explorando: o mundo ainda tem hordas e tesouros.`);
    else lines.push(`O portal da aldeia agora leva a ${ACTS[nextAct - 1].villageName}. Aviso: a dificuldade lá é brutal — talvez valha fortalecer-se aqui antes.`);
    setTimeout(() => this.showStory(lines, () => this.persist()), 1200);
  }

  /* ---------------- loot ---------------- */
  dropLoot(e: Enemy) {
    const rng = new RNG(Math.floor(Math.random() * 1e9));
    const mult = e.def.dropMult ?? (e.elite ? 3 : 1);
    const lvl = e.level;
    const place = (item: Item, gold?: number) => this.drops.push({ id: this.dropId++, x: e.x + rng.range(-0.6, 0.6), y: e.y + rng.range(-0.6, 0.6), item, bob: rng.range(0, 6), gold, life: 240 });
    if (rng.chance(0.65)) { const g = Math.round((4 + lvl * 3) * rng.range(0.6, 1.6) * mult); place({ uid: 0, kind: "gold", name: `${g} ouro`, rarity: "normal", level: 1, stats: {}, upgrade: 0, price: 0, qty: g }, g); }
    if (rng.chance(0.14 * Math.min(2, mult))) place(makePotion(rng.chance(0.6) ? "potion_hp" : "potion_mp", Math.min(3, this.act.id) as 1 | 2 | 3));
    const equipChance = Math.min(0.9, 0.16 * mult);
    if (rng.chance(equipChance)) place(generateEquip(rng, lvl, e.boss ? (rng.chance(0.5) ? "unique" : "rare") : e.elite ? (rng.chance(0.4) ? "rare" : "magic") : undefined));
    if (e.boss) for (let i = 0; i < 3; i++) place(generateEquip(rng, lvl, rng.chance(0.3) ? "rare" : "magic"));
    const ch = this.currentChapter();
    if (ch && ch.kind === "collect" && rng.chance(e.boss ? 1 : 0.45)) place(makeMaterial(this.act.collectible.id, this.act.collectible.name));
  }
  updateDrops(dt: number) {
    const p = this.player;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.bob += dt * 3; d.life -= dt;
      if (d.life <= 0) { this.drops.splice(i, 1); continue; }
      if (this.dist(d, p) < 0.7 && (d.gold || d.item.kind !== "equip" || this.hoverDrop === d || p.moveTarget)) {
        if (this.pickup(d)) this.drops.splice(i, 1);
      }
    }
  }
  pickup(d: Drop): boolean {
    if (d.gold) { this.save.gold += d.gold; this.float(d.x, d.y - 1, `+${d.gold} ouro`, "#ffd25a", 14); audio.sfx("coin"); return true; }
    if (this.addItem(d.item)) { this.float(d.x, d.y - 1, d.item.name, "#e8dcc0", 14); audio.sfx(d.item.kind === "equip" ? "pickup" : "pickup"); if (d.item.kind === "material") this.checkCollect(); return true; }
    this.float(d.x, d.y - 1, "Inventário cheio", "#ff8a6a", 14);
    return false;
  }
  addItem(it: Item): boolean {
    const inv = this.save.inventory;
    if (it.kind !== "equip") {
      const same = inv.find((x) => x.kind === it.kind && x.name === it.name && x.materialId === it.materialId && x.potionSize === it.potionSize);
      if (same) { same.qty += it.qty; return true; }
    }
    if (inv.length >= INV_SIZE) return false;
    inv.push(it);
    return true;
  }
  countMaterial(id: string) { return this.save.inventory.filter((i) => i.kind === "material" && i.materialId === id).reduce((a, b) => a + b.qty, 0); }
  removeMaterial(id: string, n: number) {
    for (const it of [...this.save.inventory]) {
      if (n <= 0) break;
      if (it.kind === "material" && it.materialId === id) { const take = Math.min(n, it.qty); it.qty -= take; n -= take; if (it.qty <= 0) this.save.inventory.splice(this.save.inventory.indexOf(it), 1); }
    }
  }
  checkCollect() {
    const ch = this.currentChapter();
    if (ch && ch.kind === "collect") { this.save.chapterProgress = Math.min(ch.count ?? 1, this.countMaterial(ch.target!)); if (this.chapterReady(ch)) { this.addLog(`Coleta completa! Fale com o Ancião.`, "#ffe9a8"); audio.sfx("quest"); } }
  }
  usePotion(kind: "potion_hp" | "potion_mp") {
    const list = this.save.inventory.filter((i) => i.kind === kind).sort((a, b) => (a.potionSize ?? 1) - (b.potionSize ?? 1));
    const it = list[0];
    if (!it) { this.float(this.player.x, this.player.y - 1.5, "Sem poções", "#ff8a6a"); audio.sfx("error"); return; }
    const amt = potionAmount(it.potionSize ?? 1);
    if (kind === "potion_hp") { this.save.hp = Math.min(this.d.maxHp, this.save.hp + amt); this.float(this.player.x, this.player.y - 1.5, `+${amt}`, "#ff6a6a", 20); }
    else { this.save.mp = Math.min(this.d.maxMp, this.save.mp + amt); this.float(this.player.x, this.player.y - 1.5, `+${amt}`, "#6f8cff", 20); }
    it.qty--; if (it.qty <= 0) this.save.inventory.splice(this.save.inventory.indexOf(it), 1);
    audio.sfx("potion");
  }
  equip(it: Item) {
    if (it.kind !== "equip" || !it.slot) return;
    const s = this.save;
    const prev = s.equipment[it.slot];
    s.inventory.splice(s.inventory.indexOf(it), 1);
    s.equipment[it.slot] = it;
    if (prev) s.inventory.push(prev);
    this.recalc();
    audio.sfx("equip");
  }
  unequip(slot: Slot) {
    const it = this.save.equipment[slot];
    if (!it) return;
    if (this.save.inventory.length >= INV_SIZE) { this.addLog("Inventário cheio.", "#ff8a6a"); return; }
    delete this.save.equipment[slot];
    this.save.inventory.push(it);
    this.recalc();
    audio.sfx("equip");
  }

  /* ---------------- xp / chapters ---------------- */
  gainXp(n: number) {
    const s = this.save;
    s.xp += n;
    this.float(this.player.x, this.player.y - 2.2, `+${n} xp`, "#c8b8ff", 13);
    while (s.xp >= xpToNext(s.level)) {
      s.xp -= xpToNext(s.level);
      s.level++;
      s.statPoints += 5;
      this.recalc();
      s.hp = this.d.maxHp; s.mp = this.d.maxMp;
      this.effects.push({ kind: "aura", x: this.player.x, y: this.player.y, color: "#ffe9a8", life: 1.5, maxLife: 1.5 });
      this.addLog(`Nível ${s.level}! +5 pontos de atributo (C).`, "#ffe9a8");
      audio.sfx("levelup");
      if (s.level === EVOLUTION_LEVEL && !s.evolved) this.addLog(`Você pode ascender a ${this.cls.evoName}! Fale com o Ancião.`, "#ffb347");
      for (const sk of this.skills) if (sk.unlock === s.level) this.addLog(`Nova habilidade: ${sk.name}!`, "#9ad7ff");
    }
  }
  currentChapter(): ChapterTemplate | null { return this.chapters[this.save.chapterIndex[this.act.id] ?? 0] ?? null; }
  chapterReady(ch: ChapterTemplate): boolean {
    if (ch.kind === "collect") return this.countMaterial(ch.target!) >= (ch.count ?? 1);
    return this.save.chapterProgress >= (ch.count ?? 1);
  }
  completeChapter(ch: ChapterTemplate) {
    const s = this.save;
    if (ch.kind === "collect") this.removeMaterial(ch.target!, ch.count ?? 1);
    s.gold += ch.rewardGold;
    this.gainXp(ch.rewardXp);
    s.chapterIndex[this.act.id] = (s.chapterIndex[this.act.id] ?? 0) + 1;
    s.chapterProgress = 0;
    this.addLog(`Missão concluída: ${ch.title} (+${ch.rewardGold} ouro)`, "#ffe9a8");
    audio.sfx("quest");
    const next = this.currentChapter();
    if (next) this.banner = { title: "NOVO CAPÍTULO", sub: next.title, t: 4 };
    else this.banner = { title: "ATO CONCLUÍDO", sub: "Todos os capítulos deste ato foram completados!", t: 5 };
    this.persist();
  }
  deliverTo(role: Npc["role"]) {
    const ch = this.currentChapter();
    if (ch && ch.kind === "deliver" && ch.target === role && this.save.chapterProgress < 1) {
      this.save.chapterProgress = 1;
      this.addLog("Entrega feita! Volte ao Ancião.", "#ffe9a8");
      audio.sfx("quest");
      return true;
    }
    return false;
  }
  evolve() {
    if (!canEvolve(this.save)) return;
    this.save.evolved = true;
    this.recalc();
    this.save.hp = this.d.maxHp; this.save.mp = this.d.maxMp;
    this.effects.push({ kind: "pillar", x: this.player.x, y: this.player.y, color: "#ffe9a8", color2: "#ff8a2a", life: 1.6, maxLife: 1.6 });
    this.effects.push({ kind: "ring", x: this.player.x, y: this.player.y, radius: 4, color: "#ffe9a8", life: 1.2, maxLife: 1.2 });
    audio.sfx("levelup"); audio.sfx("holy");
    this.showStory([`${this.save.name} ascendeu: agora é ${this.cls.evoName}.`, this.cls.evoDesc, `Nova habilidade desbloqueada: ${this.cls.skills[4].name} (tecla 5).`]);
    this.persist();
  }

  /* ---------------- exploration / portals ---------------- */
  updateExploration() {
    const r = this.region, p = this.player;
    const px = Math.floor(p.x), py = Math.floor(p.y);
    for (let y = py - 9; y <= py + 9; y++) for (let x = px - 9; x <= px + 9; x++) if (x >= 0 && y >= 0 && x < r.W && y < r.H && (x - px) * (x - px) + (y - py) * (y - py) < 81) r.explored[y * r.W + x] = 1;
    for (const poi of r.pois) {
      if (poi.discovered || this.dist(poi, p) > 4.5) continue;
      poi.discovered = true;
      const key = `${this.act.id}:${poi.id}${poi.id === "camp" ? poi.index : ""}`;
      if (!this.save.poisFound.includes(key)) this.save.poisFound.push(key);
      const names: Record<string, string> = { altar: "Local misterioso descoberto", waystone: "Pedra do Portal ativada!", lair: "Covil do chefe encontrado!", camp: "Acampamento inimigo descoberto" };
      this.addLog(names[poi.id], "#9ad7ff");
      audio.sfx(poi.id === "waystone" ? "portal" : "quest");
      if (poi.id === "waystone") { const wp = `${this.act.id}:waystone`; if (!this.save.waypoints.includes(wp)) this.save.waypoints.push(wp); this.effects.push({ kind: "portalBurst", x: poi.x, y: poi.y, color: "#9ad7ff", life: 1.5, maxLife: 1.5 }); }
      const ch = this.currentChapter();
      if (ch && ch.kind === "explore" && ch.target === poi.id) { this.save.chapterProgress = 1; this.addLog(`Missão "${ch.title}" pronta! Fale com o Ancião.`, "#ffe9a8"); }
    }
  }
  waypointList(): { key: string; label: string; act: number; kind: "village" | "waystone" }[] {
    const out: { key: string; label: string; act: number; kind: "village" | "waystone" }[] = [];
    for (const wp of this.save.waypoints) {
      const [a, k] = wp.split(":");
      const act = ACTS[Number(a) - 1];
      if (!act) continue;
      out.push({ key: wp, label: k === "village" ? `${act.villageName} (Ato ${a})` : `Pedra do Portal — ${act.subtitle}`, act: Number(a), kind: k as "village" | "waystone" });
    }
    return out.sort((x, y) => x.act - y.act || (x.kind === "village" ? -1 : 1));
  }
  travel(wp: { act: number; kind: "village" | "waystone" }) {
    audio.sfx("portal");
    this.ui.panel = null;
    this.persist();
    this.effects.push({ kind: "portalBurst", x: this.player.x, y: this.player.y, color: "#6fa8ff", life: 1, maxLife: 1 });
    if (wp.act !== this.act.id) { this.enterAct(wp.act, wp.kind); if (!this.save.poisFound.includes(`${wp.act}:seen`)) { this.save.poisFound.push(`${wp.act}:seen`); this.showStory([ACTS[wp.act - 1].intro]); } }
    else {
      const pos = wp.kind === "village" ? this.region.village.spawn : this.region.pois.find((p) => p.id === "waystone")!;
      this.player.x = pos.x + 1; this.player.y = pos.y + 1; this.player.moveTarget = null; this.snapCamera();
    }
    this.effects.push({ kind: "portalBurst", x: this.player.x, y: this.player.y, color: "#6fa8ff", life: 1, maxLife: 1 });
  }
  nearPortal(): boolean { return this.dist(this.player, this.region.village.portal) < 2.2; }

  /* ---------------- enemies ---------------- */
  updateEnemies(dt: number) {
    const p = this.player, r = this.region;
    const playerSafe = inVillage(r, p.x, p.y);
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.dead) { e.deadT += dt; this.stepAnim(e, dt); if (e.deadT > 25 && !e.boss) this.enemies.splice(i, 1); continue; }
      const dp = this.dist(e, p);
      if (dp > 45) continue; // far away: frozen
      if (e.flash > 0) e.flash -= dt;
      e.attackCd -= dt; e.slow = Math.max(0, e.slow - dt); e.cursed = Math.max(0, e.cursed - dt); e.stun = Math.max(0, e.stun - dt);
      const speed = e.speed * (e.slow > 0 ? 0.45 : 1) * (e.boss ? 1 : 1);
      const busy = e.playing;
      // target: player or nearest ally
      let target: Actor | null = null;
      let td = Infinity;
      if (!playerSafe && dp < e.aggro * (e.state === "chase" || e.state === "attack" ? 2.2 : 1)) { target = p; td = dp; }
      for (const al of this.allies) { const da = this.dist(e, al); if (!al.dead && da < Math.min(td, e.aggro * 1.6)) { target = al; td = da; } }
      if (e.stun > 0) { this.stepAnim(e, dt); continue; }
      if (!busy) {
        if (target) {
          const range = e.def.ranged ? 6 : 1.2 + e.radius + (target.radius ?? 0.3);
          if (td <= range && e.attackCd <= 0) {
            e.state = "attack"; e.dir = this.dirTo(target.x - e.x, target.y - e.y);
            this.playAnim(e, e.def.attackAnim); e.attackHit = false; e.attackCd = e.boss ? 1.3 : e.def.ranged ? 2.2 : 1.5;
          } else if (td > range * 0.8) {
            e.state = "chase";
            const dx = target.x - e.x, dy = target.y - e.y, l = Math.hypot(dx, dy) || 1;
            // separation from other enemies
            let sx = 0, sy = 0;
            for (const o of this.enemies) { if (o === e || o.dead) continue; const dd = this.dist(e, o); if (dd < 0.8 && dd > 0.001) { sx += (e.x - o.x) / dd * (0.8 - dd); sy += (e.y - o.y) / dd * (0.8 - dd); } }
            const moved = this.tryMove(e, (dx / l + sx) * speed * dt, (dy / l + sy) * speed * dt, false);
            e.dir = this.dirTo(dx, dy);
            if (!moved) { // try sliding sideways
              this.tryMove(e, -dy / l * speed * dt, dx / l * speed * dt, false);
            }
            e.anim = "walk"; e.playing = false;
          }
        } else {
          // return home / wander
          const dh = Math.hypot(e.homeX - e.x, e.homeY - e.y);
          if (e.state === "chase" || e.state === "attack" || dh > 6) e.state = "return";
          if (e.state === "return") {
            if (dh < 0.5) e.state = "idle";
            else { const dx = e.homeX - e.x, dy = e.homeY - e.y; this.tryMove(e, dx / dh * speed * dt, dy / dh * speed * dt, false); e.dir = this.dirTo(dx, dy); e.anim = "walk"; }
          } else {
            e.wanderT -= dt;
            if (e.wanderT <= 0) { e.wanderT = 2 + Math.random() * 4; e.wx = e.homeX + (Math.random() - 0.5) * 4; e.wy = e.homeY + (Math.random() - 0.5) * 4; }
            const dx = e.wx - e.x, dy = e.wy - e.y, l = Math.hypot(dx, dy);
            if (l > 0.3) { this.tryMove(e, dx / l * speed * 0.4 * dt, dy / l * speed * 0.4 * dt, false); e.dir = this.dirTo(dx, dy); e.anim = "walk"; }
            else { e.frame = 0; e.animT = 0; }
          }
        }
      }
      // attack hit frame
      if (e.playing && !e.attackHit && e.frame >= Math.floor(ANIM[e.anim].frames * 0.55)) {
        e.attackHit = true;
        const tgt = target ?? p;
        if (e.def.ranged) { this.fireProjectile(e.x, e.y, tgt.x, tgt.y, e.dmg, "enemy", "dark", e.def.projectileColor ?? "#ff4a4a", 0.3, 0, e.boss ? 1.5 : 0); audio.sfx(e.boss ? "fire" : "bolt"); }
        else if (this.dist(e, tgt) < 1.8 + e.radius + (e.boss ? 0.8 : 0)) {
          if (tgt === p) this.damagePlayer(e.dmg, e);
          else this.damageAlly(tgt as Ally, e.dmg);
          if (e.boss) { this.shake = 6; this.effects.push({ kind: "slashArc", x: e.x, y: e.y, radius: 2.2, color: "#ff3a1a", life: 0.4, maxLife: 0.4 }); }
        }
      }
      const moving = e.state === "chase" || e.state === "return" || (e.state === "idle" && Math.hypot(e.wx - e.x, e.wy - e.y) > 0.3);
      if (busy || moving) this.stepAnim(e, dt, FPS); else { e.frame = 0; }
    }
  }
  damageAlly(a: Ally, dmg: number) {
    a.hp -= dmg; a.flash = 0.15;
    if (a.hp <= 0) { a.dead = true; this.playAnim(a, "hurt"); this.burst(a.x, a.y - 0.5, "#9fd88a", 12); }
  }
  updateAllies(dt: number) {
    const p = this.player;
    for (let i = this.allies.length - 1; i >= 0; i--) {
      const a = this.allies[i];
      if (a.dead) { this.stepAnim(a, dt); a.deadT += dt; if (a.deadT > 2) this.allies.splice(i, 1); continue; }
      a.life -= dt; a.attackCd -= dt;
      if (a.flash > 0) a.flash -= dt;
      if (a.life <= 0) { this.burst(a.x, a.y - 0.5, "#9fd88a", 12); this.allies.splice(i, 1); continue; }
      if (!a.target || a.target.dead || this.dist(a, a.target) > 9) {
        a.target = null; let best = 8;
        for (const e of this.enemies) { if (e.dead) continue; const dd = this.dist(a, e); if (dd < best && this.dist(e, p) < 12) { best = dd; a.target = e; } }
      }
      if (a.playing) {
        if (!a.attackHit && a.frame >= 3 && a.target && this.dist(a, a.target) < 1.6) { a.attackHit = true; this.damageEnemy(a.target, a.dmg, false, "#9fd88a"); }
        this.stepAnim(a, dt); continue;
      }
      const goal = a.target ?? (this.dist(a, p) > 2.5 ? p : null);
      if (goal) {
        const dd = this.dist(a, goal);
        if (a.target && dd < 1.2) { if (a.attackCd <= 0) { a.attackCd = 1.2; this.playAnim(a, "slash"); a.attackHit = false; a.dir = this.dirTo(goal.x - a.x, goal.y - a.y); } else { a.frame = 0; } }
        else { const dx = goal.x - a.x, dy = goal.y - a.y; this.tryMove(a, dx / dd * a.speed * dt, dy / dd * a.speed * dt); a.dir = this.dirTo(dx, dy); a.anim = "walk"; this.stepAnim(a, dt); }
      } else a.frame = 0;
    }
  }
  updateProjectiles(dt: number) {
    const p = this.player;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.x += pr.vx * dt; pr.y += pr.vy * dt; pr.life -= dt;
      if (Math.random() < 0.6) this.particles.push({ x: pr.x, y: pr.y - 0.6, vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5, life: 0.35, maxLife: 0.35, size: 3, color: pr.color2 ?? pr.color, glow: true });
      let remove = pr.life <= 0 || !isWalkable(this.region, pr.x, pr.y) && liquidMask(this.region, Math.floor(pr.x), Math.floor(pr.y)) === 0 && this.region.blocked[Math.floor(pr.y) * this.region.W + Math.floor(pr.x)] === 1 && this.region.props.some((q) => q.blocks && q.kind !== "bush" && Math.hypot(q.x - pr.x, q.y - pr.y) < q.radius + 0.2);
      if (pr.owner === "player" || pr.owner === "ally") {
        for (const e of this.enemies) {
          if (e.dead || pr.hit.has(e.id)) continue;
          if (this.dist(e, pr) < pr.radius + e.radius + 0.2) {
            pr.hit.add(e.id);
            this.damageEnemy(e, pr.dmg, true, pr.color);
            if (pr.splash) { for (const o of this.enemies) if (o !== e && !o.dead && this.dist(o, e) < pr.splash) this.damageEnemy(o, pr.dmg * 0.6, false, pr.color); this.effects.push({ kind: "ring", x: e.x, y: e.y, radius: pr.splash, color: pr.color, color2: pr.color2, life: 0.4, maxLife: 0.4 }); }
            if (pr.pierce <= 0) { remove = true; break; }
            pr.pierce--;
          }
        }
      } else if (!this.dead && this.dist(p, pr) < pr.radius + 0.4) {
        this.damagePlayer(pr.dmg, pr); remove = true;
        if (pr.splash) this.effects.push({ kind: "ring", x: pr.x, y: pr.y, radius: pr.splash, color: pr.color, life: 0.4, maxLife: 0.4 });
      } else {
        for (const a of this.allies) if (!a.dead && this.dist(a, pr) < 0.6) { this.damageAlly(a, pr.dmg); remove = true; break; }
      }
      if (remove) { this.burst(pr.x, pr.y - 0.5, pr.color, 8, 70, 2.5, 0.4); this.projectiles.splice(i, 1); }
    }
  }
  updateFx(dt: number) {
    updateParticles(this.particles, dt);
    for (let i = this.floats.length - 1; i >= 0; i--) { const f = this.floats[i]; f.life -= dt; f.y += f.vy * dt; if (f.life <= 0) this.floats.splice(i, 1); }
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const e = this.effects[i];
      e.life -= dt;
      if (e.kind === "meteor" && e.life <= 0.25 && e.data !== undefined && e.data > 0) {
        const dmg = e.data; e.data = -1;
        for (const en of this.enemies) if (!en.dead && this.dist(en, e) < (e.radius ?? 2) + en.radius) { this.damageEnemy(en, dmg, true, e.color); en.stun = 1; }
        this.effects.push({ kind: "crack", x: e.x, y: e.y, radius: e.radius, color: "#ff8a2a", life: 1.2, maxLife: 1.2 });
        this.effects.push({ kind: "ring", x: e.x, y: e.y, radius: e.radius, color: e.color, color2: e.color2, life: 0.5, maxLife: 0.5 });
        this.burst(e.x, e.y, "#ffb347", 40, 200, 4, 1);
        this.shake = 18;
      }
      if (e.life <= 0) this.effects.splice(i, 1);
    }
  }

  /* ---------------- persistence ---------------- */
  async persist() {
    if (this.saving) return;
    this.saving = true;
    this.save.hp = Math.max(1, Math.round(this.save.hp));
    const ok = await this.g.saveToSlot(this.g.currentSlot, this.save);
    this.saving = false;
    this.savedFlash = 2;
    if (!ok) this.addLog("Salvo localmente (servidor indisponível).", "#ff8a6a");
  }

  /* ---------------- input ---------------- */
  cursorMode(): "normal" | "attack" | "talk" | "hand" {
    if (this.ui.panel) return "normal";
    if (this.hoverEnemy) return "attack";
    if (this.hoverNpc || this.nearPortalHover()) return "talk";
    if (this.hoverDrop) return "hand";
    return "normal";
  }
  nearPortalHover(): boolean {
    const [wx, wy] = this.toWorld(this.g.mouse.x, this.g.mouse.y);
    return Math.hypot(wx - this.region.village.portal.x, wy - this.region.village.portal.y) < 1.5;
  }
  onMouseDown(x: number, y: number, b: number) {
    if (this.storyOverlay) { if (this.storyOverlay.t > 0.6) { const cb = this.storyOverlay.onDone; this.storyOverlay = null; cb?.(); } return; }
    if (this.ui.onMouseDown(x, y, b)) return;
    if (this.dead) return;
    const p = this.player;
    if (b === 2) { this.castSkill(this.activeSkill, x, y); return; }
    if (b !== 0) return;
    if (this.hoverNpc && this.dist(p, this.hoverNpc) < 3) { this.ui.openNpc(this.hoverNpc); return; }
    if (this.hoverNpc) { p.moveTarget = { x: this.hoverNpc.x + 0.8, y: this.hoverNpc.y + 0.8 }; p.attackTarget = null; return; }
    if (this.nearPortalHover()) { if (this.nearPortal()) { this.ui.panel = "portal"; audio.sfx("select"); } else { p.moveTarget = { ...this.region.village.portal }; } return; }
    if (this.hoverEnemy) { p.attackTarget = this.hoverEnemy; p.moveTarget = null; if (this.g.keys.has("Shift")) { p.attackTarget = null; this.basicAttack(this.hoverEnemy); } return; }
    if (this.hoverDrop) { if (this.dist(p, this.hoverDrop) < 1.2) { if (this.pickup(this.hoverDrop)) this.drops.splice(this.drops.indexOf(this.hoverDrop), 1); } else p.moveTarget = { x: this.hoverDrop.x, y: this.hoverDrop.y }; return; }
    const [wx, wy] = this.toWorld(x, y);
    p.attackTarget = null;
    p.moveTarget = { x: wx, y: wy };
  }
  onKeyDown(k: string, e: KeyboardEvent) {
    if (this.storyOverlay) { if (k === " " || k === "Enter" || k === "Escape") { const cb = this.storyOverlay.onDone; this.storyOverlay = null; cb?.(); } return; }
    if (this.ui.onKeyDown(k, e)) return;
    if (this.dead) return;
    if (k >= "1" && k <= "5") { const i = Number(k) - 1; if (this.skills[i]) { this.activeSkill = i; this.castSkill(i, this.g.mouse.x, this.g.mouse.y); } }
    if (k === "q") this.usePotion("potion_hp");
    if (k === "e") this.usePotion("potion_mp");
  }
  onWheel(dy: number) { const n = this.skills.length; this.activeSkill = (this.activeSkill + (dy > 0 ? 1 : n - 1)) % n; audio.sfx("hover"); }

  /* ---------------- render ---------------- */
  render(ctx: CanvasRenderingContext2D) {
    const r = this.region;
    ctx.fillStyle = "#050308";
    ctx.fillRect(0, 0, VW, VH);
    ctx.save();
    if (this.shake > 0) ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
    // visible tile range
    const corners = [this.toWorld(-64, -64), this.toWorld(VW + 64, -64), this.toWorld(-64, VH + 160), this.toWorld(VW + 64, VH + 160)];
    const minX = Math.max(0, Math.floor(Math.min(...corners.map((c) => c[0])))), maxX = Math.min(r.W - 1, Math.ceil(Math.max(...corners.map((c) => c[0]))));
    const minY = Math.max(0, Math.floor(Math.min(...corners.map((c) => c[1])))), maxY = Math.min(r.H - 1, Math.ceil(Math.max(...corners.map((c) => c[1]))));
    const tiles = r.tiles;
    const liquidAnim = Math.sin(this.time * 2) * 1.5;
    for (let y = minY; y <= maxY; y++)
      for (let x = minX; x <= maxX; x++) {
        const [sx, sy] = this.toScreen(x, y);
        if (sx < -TILE_W || sx > VW + TILE_W || sy < -TILE_H * 2 || sy > VH + TILE_H) continue;
        const ox = sx - TILE_W / 2, oy = sy;
        ctx.drawImage(tiles.base[r.ground[y * r.W + x]], ox, oy);
        const lm = liquidMask(r, x, y);
        if (lm && tiles.liquid.length) { ctx.drawImage(tiles.liquid[lm], ox, oy + liquidAnim * 0.3); }
        const pm = pathMask(r, x, y);
        if (pm) ctx.drawImage(tiles.path[pm], ox, oy);
      }
    // safezone ring
    this.drawVillageRing(ctx);
    // ground markers: drops shadows, portal base, lair glyph, targets
    this.drawGroundFx(ctx);
    // depth sorted renderables
    type R = { depth: number; draw: () => void };
    const list: R[] = [];
    const p = this.player;
    const pDepth = p.x + p.y;
    const [psx, psy] = this.toScreen(p.x, p.y);
    for (const pr of r.props) {
      if (pr.kind === "portal" || pr.kind === "lair") continue;
      const [sx, sy] = this.toScreen(pr.x, pr.y);
      if (sx < -pr.w || sx > VW + pr.w || sy < -20 || sy > VH + pr.h) continue;
      let alpha = 1;
      if (pr.occludes && pr.x + pr.y > pDepth && psx > sx - pr.w / 2 && psx < sx + pr.w / 2 && psy > sy - pr.h && psy < sy + 10) {
        const x0 = sx - pr.w / 2, y0 = sy - pr.h + 8;
        let covered = 0;
        for (const [ox, oy] of [[0, -20], [0, -45], [-12, -30], [12, -30]]) if (alphaAt(pr.img, (psx + ox - x0) / pr.w, (psy + oy - y0) / pr.h) > 40) covered++;
        if (covered >= 2) alpha = 0.4;
      }
      list.push({ depth: pr.x + pr.y - (pr.kind === "bush" ? 0.3 : 0), draw: () => { ctx.globalAlpha = alpha; ctx.drawImage(pr.img, sx - pr.w / 2, sy - pr.h + 8, pr.w, pr.h); ctx.globalAlpha = 1; } });
    }
    for (const d of this.drops) {
      const [sx, sy] = this.toScreen(d.x, d.y);
      if (sx < -40 || sx > VW + 40 || sy < -40 || sy > VH + 40) continue;
      list.push({ depth: d.x + d.y - 0.01, draw: () => this.ui.drawDrop(ctx, d, sx, sy) });
    }
    const actors: Actor[] = [...this.enemies, ...this.allies, ...this.npcs, p];
    for (const a of actors) {
      const [sx, sy] = this.toScreen(a.x, a.y);
      if (sx < -100 || sx > VW + 100 || sy < -100 || sy > VH + 150) continue;
      list.push({ depth: a.x + a.y + (a.dead ? -0.5 : 0), draw: () => this.drawActor(ctx, a, sx, sy) });
    }
    for (const pr of this.projectiles) {
      const [sx, sy] = this.toScreen(pr.x, pr.y);
      list.push({ depth: pr.x + pr.y, draw: () => { ctx.save(); ctx.shadowColor = pr.color; ctx.shadowBlur = 14; ctx.fillStyle = pr.color2 ?? "#fff"; ctx.beginPath(); ctx.arc(sx, sy - 20, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = pr.color; ctx.beginPath(); ctx.arc(sx, sy - 20, 4, 0, Math.PI * 2); ctx.fill(); ctx.restore(); } });
    }
    list.sort((a, b) => a.depth - b.depth);
    for (const it of list) it.draw();
    this.drawEffects(ctx);
    // particles (world space -> screen)
    ctx.save();
    for (const pt of this.particles) {
      const [sx, sy] = this.toScreen(pt.x, pt.y);
      const a = Math.max(0, pt.life / pt.maxLife);
      ctx.globalAlpha = a; ctx.fillStyle = pt.color;
      if (pt.glow) { ctx.shadowColor = pt.color; ctx.shadowBlur = 6; }
      ctx.beginPath(); ctx.arc(sx, sy, pt.size * (0.4 + a * 0.6), 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    // floating texts
    for (const f of this.floats) {
      const [sx, sy] = this.toScreen(f.x, f.y);
      ctx.save(); ctx.globalAlpha = Math.min(1, f.life * 2); ctx.font = `bold ${f.size}px Georgia`; ctx.textAlign = "center";
      ctx.strokeStyle = "#000"; ctx.lineWidth = 3; ctx.strokeText(f.text, sx, sy); ctx.fillStyle = f.color; ctx.fillText(f.text, sx, sy); ctx.restore();
    }
    ctx.restore();
    // ambient tint
    if (this.act.ambientColor !== "rgba(0,0,0,0)") { ctx.fillStyle = this.act.ambientColor; ctx.fillRect(0, 0, VW, VH); }
    this.ui.render(ctx);
  }

  drawVillageRing(ctx: CanvasRenderingContext2D) {
    const v = this.region.village;
    ctx.save();
    ctx.strokeStyle = `rgba(255,220,120,${0.25 + Math.sin(this.time * 2) * 0.1})`;
    ctx.lineWidth = 2; ctx.setLineDash([10, 12]); ctx.lineDashOffset = -this.time * 20;
    ctx.beginPath();
    for (let a = 0; a <= Math.PI * 2 + 0.01; a += 0.05) { const [sx, sy] = this.toScreen(v.cx + Math.cos(a) * v.radius, v.cy + Math.sin(a) * v.radius); if (a === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy); }
    ctx.stroke();
    ctx.restore();
  }
  drawGroundFx(ctx: CanvasRenderingContext2D) {
    const v = this.region.village;
    // portal
    const [px, py] = this.toScreen(v.portal.x, v.portal.y);
    ctx.save();
    const g = ctx.createRadialGradient(px, py, 0, px, py, 40);
    g.addColorStop(0, "rgba(90,140,255,0.55)"); g.addColorStop(1, "rgba(90,140,255,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(px, py, 44, 22, 0, 0, Math.PI * 2); ctx.fill();
    // swirling vertical portal
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = `rgba(${120 + i * 40},${170 + i * 20},255,${0.7 - i * 0.2})`;
      ctx.lineWidth = 3 - i * 0.5;
      ctx.shadowColor = "#6fa8ff"; ctx.shadowBlur = 16;
      ctx.beginPath(); ctx.ellipse(px, py - 42, 22 + i * 4 + Math.sin(this.time * 3 + i) * 2, 44 + i * 3, Math.sin(this.time + i) * 0.1, 0, Math.PI * 2); ctx.stroke();
    }
    const ig = ctx.createRadialGradient(px, py - 42, 0, px, py - 42, 26);
    ig.addColorStop(0, "rgba(220,235,255,0.9)"); ig.addColorStop(0.5, "rgba(90,140,255,0.5)"); ig.addColorStop(1, "rgba(40,60,160,0)");
    ctx.fillStyle = ig; ctx.beginPath(); ctx.ellipse(px, py - 42, 20, 42, 0, 0, Math.PI * 2); ctx.fill();
    if (Math.random() < 0.3) this.particles.push({ x: v.portal.x + (Math.random() - 0.5) * 0.6, y: v.portal.y + (Math.random() - 0.5) * 0.6, vx: 0, vy: -1.5, life: 1, maxLife: 1, size: 2.5, color: "#9ad7ff", glow: true });
    ctx.restore();
    // boss lair glyph
    const lair = this.region.lair;
    const [lx, ly] = this.toScreen(lair.x, lair.y);
    if (lx > -200 && lx < VW + 200 && ly > -200 && ly < VH + 200) {
      ctx.save();
      ctx.strokeStyle = `rgba(255,40,20,${0.4 + Math.sin(this.time * 3) * 0.2})`; ctx.lineWidth = 3; ctx.shadowColor = "#ff2a1a"; ctx.shadowBlur = 12;
      ctx.beginPath(); ctx.ellipse(lx, ly, 120, 60, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = this.time * 0.3 + i * Math.PI * 4 / 5; const x = lx + Math.cos(a) * 100, y = ly + Math.sin(a) * 50; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); } ctx.closePath(); ctx.stroke();
      ctx.restore();
    }
    // discovered POIs glow
    for (const poi of this.region.pois) {
      if (poi.id === "camp" || poi.id === "lair") continue;
      const [sx, sy] = this.toScreen(poi.x, poi.y);
      if (sx < -100 || sx > VW + 100 || sy < -100 || sy > VH + 100) continue;
      const col = poi.id === "waystone" ? (poi.discovered ? "154,215,255" : "120,120,140") : "200,80,255";
      const gg = ctx.createRadialGradient(sx, sy, 0, sx, sy, 50);
      gg.addColorStop(0, `rgba(${col},${poi.discovered ? 0.5 : 0.25})`); gg.addColorStop(1, `rgba(${col},0)`);
      ctx.fillStyle = gg; ctx.beginPath(); ctx.ellipse(sx, sy, 50, 25, 0, 0, Math.PI * 2); ctx.fill();
    }
    // move target marker
    const p = this.player;
    if (p.moveTarget) { const [sx, sy] = this.toScreen(p.moveTarget.x, p.moveTarget.y); ctx.strokeStyle = "rgba(255,230,160,0.7)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sx, sy, 12 + Math.sin(this.time * 8) * 3, 6 + Math.sin(this.time * 8) * 1.5, 0, 0, Math.PI * 2); ctx.stroke(); }
    // hovered enemy ring
    if (this.hoverEnemy) { const e = this.hoverEnemy; const [sx, sy] = this.toScreen(e.x, e.y); ctx.strokeStyle = "rgba(255,80,60,0.8)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sx, sy, 22 * e.scale, 11 * e.scale, 0, 0, Math.PI * 2); ctx.stroke(); }
    // player buff rings
    if (p.buffs.phantom > 0) { const [sx, sy] = this.toScreen(p.x, p.y); for (let i = 0; i < 4; i++) { const a = this.time * 6 + i * Math.PI / 2; ctx.save(); ctx.translate(sx + Math.cos(a) * 70, sy - 30 + Math.sin(a) * 35); ctx.rotate(a + Math.PI / 2); ctx.fillStyle = "#cfe9ff"; ctx.shadowColor = "#9ad7ff"; ctx.shadowBlur = 10; ctx.beginPath(); ctx.moveTo(0, -16); ctx.lineTo(4, 10); ctx.lineTo(-4, 10); ctx.closePath(); ctx.fill(); ctx.restore(); } }
  }
  drawActor(ctx: CanvasRenderingContext2D, a: Actor, sx: number, sy: number) {
    // shadow
    ctx.save();
    ctx.globalAlpha = a.dead ? 0.2 : 0.4;
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.ellipse(sx, sy, 14 * a.scale, 7 * a.scale, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    const en = a as Partial<Enemy>;
    if (en.boss && !a.dead) { ctx.save(); const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, 60); g.addColorStop(0, "rgba(255,40,20,0.45)"); g.addColorStop(1, "rgba(255,40,20,0)"); ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(sx, sy, 60, 30, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
    else if (en.elite && !a.dead) { ctx.save(); ctx.strokeStyle = "rgba(255,210,90,0.7)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sx, sy, 18 * a.scale, 9 * a.scale, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
    if (a.faction === "player") {
      const p = a as Player;
      if (p.buffs.shield > 0) { ctx.save(); ctx.strokeStyle = `rgba(154,215,255,${0.5 + Math.sin(this.time * 6) * 0.2})`; ctx.lineWidth = 3; ctx.shadowColor = "#9ad7ff"; ctx.shadowBlur = 12; ctx.beginPath(); ctx.ellipse(sx, sy - 30, 28, 40, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
      if (p.buffs.warcry > 0) { ctx.save(); const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, 40); g.addColorStop(0, "rgba(255,90,40,0.4)"); g.addColorStop(1, "rgba(255,90,40,0)"); ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(sx, sy, 40, 20, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
    }
    const alpha = a.dead ? Math.max(0.25, 1 - a.deadT / 25) : 1;
    drawSheetFrame(ctx, a.sheet, a.anim, a.dir, a.frame, sx, sy, a.scale, alpha);
    if (a.flash > 0) {
      ctx.save(); ctx.globalCompositeOperation = "source-atop"; ctx.restore();
      // hit flash: quick white overlay via tinted redraw
      ctx.save(); ctx.globalAlpha = 0.5; ctx.globalCompositeOperation = "lighter"; drawSheetFrame(ctx, a.sheet, a.anim, a.dir, a.frame, sx, sy, a.scale, 0.6); ctx.restore();
    }
    if (en.cursed && en.cursed > 0 && !a.dead) { ctx.save(); ctx.fillStyle = "#b06aff"; ctx.shadowColor = "#b06aff"; ctx.shadowBlur = 8; ctx.font = "bold 14px serif"; ctx.textAlign = "center"; ctx.fillText("☠", sx, sy - 70 * a.scale); ctx.restore(); }
    if (en.slow && en.slow > 0 && !a.dead) { ctx.save(); ctx.fillStyle = "rgba(150,220,255,0.5)"; ctx.beginPath(); ctx.ellipse(sx, sy - 2, 16 * a.scale, 8 * a.scale, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
    // enemy / ally hp bars
    if ((a.faction === "enemy" || a.faction === "ally") && !a.dead && a.hp < a.maxHp) {
      const w = 36 * a.scale;
      ctx.fillStyle = "#200"; ctx.fillRect(sx - w / 2, sy - 66 * a.scale, w, 4);
      ctx.fillStyle = a.faction === "ally" ? "#8fd88a" : (en.elite ? "#ffd25a" : "#d8282a"); ctx.fillRect(sx - w / 2, sy - 66 * a.scale, w * (a.hp / a.maxHp), 4);
    }
    if (a.faction === "npc") {
      const n = a as Npc;
      const ch = this.currentChapter();
      const marker = n.role === "elder" ? (ch && this.chapterReady(ch) ? "?" : "!") : (ch && ch.kind === "deliver" && ch.target === n.role && this.save.chapterProgress < 1 ? "!" : "");
      if (marker) { ctx.save(); ctx.font = "bold 26px Georgia"; ctx.textAlign = "center"; ctx.fillStyle = marker === "?" ? "#ffe9a8" : "#ffd25a"; ctx.shadowColor = "#000"; ctx.shadowBlur = 4; ctx.fillText(marker, sx, sy - 78 + Math.sin(this.time * 4) * 4); ctx.restore(); }
      if (this.hoverNpc === n) { ctx.save(); ctx.font = "13px Georgia"; ctx.textAlign = "center"; ctx.fillStyle = "#fff0c8"; ctx.shadowColor = "#000"; ctx.shadowBlur = 4; ctx.fillText(`${n.name} — ${n.title}`, sx, sy - 96); ctx.restore(); }
    }
  }
  drawEffects(ctx: CanvasRenderingContext2D) {
    for (const e of this.effects) {
      const t = 1 - e.life / e.maxLife; // 0..1 progress
      const [sx, sy] = this.toScreen(e.x, e.y);
      ctx.save();
      switch (e.kind) {
        case "ring": {
          const rr = (e.radius ?? 2) * TILE_W / 2 * (0.2 + t * 0.8);
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 6 * (1 - t) + 1; ctx.shadowColor = e.color2 ?? e.color; ctx.shadowBlur = 20;
          ctx.beginPath(); ctx.ellipse(sx, sy, rr, rr / 2, 0, 0, Math.PI * 2); ctx.stroke();
          if (e.color2) { ctx.strokeStyle = e.color2; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sx, sy, rr * 0.7, rr * 0.35, 0, 0, Math.PI * 2); ctx.stroke(); }
          break;
        }
        case "slashArc": {
          const rr = (e.radius ?? 2) * TILE_W / 2;
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 8; ctx.shadowColor = e.color; ctx.shadowBlur = 16;
          ctx.beginPath(); ctx.ellipse(sx, sy - 10, rr, rr / 2, 0, t * Math.PI * 2 - 1, t * Math.PI * 2 + 1.2); ctx.stroke();
          break;
        }
        case "beam": {
          const [ex, ey] = this.toScreen(e.x2!, e.y2!);
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 3; ctx.shadowColor = e.color2 ?? e.color; ctx.shadowBlur = 14;
          ctx.beginPath(); ctx.moveTo(sx, sy - 30);
          const n = 6;
          for (let i = 1; i <= n; i++) { const k = i / n; ctx.lineTo(sx + (ex - sx) * k + (i < n ? (Math.random() - 0.5) * 16 : 0), sy - 30 + (ey - sy) * k + (i < n ? (Math.random() - 0.5) * 16 : 0)); }
          ctx.stroke();
          break;
        }
        case "pillar": {
          const h = 220, w = 30 + t * 20;
          const g = ctx.createLinearGradient(0, sy - h, 0, sy);
          g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.6, e.color); g.addColorStop(1, e.color2 ?? e.color);
          ctx.globalAlpha = (1 - t) * 0.85; ctx.fillStyle = g; ctx.shadowColor = e.color; ctx.shadowBlur = 25;
          ctx.fillRect(sx - w / 2, sy - h, w, h);
          ctx.beginPath(); ctx.ellipse(sx, sy, w, w / 2, 0, 0, Math.PI * 2); ctx.fill();
          break;
        }
        case "crack": {
          const rr = (e.radius ?? 2) * TILE_W / 2;
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 3; ctx.shadowColor = "#ff8a2a"; ctx.shadowBlur = 10;
          for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 + 0.3; ctx.beginPath(); ctx.moveTo(sx, sy); let x = sx, y = sy; for (let k = 1; k <= 4; k++) { x += Math.cos(a + (k % 2 ? 0.3 : -0.3)) * rr / 4; y += Math.sin(a + (k % 2 ? 0.3 : -0.3)) * rr / 8; ctx.lineTo(x, y); } ctx.stroke(); }
          ctx.fillStyle = e.color; ctx.globalAlpha = (1 - t) * 0.25; ctx.beginPath(); ctx.ellipse(sx, sy, rr, rr / 2, 0, 0, Math.PI * 2); ctx.fill();
          break;
        }
        case "meteor": {
          if (e.data !== undefined && e.data > 0) {
            const fy = sy - 500 * (1 - t / 0.75), fx = sx + 200 * (1 - t / 0.75);
            ctx.shadowColor = e.color; ctx.shadowBlur = 30; ctx.fillStyle = e.color2 ?? "#fff";
            ctx.beginPath(); ctx.arc(fx, fy, 16, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = e.color; ctx.beginPath(); ctx.arc(fx, fy, 10, 0, Math.PI * 2); ctx.fill();
            for (let i = 0; i < 6; i++) this.particles.push({ x: e.x, y: e.y, vx: 0, vy: 0, life: 0.3, maxLife: 0.3, size: 4, color: e.color, glow: true });
            // trail
            ctx.strokeStyle = e.color; ctx.lineWidth = 6; ctx.globalAlpha = 0.6; ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + 60, fy - 150); ctx.stroke();
            // target marker
            ctx.globalAlpha = 0.6; ctx.strokeStyle = "#ff5a1a"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sx, sy, (e.radius ?? 2) * 32, (e.radius ?? 2) * 16, 0, 0, Math.PI * 2); ctx.stroke();
          }
          break;
        }
        case "aura": {
          ctx.globalAlpha = (1 - t) * 0.8; ctx.strokeStyle = e.color; ctx.lineWidth = 3; ctx.shadowColor = e.color; ctx.shadowBlur = 16;
          for (let i = 0; i < 3; i++) { const yy = sy - 10 - t * 70 - i * 18; ctx.beginPath(); ctx.ellipse(sx, yy, 26 - i * 4, 10 - i * 2, 0, 0, Math.PI * 2); ctx.stroke(); }
          break;
        }
        case "summonCircle": {
          const rr = (e.radius ?? 1) * TILE_W / 2;
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 2; ctx.shadowColor = e.color; ctx.shadowBlur = 12;
          ctx.beginPath(); ctx.ellipse(sx, sy, rr, rr / 2, 0, 0, Math.PI * 2); ctx.stroke();
          ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = i * Math.PI * 4 / 5 + t * 2; const x = sx + Math.cos(a) * rr, y = sy + Math.sin(a) * rr / 2; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); } ctx.closePath(); ctx.stroke();
          break;
        }
        case "portalBurst": {
          ctx.globalAlpha = 1 - t; ctx.strokeStyle = e.color; ctx.lineWidth = 4; ctx.shadowColor = e.color; ctx.shadowBlur = 20;
          ctx.beginPath(); ctx.ellipse(sx, sy - 40, 20 + t * 40, 50 + t * 60, 0, 0, Math.PI * 2); ctx.stroke();
          break;
        }
      }
      ctx.restore();
    }
  }
}

export type { Prop };
