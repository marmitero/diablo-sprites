/**
 * Intro cutscene (elder narration with typewriter text + ember particles), PS1-style name picker,
 * and Diablo-2-like class selection (characters displayed, highlighted selection, description).
 */
import { A, composeSheet, drawSheetFrame, Sheet } from "../core/assets";
import { audio } from "../core/audio";
import { button, drawParticles, fancyText, inRect, panel, Particle, Rect, text, updateParticles, VH, VW, vignette, wrapText } from "../core/ui";
import type { Game, Scene } from "../Game";
import { CLASSES, ClassDef } from "../data/classes";
import { newSave } from "../world/entities";
import { LetterPicker } from "./menu";

const PART1 = [
  "Há muito tempo, o mundo vivia em paz.",
  "Até que um demônio maligno — Belial — considerado um dos Quatro Lordes Supremos do Inferno, começou uma guerra global e trouxe o caos para o mundo.",
  "Essa guerra já dura mais de cem anos. Devastou gerações... e sonhos.",
  "Porém, segundo a profecia, um herói nascerá para salvar o reino.",
  "E seu nome é...",
];
const PART2 = (name: string) => [
  `${name}... nunca esquecerei esse nome.`,
  "Esse é o nome de quem libertou todo o mundo da guerra.",
  "Mas enfim... essa é uma história que você não quer ouvir de mim, certo?",
  "Então... que tal VOCÊ contar essa história?",
];

type Phase = "narr1" | "name" | "narr2" | "done";

export class CutsceneScene implements Scene {
  g: Game;
  seed: string;
  phase: Phase = "narr1";
  lines = PART1;
  li = 0;
  shown = 0;
  t = 0;
  time = 0;
  particles: Particle[] = [];
  picker = new LetterPicker("", 12);
  fadeT = 0;
  name = "";
  elderSheet: Sheet | null = null;
  skipRect: Rect = { x: VW - 170, y: VH - 60, w: 150, h: 40 };

  constructor(g: Game, seed: string) { this.g = g; this.seed = seed; }
  enter() {
    audio.playMusic("village");
    this.elderSheet = composeSheet(["body_light", "feet_brown", "legs_robe", "torso_shirt_brown", "hair_long_white", "beard_white", "wpn_wand"]);
  }
  curLine() { return this.lines[this.li] ?? ""; }
  update(dt: number) {
    this.time += dt;
    if (Math.random() < dt * 18) this.particles.push({ x: Math.random() * VW, y: VH + 10, vx: (Math.random() - 0.5) * 20, vy: -30 - Math.random() * 50, life: 5, maxLife: 5, size: 1 + Math.random() * 2, color: "#ff8a3a", glow: true });
    updateParticles(this.particles, dt);
    if (this.phase === "narr1" || this.phase === "narr2") {
      this.t += dt;
      const target = Math.min(this.curLine().length, Math.floor(this.t * 32));
      if (target !== this.shown) { this.shown = target; if (this.shown % 3 === 0) audio.sfx("page"); }
      if (this.shown >= this.curLine().length && this.t > this.curLine().length / 32 + 2.2) this.nextLine();
    }
  }
  nextLine() {
    this.li++;
    this.t = 0;
    this.shown = 0;
    if (this.li >= this.lines.length) {
      if (this.phase === "narr1") { this.phase = "name"; audio.sfx("portal"); }
      else if (this.phase === "narr2") this.finish();
    }
  }
  finish() {
    if (this.phase === "done") return;
    this.phase = "done";
    audio.sfx("select");
    this.g.goto(new ClassSelectScene(this.g, this.seed, this.name || "Herói"), 1.2);
  }
  render(ctx: CanvasRenderingContext2D) {
    const a = A.data!;
    ctx.drawImage(a.menuSky, -40, -40, VW + 80, VH + 80);
    ctx.fillStyle = "rgba(5,2,8,0.72)";
    ctx.fillRect(0, 0, VW, VH);
    drawParticles(ctx, this.particles);
    vignette(ctx, 0.9);
    // candle light flicker
    const fl = 0.85 + Math.sin(this.time * 9) * 0.05 + Math.sin(this.time * 23) * 0.03;
    const lg = ctx.createRadialGradient(260, 420, 10, 260, 420, 420 * fl);
    lg.addColorStop(0, "rgba(255,170,80,0.28)"); lg.addColorStop(1, "rgba(255,170,80,0)");
    ctx.fillStyle = lg; ctx.fillRect(0, 0, VW, VH);
    if (this.phase === "name") {
      this.picker.render(ctx, "QUAL É O SEU NOME, HERÓI?", this.time, this.g.mouse.x, this.g.mouse.y);
      return;
    }
    // elder portrait (slow breathing)
    const p = a.portraits.elder;
    const ph = 420 + Math.sin(this.time * 1.5) * 4, pw = (p.width / p.height) * ph;
    ctx.drawImage(p, 70, VH - ph - 30, pw, ph);
    // speech panel
    const box: Rect = { x: 380, y: 200, w: 820, h: 300 };
    panel(ctx, box, { title: "O ANCIÃO" });
    const line = this.curLine().slice(0, this.shown);
    const lines = wrapText(ctx, line, box.w - 80, 26);
    lines.forEach((l, i) => text(ctx, l, box.x + 40, box.y + 80 + i * 36, 26, "#f4e8c8"));
    // small elder sprite walking in place at the bottom (animated)
    if (this.elderSheet) drawSheetFrame(ctx, this.elderSheet, "walk", 2, Math.floor(this.time * 8) % 9, box.x + box.w - 60, box.y + box.h - 20, 1.6);
    text(ctx, "Clique para avançar", box.x + box.w - 40, box.y + box.h - 14, 13, "#8a7a60", "right");
    button(ctx, this.skipRect, "PULAR", inRect(this.g.mouse.x, this.g.mouse.y, this.skipRect), { size: 14, time: this.time });
  }
  onMouseMove(x: number, y: number) { if (this.phase === "name") this.picker.hover(x, y); }
  onMouseDown(x: number, y: number, b: number) {
    if (b !== 0) return;
    if (this.phase === "name") {
      const r = this.picker.click(x, y);
      if (r === "ok") this.confirmName();
      else if (r === "back" && !this.picker.value) { /* nothing */ }
      return;
    }
    if (inRect(x, y, this.skipRect)) { if (this.phase === "narr1") { this.phase = "name"; audio.sfx("portal"); } else this.finish(); return; }
    this.advance();
  }
  advance() {
    if (this.shown < this.curLine().length) { this.shown = this.curLine().length; this.t = 999; }
    else this.nextLine();
  }
  confirmName() {
    const v = this.picker.value.trim();
    if (!v) { audio.sfx("error"); return; }
    this.name = v.charAt(0) + v.slice(1).toLowerCase();
    this.phase = "narr2";
    this.lines = PART2(this.name);
    this.li = 0; this.t = 0; this.shown = 0;
    audio.sfx("quest");
  }
  onKeyDown(k: string) {
    if (this.phase === "name") { const r = this.picker.key(k); if (r === "ok") this.confirmName(); return; }
    if (k === " " || k === "Enter") this.advance();
    if (k === "Escape") { if (this.phase === "narr1") { this.phase = "name"; } else this.finish(); }
  }
}

/* ------------------------------------------------------------------ */

export class ClassSelectScene implements Scene {
  g: Game;
  seed: string;
  name: string;
  sel = 0;
  hover = -1;
  time = 0;
  sheets: Sheet[] = [];
  particles: Particle[] = [];
  startRect: Rect = { x: VW / 2 - 120, y: VH - 80, w: 240, h: 50 };
  backRect: Rect = { x: 30, y: VH - 70, w: 140, h: 40 };

  constructor(g: Game, seed: string, name: string) { this.g = g; this.seed = seed; this.name = name; }
  enter() { this.sheets = CLASSES.map((c) => composeSheet(c.layers)); audio.playMusic("menu"); }
  slots(): Rect[] { return CLASSES.map((_, i) => ({ x: 70 + i * 200, y: 170, w: 180, h: 330 })); }
  update(dt: number) {
    this.time += dt;
    if (Math.random() < dt * 20) this.particles.push({ x: Math.random() * VW, y: VH, vx: 0, vy: -40 - Math.random() * 40, life: 4, maxLife: 4, size: 1.5, color: "#ffb347", glow: true });
    updateParticles(this.particles, dt);
  }
  render(ctx: CanvasRenderingContext2D) {
    const a = A.data!;
    ctx.drawImage(a.menuSky, -30, -30, VW + 60, VH + 60);
    ctx.fillStyle = "rgba(4,2,6,0.6)"; ctx.fillRect(0, 0, VW, VH);
    drawParticles(ctx, this.particles);
    // camp fire glow ground
    const g = ctx.createRadialGradient(VW / 2, 520, 20, VW / 2, 520, 600);
    g.addColorStop(0, "rgba(255,120,40,0.25)"); g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH);
    vignette(ctx, 0.8);
    fancyText(ctx, `${this.name.toUpperCase()}, QUEM VOCÊ ERA ANTES DA GUERRA?`, VW / 2, 90, { size: 32, align: "center", glow: "#ff8a2a", wave: 2, time: this.time });
    text(ctx, "Escolha sua classe. Cada uma evolui para uma segunda classe no nível 18.", VW / 2, 125, 16, "#c8b890", "center");
    const rects = this.slots();
    CLASSES.forEach((c, i) => {
      const r = rects[i];
      const selected = this.sel === i;
      const hov = this.hover === i;
      // pedestal glow
      if (selected) {
        const pg = ctx.createRadialGradient(r.x + r.w / 2, r.y + r.h - 20, 5, r.x + r.w / 2, r.y + r.h - 20, 110);
        pg.addColorStop(0, "rgba(255,200,90,0.55)"); pg.addColorStop(1, "rgba(255,200,90,0)");
        ctx.fillStyle = pg; ctx.fillRect(r.x - 40, r.y, r.w + 80, r.h + 40);
      }
      // portrait (painted) - selected one larger and brighter
      const p = a.portraits[c.portrait];
      const ph = (selected ? 300 : 240) + (hov && !selected ? 10 : 0);
      const pw = (p.width / p.height) * ph;
      ctx.save();
      ctx.globalAlpha = selected ? 1 : 0.55;
      if (selected) { ctx.shadowColor = "#ffb347"; ctx.shadowBlur = 25; }
      const bob = selected ? Math.sin(this.time * 2) * 4 : 0;
      ctx.drawImage(p, r.x + r.w / 2 - pw / 2, r.y + r.h - 30 - ph + bob, pw, ph);
      ctx.restore();
      // animated in-game sprite (walk cycle) at feet
      drawSheetFrame(ctx, this.sheets[i], selected ? "walk" : "walk", 2, selected ? Math.floor(this.time * 9) % 9 : 0, r.x + r.w / 2, r.y + r.h + 40, 1.3, selected ? 1 : 0.6);
      fancyText(ctx, c.name.toUpperCase(), r.x + r.w / 2, r.y + r.h + 70, { size: selected ? 22 : 18, align: "center", colors: selected ? ["#fff6d8", "#ffcf5a"] : ["#c8b890", "#7a6a50"] });
    });
    // description panel
    const c = CLASSES[this.sel];
    const box: Rect = { x: 160, y: 575, w: 960, h: 60 };
    panel(ctx, { x: box.x, y: box.y - 10, w: box.w, h: box.h + 14 }, { title: `${c.title} • evolui para ${c.evoName}` });
    const lines = wrapText(ctx, c.desc, box.w - 40, 15);
    lines.forEach((l, i) => text(ctx, l, box.x + box.w / 2, box.y + 26 + i * 18, 15, "#f0e4c8", "center"));
    button(ctx, this.startRect, "INICIAR JORNADA", inRect(this.g.mouse.x, this.g.mouse.y, this.startRect), { size: 20, time: this.time });
    button(ctx, this.backRect, "VOLTAR", inRect(this.g.mouse.x, this.g.mouse.y, this.backRect), { size: 14, time: this.time });
    text(ctx, `Seed: ${this.seed}`, VW - 20, VH - 20, 13, "#8a7a60", "right");
  }
  onMouseMove(x: number, y: number) {
    let h = -1;
    this.slots().forEach((r, i) => { if (inRect(x, y, { x: r.x, y: r.y, w: r.w, h: r.h + 80 })) h = i; });
    if (h !== this.hover) { this.hover = h; if (h >= 0) audio.sfx("hover"); }
  }
  onMouseDown(x: number, y: number, b: number) {
    if (b !== 0) return;
    if (inRect(x, y, this.startRect)) { this.startGame(); return; }
    if (inRect(x, y, this.backRect)) { audio.sfx("back"); import("./menu").then(({ MenuScene }) => this.g.goto(new MenuScene(this.g))); return; }
    this.slots().forEach((r, i) => { if (inRect(x, y, { x: r.x, y: r.y, w: r.w, h: r.h + 80 })) { if (this.sel === i) this.startGame(); else { this.sel = i; audio.sfx("select"); } } });
  }
  onKeyDown(k: string) {
    if (k === "ArrowLeft") { this.sel = (this.sel + 3) % 4; audio.sfx("hover"); }
    if (k === "ArrowRight") { this.sel = (this.sel + 1) % 4; audio.sfx("hover"); }
    if (k === "Enter") this.startGame();
  }
  async startGame() {
    const c: ClassDef = CLASSES[this.sel];
    audio.sfx("portal");
    const save = newSave(this.name, c.id, this.seed);
    const { PlayScene } = await import("./play");
    this.g.goto(new PlayScene(this.g, save, true), 0.8);
  }
}
